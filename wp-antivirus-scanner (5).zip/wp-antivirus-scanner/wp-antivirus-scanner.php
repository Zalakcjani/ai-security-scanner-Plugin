<?php
/**
 * Plugin Name:       WP Anti-Virus Scanner
 * Description:       Malware scanner and repair tool: verifies core, WordPress.org plugins and themes against the official files, repairs infected files from clean originals, quarantines web shells, scans the database (including hidden admin accounts), flags known vulnerabilities, detects file changes, runs scheduled scans with email alerts, and provides post-hack cleanup and hardening. Custom themes and plugins are reported, never replaced.
 * Version:           3.0.1
 * Requires at least: 5.3
 * Requires PHP:      7.2
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wpav
 *
 * @package WPAV
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WPAV_VERSION', '3.0.1' );
define( 'WPAV_FILE', __FILE__ );
define( 'WPAV_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPAV_URL', plugin_dir_url( __FILE__ ) );

/**
 * Load classes on first use: WPAV_DB_Scanner => includes/class-wpav-db-scanner.php.
 * Nothing depends on a hand-maintained include list, so a class can never be "not found".
 */
spl_autoload_register(
	static function ( $class ) {
		if ( 0 !== strpos( $class, 'WPAV_' ) ) {
			return;
		}
		$file = WPAV_DIR . 'includes/class-' . strtolower( str_replace( '_', '-', $class ) ) . '.php';
		if ( is_readable( $file ) ) {
			require_once $file;
		}
	}
);

WPAV_Cron::init();

add_action(
	'plugins_loaded',
	static function () {
		WPAV_Hardening::init();
		if ( is_admin() ) {
			new WPAV_Admin();
		}
	}
);

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	require_once WPAV_DIR . 'includes/class-wpav-cli.php';
	WP_CLI::add_command( 'antivirus', 'WPAV_CLI' );
}

register_activation_hook( __FILE__, array( 'WPAV_Cron', 'reschedule' ) );
register_deactivation_hook( __FILE__, array( 'WPAV_Cron', 'unschedule' ) );
