<?php
/**
 * Known-vulnerability check for installed core, plugin and theme versions,
 * using the free WPVulnerability.net database (no API key).
 *
 * @package WPAV
 */

defined( 'ABSPATH' ) || exit;

class WPAV_Vulnerabilities {

	const API       = 'https://www.wpvulnerability.net/';
	const CACHE_TTL = 43200; // 12 hours.

	const OPERATORS = array(
		'lt' => '<',
		'le' => '<=',
		'gt' => '>',
		'ge' => '>=',
		'eq' => '==',
	);

	/**
	 * @return array|WP_Error API "data" object.
	 */
	private static function fetch( $type, $key ) {
		$cache_key = 'wpav_vuln_' . md5( $type . ':' . $key );
		$cached    = get_site_transient( $cache_key );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		$response = wp_remote_get( self::API . $type . '/' . rawurlencode( $key ) . '/', array( 'timeout' => 15 ) );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		if ( 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'wpav_vuln_http', sprintf( 'HTTP %d', wp_remote_retrieve_response_code( $response ) ) );
		}
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $body ) || ! isset( $body['data'] ) ) {
			return new WP_Error( 'wpav_vuln_json', __( 'Unexpected response from the vulnerability database.', 'wpav' ) );
		}
		$data = is_array( $body['data'] ) ? $body['data'] : array();
		set_site_transient( $cache_key, $data, self::CACHE_TTL );
		return $data;
	}

	private static function in_range( $version, $op ) {
		if ( empty( $op ) || ! is_array( $op ) ) {
			return true;
		}
		if ( ! empty( $op['min_version'] ) ) {
			$cmp = isset( self::OPERATORS[ $op['min_operator'] ] ) ? self::OPERATORS[ $op['min_operator'] ] : '>=';
			if ( ! version_compare( $version, $op['min_version'], $cmp ) ) {
				return false;
			}
		}
		if ( ! empty( $op['max_version'] ) ) {
			$cmp = isset( self::OPERATORS[ $op['max_operator'] ] ) ? self::OPERATORS[ $op['max_operator'] ] : '<=';
			if ( ! version_compare( $version, $op['max_version'], $cmp ) ) {
				return false;
			}
		}
		return true;
	}

	private static function severity( $vuln ) {
		$score = null;
		if ( isset( $vuln['impact']['cvss']['score'] ) ) {
			$score = (float) $vuln['impact']['cvss']['score'];
		} elseif ( isset( $vuln['impact']['cvss3']['score'] ) ) {
			$score = (float) $vuln['impact']['cvss3']['score'];
		}
		if ( null === $score ) {
			return array( 'medium', null );
		}
		if ( $score >= 9 ) {
			return array( 'critical', $score );
		}
		if ( $score >= 7 ) {
			return array( 'high', $score );
		}
		return array( $score >= 4 ? 'medium' : 'low', $score );
	}

	/**
	 * Vulnerabilities affecting one installed component.
	 *
	 * @param string $type    core|plugin|theme.
	 * @param string $slug    Plugin/theme slug ('' for core).
	 * @param string $version Installed version.
	 * @return array|WP_Error { issues: array, fixed_in: string }
	 */
	public static function check( $type, $slug, $version ) {
		$data = self::fetch( $type, 'core' === $type ? $version : $slug );
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$issues   = array();
		$fixed_in = '';

		if ( 'core' !== $type && ! empty( $data['closed'] ) ) {
			$reason   = empty( $data['closed_reason'] ) ? '' : ' (' . $data['closed_reason'] . ')';
			$issues[] = array(
				'kind'     => 'vulnerability',
				'rule'     => 'closed',
				/* translators: %s: reason */
				'title'    => sprintf( __( 'Removed from WordPress.org%s — it will receive no further fixes', 'wpav' ), $reason ),
				'severity' => 'high',
				'line'     => 0,
				'code'     => '',
				'link'     => isset( $data['link'] ) ? (string) $data['link'] : '',
			);
		}

		foreach ( ( isset( $data['vulnerability'] ) && is_array( $data['vulnerability'] ) ) ? $data['vulnerability'] : array() as $vuln ) {
			$op = isset( $vuln['operator'] ) ? $vuln['operator'] : null;
			if ( 'core' !== $type && ! self::in_range( $version, $op ) ) {
				continue;
			}

			$sources = isset( $vuln['source'] ) && is_array( $vuln['source'] ) ? $vuln['source'] : array();
			$title   = isset( $vuln['name'] ) ? $vuln['name'] : __( 'Known vulnerability', 'wpav' );
			$link    = '';
			$cves    = array();
			$named   = false;
			foreach ( $sources as $source ) {
				if ( isset( $source['id'] ) && 0 === strpos( $source['id'], 'CVE-' ) ) {
					$cves[] = $source['id'];
				}
				// Prefer the first human-readable title over a bare CVE id.
				if ( ! $named && ! empty( $source['name'] ) && 0 !== strpos( $source['name'], 'CVE-' ) ) {
					$title = $source['name'];
					$link  = isset( $source['link'] ) ? $source['link'] : '';
					$named = true;
				}
			}
			if ( '' === $link && isset( $sources[0]['link'] ) ) {
				$link = $sources[0]['link'];
			}
			// CVE-only entries: use the first sentence of the description ("[en] …") as the title.
			if ( ! $named && ! empty( $sources[0]['description'] ) ) {
				$description = trim( preg_replace( '/^\[[a-z]{2}\]\s*/', '', $sources[0]['description'] ) );
				$title       = preg_match( '/^(.{20,200}?[.!?])(\s|$)/s', $description, $m ) ? $m[1] : $description;
			}

			list( $severity, $score ) = self::severity( $vuln );

			$fix = '';
			if ( $op && ! empty( $op['max_version'] ) && 'lt' === $op['max_operator'] && empty( $op['unfixed'] ) ) {
				$fix = $op['max_version'];
				if ( '' === $fixed_in || version_compare( $fix, $fixed_in, '>' ) ) {
					$fixed_in = $fix;
				}
			}

			$meta = array_filter(
				array(
					$cves ? implode( ', ', array_unique( $cves ) ) : '',
					null !== $score ? 'CVSS ' . $score : '',
					/* translators: %s: version */
					$fix ? sprintf( __( 'Fixed in %s', 'wpav' ), $fix ) : ( ! empty( $op['unfixed'] ) ? __( 'No fix available', 'wpav' ) : '' ),
				)
			);

			$issues[] = array(
				'kind'     => 'vulnerability',
				'rule'     => isset( $vuln['uuid'] ) ? $vuln['uuid'] : md5( $title ),
				// Plain text; titles contain literal "<= 6.9.1", so no tag stripping (every output escapes it).
				'title'    => WPAV_Util::truncate( html_entity_decode( $title, ENT_QUOTES, 'UTF-8' ), 200 ),
				'severity' => $severity,
				'line'     => 0,
				'code'     => implode( ' · ', $meta ),
				'link'     => esc_url_raw( $link ),
			);
		}

		usort(
			$issues,
			static function ( $a, $b ) {
				return WPAV_Util::severity_rank( $b['severity'] ) - WPAV_Util::severity_rank( $a['severity'] );
			}
		);

		return array(
			'issues'   => $issues,
			'fixed_in' => $fixed_in,
		);
	}

	/**
	 * Build a report finding for a vulnerable component.
	 */
	public static function finding( $type, $slug, $name, $version, array $check ) {
		$labels = array(
			'core'   => __( 'WordPress core', 'wpav' ),
			'plugin' => __( 'Plugin', 'wpav' ),
			'theme'  => __( 'Theme', 'wpav' ),
		);
		$rules  = wp_list_pluck( $check['issues'], 'rule' );
		return array(
			'key'        => 'vuln:' . $type . ':' . $slug,
			'path'       => '',
			'rel'        => trim( $labels[ $type ] . ( 'core' === $type ? '' : ': ' . $name ) . ' ' . $version ),
			'type'       => 'vulnerability',
			'slug'       => $slug,
			'file_rel'   => '',
			'component'  => $name,
			'version'    => $version,
			'source'     => $type,
			'locale'     => '',
			'repairable' => false,
			'expected'   => array(),
			'md5'        => md5( $version . implode( ',', $rules ) ),
			'fixed_in'   => $check['fixed_in'],
			'issues'     => array_slice( $check['issues'], 0, WPAV_Scanner::MAX_ISSUES ),
			'severity'   => WPAV_Util::max_severity( $check['issues'] ),
			'status'     => 'open',
		);
	}
}
