<?php
/**
 * Post-hack cleanup: close the doors attackers leave behind after the malware is gone.
 *
 * @package WPAV
 */

defined( 'ABSPATH' ) || exit;

class WPAV_Cleanup {

	const KEYS = array( 'AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY', 'AUTH_SALT', 'SECURE_AUTH_SALT', 'LOGGED_IN_SALT', 'NONCE_SALT' );

	/* ---- Administrators ------------------------------------------------ */

	/**
	 * Every administrator, read straight from usermeta. Accounts that WP_User_Query
	 * does not return (because a pre_user_query filter hides them) are flagged hidden.
	 *
	 * @param int[]|null $blogs Sites to check (default: current site).
	 */
	public static function administrators( $blogs = null ) {
		global $wpdb;
		$blogs  = $blogs ? $blogs : array( get_current_blog_id() );
		$admins = array();

		foreach ( $blogs as $blog ) {
			$meta_key = $wpdb->get_blog_prefix( $blog ) . 'capabilities';
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT u.ID, u.user_login, u.user_email, u.user_registered FROM {$wpdb->users} u INNER JOIN {$wpdb->usermeta} m ON m.user_id = u.ID WHERE m.meta_key = %s AND m.meta_value LIKE %s",
					$meta_key,
					'%' . $wpdb->esc_like( '"administrator"' ) . '%'
				)
			);
			$visible = array_map(
				'intval',
				get_users(
					array(
						'blog_id' => $blog,
						'role'    => 'administrator',
						'fields'  => 'ID',
					)
				)
			);

			foreach ( (array) $rows as $row ) {
				$id = (int) $row->ID;
				if ( ! isset( $admins[ $id ] ) ) {
					$admins[ $id ] = array(
						'id'            => $id,
						'login'         => $row->user_login,
						'email'         => $row->user_email,
						'registered'    => $row->user_registered,
						'registered_ts' => (int) strtotime( $row->user_registered . ' UTC' ),
						'hidden'        => false,
						'blogs'         => array(),
					);
				}
				$admins[ $id ]['blogs'][] = $blog;
				if ( ! in_array( $id, $visible, true ) ) {
					$admins[ $id ]['hidden'] = true;
				}
			}
		}
		return array_values( $admins );
	}

	/**
	 * Remove administrator rights (the safe alternative to deleting an unknown account).
	 */
	public static function demote( $user_id ) {
		$user_id = (int) $user_id;
		if ( get_current_user_id() === $user_id ) {
			return new WP_Error( 'wpav_self', __( 'You cannot demote your own account.', 'wpav' ) );
		}
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return new WP_Error( 'wpav_no_user', __( 'User not found.', 'wpav' ) );
		}

		$blogs = is_multisite() ? array_map( 'intval', get_sites( array( 'fields' => 'ids', 'number' => WPAV_DB_Scanner::MAX_SITES ) ) ) : array( get_current_blog_id() );
		foreach ( self::administrators( $blogs ) as $admin ) {
			if ( $admin['id'] !== $user_id ) {
				continue;
			}
			foreach ( $admin['blogs'] as $blog ) {
				$site_user = new WP_User( $user_id, '', $blog );
				$site_user->set_role( 'subscriber' );
			}
		}
		if ( is_multisite() && is_super_admin( $user_id ) ) {
			revoke_super_admin( $user_id );
		}
		WP_Session_Tokens::get_instance( $user_id )->destroy_all();

		WPAV_Log::add( __( 'Demoted administrator', 'wpav' ), $user->user_login );
		/* translators: %s: user login */
		return array( 'message' => sprintf( __( '%s is now a subscriber and has been logged out.', 'wpav' ), $user->user_login ) );
	}

	/* ---- Sessions & passwords ----------------------------------------- */

	/**
	 * Log out every user everywhere, except the current browser session.
	 */
	public static function logout_all() {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$ids     = $wpdb->get_col( "SELECT DISTINCT user_id FROM {$wpdb->usermeta} WHERE meta_key = 'session_tokens'" );
		$current = get_current_user_id();
		$token   = wp_get_session_token();

		foreach ( $ids as $id ) {
			$manager = WP_Session_Tokens::get_instance( (int) $id );
			if ( (int) $id === $current && $token ) {
				$manager->destroy_others( $token );
			} else {
				$manager->destroy_all();
			}
		}
		WPAV_Log::add( __( 'Logged out all users', 'wpav' ), '', count( $ids ) . ' users' );
		/* translators: %d: number of users */
		return array( 'message' => sprintf( __( 'Logged out %d user(s) on all devices (your current session was kept).', 'wpav' ), count( $ids ) ) );
	}

	/**
	 * Set a random password for privileged users (hidden admins included) and optionally email reset links.
	 */
	public static function reset_passwords( $send_email ) {
		$ids = wp_list_pluck( self::administrators(), 'id' );
		$ids = array_merge(
			$ids,
			array_map(
				'intval',
				get_users(
					array(
						'role__in' => array( 'administrator', 'editor', 'shop_manager' ),
						'fields'   => 'ID',
					)
				)
			)
		);
		$ids = array_diff( array_unique( $ids ), array( get_current_user_id() ) );

		// retrieve_password( $login ) exists in core from WordPress 5.7.
		$send_email = $send_email && function_exists( 'retrieve_password' ) && version_compare( get_bloginfo( 'version' ), '5.7', '>=' );
		$emailed    = 0;
		foreach ( $ids as $id ) {
			$user = get_userdata( $id );
			if ( ! $user ) {
				continue;
			}
			wp_set_password( wp_generate_password( 32, true, true ), $id );
			WP_Session_Tokens::get_instance( $id )->destroy_all();
			if ( $send_email && true === retrieve_password( $user->user_login ) ) {
				$emailed++;
			}
		}

		WPAV_Log::add( __( 'Forced password reset', 'wpav' ), '', count( $ids ) . ' users' );
		return array(
			'message' => sprintf(
				/* translators: 1: users reset, 2: emails sent */
				__( 'Passwords reset for %1$d privileged user(s); %2$d reset email(s) sent. Change your own password too.', 'wpav' ),
				count( $ids ),
				$emailed
			),
		);
	}

	/* ---- Security keys ------------------------------------------------- */

	public static function config_path() {
		if ( file_exists( ABSPATH . 'wp-config.php' ) ) {
			return ABSPATH . 'wp-config.php';
		}
		$parent = dirname( ABSPATH );
		if ( file_exists( $parent . '/wp-config.php' ) && ! file_exists( $parent . '/wp-settings.php' ) ) {
			return $parent . '/wp-config.php';
		}
		return '';
	}

	/**
	 * Generate new authentication keys and salts. This invalidates every login cookie,
	 * including the current one. wp-config.php is backed up and syntax-checked before writing.
	 */
	public static function regenerate_keys() {
		if ( ! WPAV_Repair::can_modify() ) {
			return new WP_Error( 'wpav_file_mods', __( 'File modifications are disabled on this site (DISALLOW_FILE_MODS).', 'wpav' ) );
		}

		$config  = self::config_path();
		$in_file = array();

		if ( $config ) {
			$content = (string) file_get_contents( $config ); // phpcs:ignore
			$updated = $content;
			foreach ( self::KEYS as $key ) {
				$pattern = '/(define\s*\(\s*([\'"])' . $key . '\2\s*,\s*)([\'"])(?:\\\\.|(?!\3).)*\3(\s*\))/s';
				$updated = preg_replace_callback(
					$pattern,
					static function ( $m ) use ( $key, &$in_file ) {
						$in_file[ $key ] = true;
						return $m[1] . "'" . WPAV_Cleanup::random_key() . "'" . $m[4];
					},
					$updated,
					1
				);
			}

			if ( $in_file ) {
				if ( ! is_writable( $config ) ) {
					return new WP_Error( 'wpav_config_write', __( 'wp-config.php is not writable. Replace the keys manually with new ones from https://api.wordpress.org/secret-key/1.1/salt/', 'wpav' ) );
				}
				try {
					token_get_all( $updated, TOKEN_PARSE );
				} catch ( ParseError $e ) {
					return new WP_Error( 'wpav_config_parse', __( 'The updated wp-config.php failed a syntax check, so it was not saved.', 'wpav' ) );
				}
				$backup = WPAV_Backup::create( $config, __( 'Before regenerating security keys', 'wpav' ) );
				if ( is_wp_error( $backup ) ) {
					return $backup;
				}
				if ( false === file_put_contents( $config, $updated, LOCK_EX ) ) { // phpcs:ignore
					return new WP_Error( 'wpav_config_write', __( 'wp-config.php could not be written (a backup was kept).', 'wpav' ) );
				}
				if ( function_exists( 'opcache_invalidate' ) ) {
					@opcache_invalidate( $config, true ); // phpcs:ignore
				}
			}
		}

		// Keys not defined in wp-config.php fall back to values stored in the database.
		foreach ( self::KEYS as $key ) {
			update_site_option( strtolower( $key ), self::random_key() );
		}

		WPAV_Log::add( __( 'Regenerated security keys', 'wpav' ), $config ? WPAV_Util::rel( $config ) : 'database', count( $in_file ) . ' keys in wp-config.php' );
		return array(
			'message' => $in_file
				? __( 'New security keys saved to wp-config.php (backup in Backups). Everyone, including you, must log in again.', 'wpav' )
				: __( 'wp-config.php defines no keys, so new keys were stored in the database. Everyone, including you, must log in again. Consider adding keys to wp-config.php.', 'wpav' ),
			'relogin' => true,
		);
	}

	/**
	 * 64 random characters without quotes or backslashes (safe inside a PHP string literal).
	 */
	public static function random_key() {
		return wp_generate_password( 64, true, true );
	}

	/* ---- Scheduled tasks ----------------------------------------------- */

	/**
	 * All WP-Cron events of the current site with a suspicion assessment.
	 */
	public static function cron_events() {
		$crons  = function_exists( '_get_cron_array' ) ? _get_cron_array() : array();
		$events = array();
		foreach ( (array) $crons as $timestamp => $hooks ) {
			if ( ! is_array( $hooks ) ) {
				continue;
			}
			foreach ( $hooks as $hook => $instances ) {
				foreach ( (array) $instances as $sig => $event ) {
					$args     = isset( $event['args'] ) ? (array) $event['args'] : array();
					$args_str = $args ? serialize( $args ) : ''; // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize
					$events[] = array(
						'id'           => md5( $timestamp . '|' . $hook . '|' . $sig ),
						'timestamp'    => (int) $timestamp,
						'hook'         => (string) $hook,
						'sig'          => $sig,
						'schedule'     => empty( $event['schedule'] ) ? '' : $event['schedule'],
						'args'         => $args,
						'args_preview' => WPAV_Util::clean_text( WPAV_Util::truncate( (string) wp_json_encode( $args ), 160 ) ),
						'has_callback' => false !== has_action( $hook ),
						'args_issues'  => $args_str ? WPAV_Signatures::scan( $args_str, array( 'db', 'php' ) ) : array(),
					);
				}
			}
		}
		return $events;
	}

	public static function delete_cron( $id ) {
		foreach ( self::cron_events() as $event ) {
			if ( $event['id'] === $id ) {
				$result = wp_unschedule_event( $event['timestamp'], $event['hook'], $event['args'] );
				if ( false === $result || is_wp_error( $result ) ) {
					return new WP_Error( 'wpav_cron', __( 'The scheduled task could not be removed.', 'wpav' ) );
				}
				WPAV_Log::add( __( 'Deleted scheduled task', 'wpav' ), $event['hook'], $event['args_preview'] );
				/* translators: %s: hook */
				return array( 'message' => sprintf( __( 'Removed scheduled task %s.', 'wpav' ), $event['hook'] ) );
			}
		}
		return new WP_Error( 'wpav_cron', __( 'Scheduled task not found (it may have just run).', 'wpav' ) );
	}

	/* ---- Must-use plugins & drop-ins ------------------------------------ */

	/**
	 * Code that loads automatically and cannot be deactivated — a favourite hiding place.
	 */
	public static function autoloaded_code() {
		if ( ! function_exists( 'get_mu_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$items = array();
		foreach ( get_mu_plugins() as $file => $data ) {
			$items[] = array(
				'type' => __( 'Must-use plugin', 'wpav' ),
				'path' => wp_normalize_path( WPMU_PLUGIN_DIR . '/' . $file ),
				'name' => $data['Name'] ? $data['Name'] : __( '(no plugin header)', 'wpav' ),
			);
		}
		foreach ( get_dropins() as $file => $data ) {
			$items[] = array(
				'type' => __( 'Drop-in', 'wpav' ),
				'path' => wp_normalize_path( WP_CONTENT_DIR . '/' . $file ),
				'name' => $data['Name'] ? $data['Name'] : $file,
			);
		}
		return $items;
	}
}
