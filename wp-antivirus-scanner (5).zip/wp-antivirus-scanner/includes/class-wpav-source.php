<?php
/**
 * Fetches clean original files from WordPress.org and diffs them against local copies.
 *
 * Every fetched file is verified against the official md5 before it is returned,
 * so a repair can only ever write byte-identical official content.
 *
 * @package WPAV
 */

defined( 'ABSPATH' ) || exit;

class WPAV_Source {

	const CACHE_TTL = DAY_IN_SECONDS;

	/**
	 * @return string|WP_Error Verified original file contents.
	 */
	public static function original( array $finding ) {
		if ( empty( $finding['expected'] ) ) {
			return new WP_Error( 'wpav_no_reference', __( 'There is no official reference for this file.', 'wpav' ) );
		}

		$version  = $finding['version'];
		$rel      = $finding['file_rel'];
		$expected = $finding['expected'];

		if ( 'core' === $finding['type'] ) {
			$file_urls = array( 'https://core.svn.wordpress.org/tags/' . rawurlencode( $version ) . '/' . self::encode_path( $rel ) );
			$zip_urls  = array();
			if ( ! empty( $finding['locale'] ) && 'en_US' !== $finding['locale'] ) {
				$zip_urls[] = 'https://downloads.wordpress.org/release/' . rawurlencode( $finding['locale'] ) . '/wordpress-' . rawurlencode( $version ) . '.zip';
			}
			$zip_urls[] = 'https://downloads.wordpress.org/release/wordpress-' . rawurlencode( $version ) . '.zip';
			$cache_name = 'core-' . $version . '-' . ( empty( $finding['locale'] ) ? 'en_US' : $finding['locale'] );
			$prefix     = 'wordpress/';
		} elseif ( 'plugin' === $finding['type'] && 'wporg' === $finding['source'] ) {
			$slug       = $finding['slug'];
			$file_urls  = array( 'https://plugins.svn.wordpress.org/' . rawurlencode( $slug ) . '/tags/' . rawurlencode( $version ) . '/' . self::encode_path( $rel ) );
			$zip_urls   = array( 'https://downloads.wordpress.org/plugin/' . rawurlencode( $slug ) . '.' . rawurlencode( $version ) . '.zip' );
			$cache_name = 'plugin-' . $slug . '-' . $version;
			$prefix     = $slug . '/';
		} elseif ( 'theme' === $finding['type'] && 'wporg' === $finding['source'] ) {
			$slug       = $finding['slug'];
			$file_urls  = array( 'https://themes.svn.wordpress.org/' . rawurlencode( $slug ) . '/' . rawurlencode( $version ) . '/' . self::encode_path( $rel ) );
			$zip_urls   = array( self::theme_zip_url( $slug, $version ) );
			$cache_name = 'theme-' . $slug . '-' . $version;
			$prefix     = $slug . '/';
		} else {
			return new WP_Error( 'wpav_not_repairable', __( 'Only WordPress core and WordPress.org plugin/theme files can be restored from an official source.', 'wpav' ) );
		}

		// 1. Single file straight from SVN (fast, small).
		foreach ( $file_urls as $url ) {
			$response = wp_remote_get( $url, array( 'timeout' => 30 ) );
			if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
				$body = wp_remote_retrieve_body( $response );
				if ( in_array( md5( $body ), $expected, true ) ) {
					return $body;
				}
			}
		}

		// 2. Fall back to the official release zip (cached for a day).
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'wpav_no_zip', __( 'Could not fetch the file from WordPress.org SVN and the PHP Zip extension is not available for the package fallback.', 'wpav' ) );
		}
		$zip_file = self::package( $zip_urls, $cache_name );
		if ( is_wp_error( $zip_file ) ) {
			return $zip_file;
		}

		$zip = new ZipArchive();
		if ( true !== $zip->open( $zip_file ) ) {
			@unlink( $zip_file ); // phpcs:ignore
			return new WP_Error( 'wpav_zip_open', __( 'The downloaded package could not be opened.', 'wpav' ) );
		}
		$body = $zip->getFromName( $prefix . $rel );
		$zip->close();

		if ( false === $body ) {
			return new WP_Error( 'wpav_zip_missing', __( 'The file was not found in the official package.', 'wpav' ) );
		}
		if ( ! in_array( md5( $body ), $expected, true ) ) {
			return new WP_Error( 'wpav_checksum', __( 'The downloaded file failed checksum verification, so it was not used.', 'wpav' ) );
		}
		return $body;
	}

	/**
	 * Added / removed lines between the official file and the local copy.
	 */
	public static function diff( array $finding ) {
		$original = self::original( $finding );
		if ( is_wp_error( $original ) ) {
			return $original;
		}
		$current = @file_get_contents( $finding['path'] ); // phpcs:ignore
		if ( false === $current ) {
			return new WP_Error( 'wpav_read', __( 'The local file could not be read.', 'wpav' ) );
		}

		if ( ! class_exists( 'Text_Diff', false ) ) {
			require_once ABSPATH . WPINC . '/wp-diff.php';
		}

		$old  = preg_split( '/\r\n|\n|\r/', $original );
		$new  = preg_split( '/\r\n|\n|\r/', $current );
		$diff = new Text_Diff( $old, $new );

		$lines     = array();
		$old_line  = 1;
		$new_line  = 1;
		$limit     = 500;
		$truncated = false;

		foreach ( $diff->getDiff() as $op ) {
			$orig  = is_array( $op->orig ) ? $op->orig : array();
			$final = is_array( $op->final ) ? $op->final : array();

			if ( ! ( $op instanceof Text_Diff_Op_copy ) ) {
				foreach ( $orig as $i => $text ) {
					$lines[] = array(
						't'    => '-',
						'line' => $old_line + $i,
						'code' => WPAV_Util::clean_text( WPAV_Util::truncate( $text, 500 ) ),
					);
				}
				foreach ( $final as $i => $text ) {
					$lines[] = array(
						't'    => '+',
						'line' => $new_line + $i,
						'code' => WPAV_Util::clean_text( WPAV_Util::truncate( $text, 500 ) ),
					);
				}
			}
			$old_line += count( $orig );
			$new_line += count( $final );

			if ( count( $lines ) > $limit ) {
				$lines     = array_slice( $lines, 0, $limit );
				$truncated = true;
				break;
			}
		}

		return array(
			'lines'     => $lines,
			'truncated' => $truncated,
		);
	}

	/**
	 * Remove cached packages older than a day.
	 */
	public static function prune_cache() {
		$dir = WPAV_Storage::dir( 'cache' );
		foreach ( (array) glob( $dir . '/*.zip' ) as $file ) {
			if ( $file && filemtime( $file ) < time() - self::CACHE_TTL ) {
				@unlink( $file ); // phpcs:ignore
			}
		}
	}

	public static function theme_zip_url( $slug, $version ) {
		return 'https://downloads.wordpress.org/theme/' . rawurlencode( $slug ) . '.' . rawurlencode( $version ) . '.zip';
	}

	/**
	 * Download an official package into the private cache (reused for a day).
	 *
	 * @return string|WP_Error Local zip path.
	 */
	public static function package( array $urls, $name ) {
		$file = WPAV_Storage::dir( 'cache' ) . '/' . sanitize_file_name( $name ) . '.zip';
		if ( file_exists( $file ) && filesize( $file ) > 0 ) {
			return $file;
		}

		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		$error = new WP_Error( 'wpav_download', __( 'Could not download the official package.', 'wpav' ) );
		foreach ( $urls as $url ) {
			$tmp = download_url( $url, 300 );
			if ( is_wp_error( $tmp ) ) {
				$error = $tmp;
				continue;
			}
			if ( @rename( $tmp, $file ) || @copy( $tmp, $file ) ) { // phpcs:ignore
				@unlink( $tmp ); // phpcs:ignore
				return $file;
			}
			@unlink( $tmp ); // phpcs:ignore
		}
		return $error;
	}

	private static function encode_path( $path ) {
		return implode( '/', array_map( 'rawurlencode', explode( '/', $path ) ) );
	}
}
