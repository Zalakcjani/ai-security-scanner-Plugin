<?php
/**
 * Resumable scan engine. Callers (admin AJAX, WP-Cron, WP-CLI) drive it through
 * repeated step() calls so large sites never hit PHP time limits.
 *
 * Phases: plugins (fetch WordPress.org checksums) -> files (hash + signature scan)
 *         -> database (optional) -> done.
 *
 * @package WPAV
 */

defined( 'ABSPATH' ) || exit;

class WPAV_Scanner {

	const TIME_BUDGET      = 8;
	const FILES_PER_STEP   = 600;
	const PLUGINS_PER_STEP = 6;
	const MAX_ISSUES       = 25;
	const STALE_AFTER      = 600;
	const MAX_CHANGE_LIST  = 500;

	const QUEUE    = 'queue.json';
	const CONTEXT  = 'context.json';
	const PROGRESS = 'progress.json';
	const HASHES   = 'hashes.txt';
	const BASELINE = 'baseline.json';

	/** @var string manual|cron|cli */
	private $origin;

	/** @var array */
	private $ctx;

	/** @var array */
	private $dirs;

	/** @var string Buffered "md5 flag path" lines for change detection. */
	private $hash_lines = '';

	/** @var int */
	private $max_bytes;

	public function __construct( $origin = 'manual' ) {
		$this->origin    = $origin;
		$this->max_bytes = (int) WPAV_Settings::get( 'max_file_mb' ) * MB_IN_BYTES;
	}

	/**
	 * A scan is running if it has not finished and made progress recently.
	 */
	public static function is_running() {
		$progress = WPAV_Storage::read_json( self::PROGRESS );
		return $progress && 'done' !== $progress['phase'] && isset( $progress['updated'] ) && $progress['updated'] > time() - self::STALE_AFTER;
	}

	public static function current_scan_id() {
		$progress = WPAV_Storage::read_json( self::PROGRESS );
		return $progress ? $progress['scan_id'] : '';
	}

	public function start() {
		@set_time_limit( 300 ); // phpcs:ignore

		WPAV_Source::prune_cache();
		WPAV_Storage::delete( self::HASHES );

		$context = array(
			'scan_id' => strtolower( wp_generate_password( 10, false, false ) ),
			'started' => time(),
			'origin'  => $this->origin,
			'core'    => WPAV_Integrity::core_info(),
			'plugins' => WPAV_Integrity::installed_plugins(),
			'themes'  => WPAV_Integrity::installed_themes(),
		);
		$queue   = $this->build_queue();

		WPAV_Storage::write_json( self::CONTEXT, $context );
		WPAV_Storage::write_json( self::QUEUE, $queue );

		$progress = array(
			'scan_id'       => $context['scan_id'],
			'origin'        => $this->origin,
			'phase'         => 'plugins',
			'updated'       => time(),
			'scan_db'       => (bool) WPAV_Settings::get( 'scan_database' ),
			'scan_vulns'    => (bool) WPAV_Settings::get( 'check_vulns' ),
			'plugin_pos'    => 0,
			'vuln_pos'      => 0,
			'pos'           => 0,
			'total'         => count( $queue ),
			'db'            => null,
			'stats'         => array(
				'scanned'  => 0,
				'verified' => 0,
				'skipped'  => 0,
				'db_rows'  => 0,
			),
			'plugin_counts' => array(),
			'findings'      => array(),
		);
		WPAV_Storage::write_json( self::PROGRESS, $progress );

		return $this->status( $progress, $context );
	}

	/**
	 * @return array|WP_Error
	 */
	public function step() {
		@set_time_limit( 120 ); // phpcs:ignore

		$progress = WPAV_Storage::read_json( self::PROGRESS );
		$context  = WPAV_Storage::read_json( self::CONTEXT );
		if ( $progress && 'done' === $progress['phase'] ) {
			return $this->status( $progress, $context ? $context : array( 'plugins' => array() ) );
		}
		if ( ! $progress || ! $context || $progress['scan_id'] !== $context['scan_id'] ) {
			return new WP_Error( 'wpav_no_scan', __( 'No scan is running. Start a new scan.', 'wpav' ) );
		}

		$deadline = microtime( true ) + self::TIME_BUDGET;

		if ( 'plugins' === $progress['phase'] ) {
			$components = self::components( $context );
			$count      = 0;
			while ( $progress['plugin_pos'] < count( $components ) && $count < self::PLUGINS_PER_STEP && microtime( true ) < $deadline ) {
				list( $type, $slug ) = $components[ $progress['plugin_pos'] ];
				if ( 'plugin' === $type ) {
					$this->resolve_plugin( $context['plugins'][ $slug ], $slug );
				} else {
					$this->resolve_theme( $context['themes'][ $slug ], $slug );
				}
				$progress['plugin_pos']++;
				$count++;
			}
			WPAV_Storage::write_json( self::CONTEXT, $context );
			if ( $progress['plugin_pos'] >= count( $components ) ) {
				$progress['phase'] = 'files';
			}
		} elseif ( 'vulns' === $progress['phase'] ) {
			$targets = self::vuln_targets( $context );
			while ( $progress['vuln_pos'] < count( $targets ) && microtime( true ) < $deadline ) {
				list( $type, $slug, $name, $version ) = $targets[ $progress['vuln_pos'] ];
				$check = WPAV_Vulnerabilities::check( $type, $slug, $version );
				if ( ! is_wp_error( $check ) && $check['issues'] ) {
					$progress['findings'][] = WPAV_Vulnerabilities::finding( $type, $slug, $name, $version, $check );
				}
				$progress['vuln_pos']++;
			}
			if ( $progress['vuln_pos'] >= count( $targets ) ) {
				$progress['phase'] = $progress['scan_db'] ? 'database' : 'finish';
			}
		} elseif ( 'files' === $progress['phase'] ) {
			$queue     = WPAV_Storage::read_json( self::QUEUE, array() );
			$this->ctx = $context;
			$this->init_dirs();

			$count = 0;
			while ( $progress['pos'] < $progress['total'] && $count < self::FILES_PER_STEP && microtime( true ) < $deadline ) {
				$finding = $this->scan_file( $queue[ $progress['pos'] ], $progress );
				if ( $finding ) {
					$progress['findings'][] = $finding;
				}
				$progress['pos']++;
				$count++;
			}
			$this->flush_hashes();

			if ( $progress['pos'] >= $progress['total'] ) {
				$progress['phase'] = $progress['scan_vulns'] ? 'vulns' : ( $progress['scan_db'] ? 'database' : 'finish' );
			}
		} elseif ( 'database' === $progress['phase'] ) {
			if ( WPAV_DB_Scanner::step( $progress, $deadline ) ) {
				$progress['phase'] = 'finish';
			}
		}

		if ( 'finish' === $progress['phase'] ) {
			$this->finish( $progress, $context );
		}

		$progress['updated'] = time();
		WPAV_Storage::write_json( self::PROGRESS, $progress );

		return $this->status( $progress, $context );
	}

	/**
	 * Plugins and themes to verify against WordPress.org, in order.
	 */
	private static function components( array $context ) {
		$list = array();
		foreach ( array_keys( $context['plugins'] ) as $slug ) {
			$list[] = array( 'plugin', $slug );
		}
		foreach ( array_keys( $context['themes'] ) as $slug ) {
			$list[] = array( 'theme', $slug );
		}
		return $list;
	}

	/**
	 * Components to check for known vulnerabilities: [type, slug, name, version].
	 */
	private static function vuln_targets( array $context ) {
		$list = array( array( 'core', '', __( 'WordPress', 'wpav' ), $context['core']['version'] ) );
		foreach ( $context['plugins'] as $slug => $plugin ) {
			// Premium plugins are covered by the database too, so custom-source plugins are included.
			if ( '' !== (string) $plugin['version'] ) {
				$list[] = array( 'plugin', $slug, $plugin['name'], $plugin['version'] );
			}
		}
		foreach ( $context['themes'] as $slug => $theme ) {
			if ( '' !== (string) $theme['version'] ) {
				$list[] = array( 'theme', $slug, $theme['name'], $theme['version'] );
			}
		}
		return $list;
	}

	private function resolve_theme( array &$theme, $slug ) {
		if ( 'pending' !== $theme['source'] ) {
			return;
		}
		$sums = WPAV_Integrity::theme_checksums( $slug, $theme['version'] );
		if ( is_wp_error( $sums ) ) {
			$theme['source'] = 'unverified';
			$theme['note']   = sprintf(
				/* translators: %s: error message */
				__( 'Could not verify with WordPress.org: %s', 'wpav' ),
				$sums->get_error_message()
			);
		} elseif ( null === $sums ) {
			$theme['source'] = 'custom';
			$theme['note']   = __( 'This theme/version is not published on WordPress.org.', 'wpav' );
		} else {
			$theme['source']    = 'wporg';
			$theme['checksums'] = $sums;
		}
	}

	private function resolve_plugin( array &$plugin, $slug ) {
		if ( 'pending' !== $plugin['source'] ) {
			return;
		}
		$sums = WPAV_Integrity::plugin_checksums( $slug, $plugin['version'] );
		if ( is_wp_error( $sums ) ) {
			$plugin['source'] = 'unverified';
			$plugin['note']   = sprintf(
				/* translators: %s: error message */
				__( 'Could not reach WordPress.org: %s', 'wpav' ),
				$sums->get_error_message()
			);
		} elseif ( null === $sums ) {
			$plugin['source'] = 'custom';
			$plugin['note']   = __( 'This plugin/version is not published on WordPress.org.', 'wpav' );
		} else {
			$plugin['source']    = 'wporg';
			$plugin['checksums'] = $sums;
		}
	}

	private function status( array $progress, array $context ) {
		$components = isset( $context['themes'] ) ? count( $context['plugins'] ) + count( $context['themes'] ) : 0;
		$files_end  = 100 - ( $progress['scan_vulns'] ? 5 : 0 ) - ( $progress['scan_db'] ? 12 : 0 );

		if ( 'plugins' === $progress['phase'] ) {
			$percent = $components ? 5 * $progress['plugin_pos'] / $components : 5;
			/* translators: 1: current, 2: total */
			$message = sprintf( __( 'Fetching official plugin & theme checksums from WordPress.org (%1$d / %2$d)…', 'wpav' ), $progress['plugin_pos'], $components );
		} elseif ( 'files' === $progress['phase'] ) {
			$percent = 5 + ( $progress['total'] ? ( $files_end - 5 ) * $progress['pos'] / $progress['total'] : 0 );
			/* translators: 1: current, 2: total, 3: findings */
			$message = sprintf( __( 'Scanning files (%1$s / %2$s) — %3$d suspicious so far…', 'wpav' ), number_format_i18n( $progress['pos'] ), number_format_i18n( $progress['total'] ), count( $progress['findings'] ) );
		} elseif ( 'vulns' === $progress['phase'] ) {
			$percent = $files_end + 5 * $progress['vuln_pos'] / max( 1, $components + 1 );
			$message = __( 'Checking installed versions against the vulnerability database…', 'wpav' );
		} elseif ( 'database' === $progress['phase'] ) {
			$percent = 88 + 11 * WPAV_DB_Scanner::fraction( $progress['db'] );
			$stage   = isset( $progress['db']['stage'] ) ? $progress['db']['stage'] : 'posts';
			/* translators: %s: database table group */
			$message = sprintf( __( 'Scanning database (%s)…', 'wpav' ), $stage );
		} else {
			$percent = 100;
			$message = __( 'Scan complete.', 'wpav' );
		}
		return array(
			'scan_id' => $progress['scan_id'],
			'phase'   => $progress['phase'],
			'percent' => round( $percent, 1 ),
			'message' => $message,
			'done'    => 'done' === $progress['phase'],
		);
	}

	private function build_queue() {
		$exclude = array();
		$storage = WPAV_Storage::existing_dir();
		if ( $storage ) {
			$exclude[] = trailingslashit( $storage );
		}
		$patterns = WPAV_Settings::exclusions();
		$uploads  = wp_upload_dir( null, false );
		$uploads  = WPAV_Settings::get( 'scan_images' ) ? trailingslashit( wp_normalize_path( $uploads['basedir'] ) ) : '';
		$files    = array();
		foreach ( WPAV_Util::roots() as $root ) {
			$filter = new RecursiveCallbackFilterIterator(
				new RecursiveDirectoryIterator( $root, FilesystemIterator::SKIP_DOTS | FilesystemIterator::UNIX_PATHS ),
				static function ( $current ) use ( $exclude, $patterns ) {
					if ( ! $current->isDir() ) {
						return true;
					}
					if ( $current->isLink() || in_array( $current->getFilename(), array( '.git', '.svn' ), true ) ) {
						return false;
					}
					$dir = trailingslashit( wp_normalize_path( $current->getPathname() ) );
					if ( in_array( $dir, $exclude, true ) ) {
						return false;
					}
					return ! ( $patterns && WPAV_Settings::is_excluded( WPAV_Util::rel( $dir ), $patterns ) );
				}
			);
			$iterator = new RecursiveIteratorIterator( $filter, RecursiveIteratorIterator::LEAVES_ONLY, RecursiveIteratorIterator::CATCH_GET_CHILD );

			foreach ( $iterator as $file ) {
				if ( ! $file->isFile() ) {
					continue;
				}
				$path = wp_normalize_path( $file->getPathname() );
				if ( '' === WPAV_Util::file_kind( $path ) && ! ( $uploads && WPAV_Util::starts_with( $path, $uploads ) && '' !== WPAV_Util::media_kind( $path ) ) ) {
					continue;
				}
				if ( $patterns && WPAV_Settings::is_excluded( WPAV_Util::rel( $path ), $patterns ) ) {
					continue;
				}
				$files[ $path ] = true;
			}
		}
		return array_keys( $files );
	}

	private function init_dirs() {
		$uploads     = wp_upload_dir( null, false );
		$theme_roots = array();
		$registered  = isset( $GLOBALS['wp_theme_directories'] ) ? (array) $GLOBALS['wp_theme_directories'] : array( WP_CONTENT_DIR . '/themes' );
		foreach ( $registered as $dir ) {
			$theme_roots[] = trailingslashit( wp_normalize_path( $dir ) );
		}
		$this->dirs = array(
			'plugins' => trailingslashit( wp_normalize_path( WP_PLUGIN_DIR ) ),
			'mu'      => trailingslashit( wp_normalize_path( WPMU_PLUGIN_DIR ) ),
			'themes'  => $theme_roots,
			'uploads' => trailingslashit( wp_normalize_path( $uploads['basedir'] ) ),
			'abspath' => WPAV_Util::abspath(),
			'self'    => trailingslashit( wp_normalize_path( WPAV_DIR ) ),
		);
	}

	/**
	 * Which component a file belongs to, and its path relative to that component.
	 */
	private function classify( $path ) {
		$d = $this->dirs;

		if ( WPAV_Util::starts_with( $path, $d['plugins'] ) ) {
			$sub   = substr( $path, strlen( $d['plugins'] ) );
			$slash = strpos( $sub, '/' );
			if ( false === $slash ) {
				return array( 'type' => 'plugin', 'slug' => '', 'rel' => $sub );
			}
			return array( 'type' => 'plugin', 'slug' => substr( $sub, 0, $slash ), 'rel' => substr( $sub, $slash + 1 ) );
		}
		if ( WPAV_Util::starts_with( $path, $d['mu'] ) ) {
			return array( 'type' => 'mu-plugin', 'slug' => '', 'rel' => substr( $path, strlen( $d['mu'] ) ) );
		}
		foreach ( $d['themes'] as $root ) {
			if ( WPAV_Util::starts_with( $path, $root ) ) {
				$sub   = substr( $path, strlen( $root ) );
				$slash = strpos( $sub, '/' );
				return array(
					'type' => 'theme',
					'slug' => false === $slash ? '' : substr( $sub, 0, $slash ),
					'rel'  => false === $slash ? $sub : substr( $sub, $slash + 1 ),
				);
			}
		}
		if ( WPAV_Util::starts_with( $path, $d['uploads'] ) ) {
			return array( 'type' => 'upload', 'slug' => '', 'rel' => substr( $path, strlen( $d['uploads'] ) ) );
		}
		if ( WPAV_Util::starts_with( $path, $d['abspath'] ) ) {
			$rel = substr( $path, strlen( $d['abspath'] ) );
			if ( 0 === strpos( $rel, 'wp-admin/' ) || 0 === strpos( $rel, 'wp-includes/' ) ) {
				return array( 'type' => 'core', 'slug' => '', 'rel' => $rel );
			}
			// Root files: core only if WordPress ships them (wp-config.php, .htaccess etc. are site files).
			if ( false === strpos( $rel, '/' ) && ( empty( $this->ctx['core']['checksums'] ) || isset( $this->ctx['core']['checksums'][ $rel ] ) ) ) {
				return array( 'type' => 'core', 'slug' => '', 'rel' => $rel );
			}
		}
		return array( 'type' => 'other', 'slug' => '', 'rel' => WPAV_Util::rel( $path ) );
	}

	private function scan_file( $path, array &$progress ) {
		if ( ! is_file( $path ) || ! is_readable( $path ) ) {
			$progress['stats']['skipped']++;
			return null;
		}

		$class  = $this->classify( $path );
		$kind   = WPAV_Util::file_kind( $path );
		$sample = null;
		if ( '' === $kind ) {
			// Media file in uploads: only the head and tail are read (where payloads are hidden),
			// and a size-salted fingerprint replaces the full hash to keep large libraries fast.
			$kind = WPAV_Util::media_kind( $path );
			if ( 'image' === $kind ) {
				$sample = self::sample( $path );
			}
		}
		$is_php    = 'php' === $kind;
		$md5       = null !== $sample ? md5( filesize( $path ) . $sample ) : md5_file( $path );
		$issues    = array();
		$expected  = array();
		$component = '';
		$version   = '';
		$source    = 'custom';
		$count_key = '';

		switch ( $class['type'] ) {
			case 'core':
				$core      = $this->ctx['core'];
				$component = __( 'WordPress core', 'wpav' );
				$version   = $core['version'];
				$source    = 'core';
				$count_key = '__core';
				if ( ! empty( $core['checksums'] ) ) {
					if ( isset( $core['checksums'][ $class['rel'] ] ) ) {
						$expected = array_values( (array) $core['checksums'][ $class['rel'] ] );
					} else {
						// Unknown file inside wp-admin/ or wp-includes/.
						$issues[] = self::issue(
							'unknown',
							$is_php ? 'high' : 'medium',
							/* translators: %s: WordPress version */
							sprintf( __( 'File is not part of WordPress %s core', 'wpav' ), $version )
						);
					}
				}
				break;

			case 'plugin':
				$plugin    = isset( $this->ctx['plugins'][ $class['slug'] ] ) ? $this->ctx['plugins'][ $class['slug'] ] : null;
				$component = $plugin ? $plugin['name'] : ( $class['slug'] ? $class['slug'] : __( 'Single-file plugin', 'wpav' ) );
				$version   = $plugin ? $plugin['version'] : '';
				$source    = $plugin ? $plugin['source'] : 'custom';
				$count_key = $class['slug'];
				if ( $plugin && 'wporg' === $plugin['source'] ) {
					if ( isset( $plugin['checksums'][ $class['rel'] ] ) ) {
						$expected = $plugin['checksums'][ $class['rel'] ];
					} elseif ( $is_php ) {
						$issues[] = self::issue(
							'unknown',
							'medium',
							/* translators: 1: plugin name, 2: version */
							sprintf( __( 'File is not part of the official %1$s %2$s package', 'wpav' ), $component, $version )
						);
					}
				}
				break;

			case 'theme':
				$theme     = isset( $this->ctx['themes'][ $class['slug'] ] ) ? $this->ctx['themes'][ $class['slug'] ] : null;
				$component = $theme ? $theme['name'] : ( $class['slug'] ? $class['slug'] : __( 'Themes directory', 'wpav' ) );
				$version   = $theme ? $theme['version'] : '';
				$source    = $theme ? $theme['source'] : 'custom';
				$count_key = 'theme:' . $class['slug'];
				if ( $theme && 'wporg' === $theme['source'] ) {
					if ( isset( $theme['checksums'][ $class['rel'] ] ) ) {
						$expected = $theme['checksums'][ $class['rel'] ];
					} elseif ( $is_php ) {
						$issues[] = self::issue(
							'unknown',
							'medium',
							/* translators: 1: theme name, 2: version */
							sprintf( __( 'File is not part of the official %1$s %2$s theme package', 'wpav' ), $component, $version )
						);
					}
				}
				break;

			case 'mu-plugin':
				$component = __( 'Must-use plugins', 'wpav' );
				break;

			case 'upload':
				$component = __( 'Uploads', 'wpav' );
				if ( $is_php ) {
					$issues[] = self::issue( 'structure', 'high', __( 'PHP file inside the uploads directory', 'wpav' ) );
				}
				break;

			default:
				$component = false === strpos( $class['rel'], '/' ) ? __( 'Site root', 'wpav' ) : __( 'Other files', 'wpav' );
		}

		if ( $is_php ) {
			$base = basename( $path );
			if ( '.' === $base[0] ) {
				$issues[] = self::issue( 'structure', 'medium', __( 'Hidden PHP file (name starts with a dot)', 'wpav' ) );
			}
			if ( preg_match( '/\.(?:jpe?g|png|gif|ico|bmp|webp|svg|txt|pdf|zip|css)\.[a-z0-9]+$/i', $base ) ) {
				$issues[] = self::issue( 'structure', 'high', __( 'PHP file disguised with a media/text extension', 'wpav' ) );
			}
		}

		if ( $expected ) {
			if ( ! isset( $progress['plugin_counts'][ $count_key ] ) ) {
				$progress['plugin_counts'][ $count_key ] = array( 'checked' => 0, 'mismatched' => 0 );
			}
			$progress['plugin_counts'][ $count_key ]['checked']++;

			if ( in_array( $md5, $expected, true ) ) {
				$progress['stats']['scanned']++;
				$progress['stats']['verified']++;
				$this->hash_lines .= $md5 . ' v ' . $path . "\n";
				return null; // Byte-identical to the official file.
			}

			$progress['plugin_counts'][ $count_key ]['mismatched']++;
			$issues[] = self::issue(
				'modified',
				'high',
				/* translators: 1: component, 2: version */
				sprintf( __( 'Modified: differs from the official %1$s %2$s file', 'wpav' ), $component, $version )
			);
		}
		$this->hash_lines .= $md5 . ' - ' . $path . "\n";

		// This plugin's own code contains detection patterns; it is still covered by change detection.
		$is_self = WPAV_Util::starts_with( $path, $this->dirs['self'] );

		if ( null !== $sample ) {
			$issues = array_merge( $issues, WPAV_Signatures::scan( $sample, $kind ) );
		} elseif ( ! $is_self && filesize( $path ) <= $this->max_bytes ) {
			$content = @file_get_contents( $path ); // phpcs:ignore
			if ( false !== $content ) {
				$issues = array_merge( $issues, WPAV_Signatures::scan( $content, $kind ) );
			}
		}
		$progress['stats']['scanned']++;

		if ( ! $issues ) {
			return null;
		}

		return array(
			'key'        => $path,
			'path'       => $path,
			'rel'        => WPAV_Util::rel( $path ),
			'type'       => $class['type'],
			'slug'       => $class['slug'],
			'file_rel'   => $class['rel'],
			'component'  => $component,
			'version'    => $version,
			'source'     => $source,
			'locale'     => 'core' === $class['type'] ? $this->ctx['core']['locale'] : '',
			'repairable' => (bool) $expected,
			'expected'   => $expected,
			'md5'        => $md5,
			'issues'     => array_slice( $issues, 0, self::MAX_ISSUES ),
			'severity'   => WPAV_Util::max_severity( $issues ),
			'status'     => 'open',
		);
	}

	/**
	 * First and last 32 KB of a file.
	 */
	private static function sample( $path ) {
		$size   = (int) filesize( $path );
		$handle = @fopen( $path, 'rb' ); // phpcs:ignore
		if ( ! $handle ) {
			return '';
		}
		$data = (string) fread( $handle, 32768 ); // phpcs:ignore
		if ( $size > 65536 ) {
			fseek( $handle, -32768, SEEK_END );
			$data .= "\n" . fread( $handle, 32768 ); // phpcs:ignore
		} elseif ( $size > 32768 ) {
			$data .= (string) fread( $handle, $size ); // phpcs:ignore
		}
		fclose( $handle ); // phpcs:ignore
		return $data;
	}

	public static function issue( $kind, $severity, $title, $line = 0, $code = '' ) {
		return array(
			'kind'     => $kind,
			'rule'     => $kind,
			'title'    => $title,
			'severity' => $severity,
			'line'     => $line,
			'code'     => $code,
		);
	}

	private function flush_hashes() {
		if ( '' !== $this->hash_lines ) {
			file_put_contents( WPAV_Storage::dir() . '/' . self::HASHES, $this->hash_lines, FILE_APPEND | LOCK_EX ); // phpcs:ignore
			$this->hash_lines = '';
		}
	}

	/**
	 * Compare this scan's file hashes with the previous scan's baseline, then store the new baseline.
	 * Files verified against official checksums are known-good and are not reported as changes.
	 */
	private function file_changes() {
		$current = array();
		$raw     = @file_get_contents( WPAV_Storage::dir() . '/' . self::HASHES ); // phpcs:ignore
		foreach ( explode( "\n", (string) $raw ) as $line ) {
			if ( strlen( $line ) > 35 ) {
				$current[ substr( $line, 35 ) ] = substr( $line, 0, 32 ) . ( 'v' === $line[33] ? 'v' : '' );
			}
		}
		WPAV_Storage::delete( self::HASHES );

		$baseline = WPAV_Storage::read_json( self::BASELINE );
		WPAV_Storage::write_json( self::BASELINE, $current );
		if ( ! is_array( $baseline ) ) {
			return null;
		}

		$lists = array(
			'new'      => array(),
			'modified' => array(),
			'deleted'  => array(),
		);
		foreach ( $current as $path => $hash ) {
			if ( 'v' === substr( $hash, 32 ) ) {
				continue;
			}
			if ( ! isset( $baseline[ $path ] ) ) {
				$lists['new'][] = WPAV_Util::rel( $path );
			} elseif ( substr( $baseline[ $path ], 0, 32 ) !== substr( $hash, 0, 32 ) ) {
				$lists['modified'][] = WPAV_Util::rel( $path );
			}
		}
		foreach ( $baseline as $path => $hash ) {
			if ( ! isset( $current[ $path ] ) && 'v' !== substr( $hash, 32 ) ) {
				$lists['deleted'][] = WPAV_Util::rel( $path );
			}
		}

		$changes = array( 'lists' => array() );
		foreach ( $lists as $type => $paths ) {
			sort( $paths );
			$changes[ $type ]          = count( $paths );
			$changes['lists'][ $type ] = array_slice( $paths, 0, self::MAX_CHANGE_LIST );
		}
		return $changes;
	}

	private function finish( array &$progress, array $context ) {
		// Safety net: if most of a "WordPress.org" plugin differs from the official
		// version, it is almost certainly a fork/custom build sharing the slug — never overwrite it.
		$diverged = array();
		foreach ( $progress['plugin_counts'] as $key => $counts ) {
			if ( '__core' !== $key && $counts['mismatched'] >= 5 && $counts['mismatched'] > 0.5 * $counts['checked'] ) {
				$diverged[ $key ] = true;
			}
		}

		$previous  = WPAV_Results::load();
		$prev_keys = array();
		if ( $previous ) {
			foreach ( $previous['findings'] as $old ) {
				$prev_keys[ $old['key'] ] = true;
			}
		}
		$ignored = WPAV_Results::ignored();

		$findings = $progress['findings'];
		foreach ( $findings as &$finding ) {
			$finding['id']      = substr( md5( $finding['key'] ), 0, 12 );
			$finding['ignored'] = isset( $ignored[ $finding['key'] ] ) && $ignored[ $finding['key'] ]['md5'] === $finding['md5'];
			$finding['is_new']  = ! isset( $prev_keys[ $finding['key'] ] );
			if ( 'plugin' === $finding['type'] && isset( $diverged[ $finding['slug'] ] ) && $finding['repairable'] ) {
				$finding['repairable'] = false;
				$finding['note']       = __( 'Most files in this plugin differ from the WordPress.org version, so it looks like a customised or forked copy. Automatic repair is disabled; reinstall it manually if appropriate.', 'wpav' );
			}
			if ( 'theme' === $finding['type'] && isset( $diverged[ 'theme:' . $finding['slug'] ] ) && $finding['repairable'] ) {
				$finding['repairable'] = false;
				$finding['note']       = __( 'Most files in this theme differ from the WordPress.org version, so it looks like a customised copy. Automatic repair is disabled to protect your changes.', 'wpav' );
			}
		}
		unset( $finding );

		usort(
			$findings,
			static function ( $a, $b ) {
				$diff = WPAV_Util::severity_rank( $b['severity'] ) - WPAV_Util::severity_rank( $a['severity'] );
				return $diff ? $diff : strcmp( $a['rel'], $b['rel'] );
			}
		);

		$plugins = array();
		foreach ( $context['plugins'] as $slug => $plugin ) {
			$plugins[ $slug ] = array(
				'name'     => $plugin['name'],
				'version'  => $plugin['version'],
				'source'   => $plugin['source'],
				'note'     => $plugin['note'],
				'diverged' => isset( $diverged[ $slug ] ),
			);
		}
		$themes = array();
		foreach ( $context['themes'] as $slug => $theme ) {
			$themes[ $slug ] = array(
				'name'     => $theme['name'],
				'version'  => $theme['version'],
				'source'   => $theme['source'],
				'note'     => $theme['note'],
				'diverged' => isset( $diverged[ 'theme:' . $slug ] ),
			);
		}

		$results = array(
			'scan_id'     => $context['scan_id'],
			'origin'      => $this->origin,
			'started'     => $context['started'],
			'finished'    => time(),
			'wp_version'  => $context['core']['version'],
			'locale'      => $context['core']['locale'],
			'core_status' => empty( $context['core']['checksums'] ) ? 'unavailable' : 'verified',
			'db_scanned'  => $progress['scan_db'],
			'plugins'     => $plugins,
			'themes'      => $themes,
			'changes'     => $this->file_changes(),
			'stats'       => array_merge( $progress['stats'], array( 'total' => $progress['total'] ) ),
			'findings'    => $findings,
		);
		WPAV_Results::recount( $results );
		WPAV_Results::save( $results );

		WPAV_History::add( $results );
		WPAV_Log::add(
			__( 'Scan completed', 'wpav' ),
			'',
			/* translators: 1: files, 2: issues */
			sprintf( __( '%1$d files, %2$d active issues', 'wpav' ), $results['stats']['scanned'], $results['stats']['findings'] )
		);

		WPAV_Storage::delete( self::QUEUE );
		WPAV_Storage::delete( self::CONTEXT );
		$progress['phase']    = 'done';
		$progress['findings'] = array();

		/**
		 * Fires after a scan completes and its report is saved.
		 *
		 * @param array  $results Scan report.
		 * @param string $origin  manual|cron|cli.
		 */
		do_action( 'wpav_scan_finished', $results, $this->origin );
	}
}
