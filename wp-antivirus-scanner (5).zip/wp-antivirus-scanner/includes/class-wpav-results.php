<?php
/**
 * Access to the last completed scan report and the "ignored" (marked safe) list.
 *
 * @package WPAV
 */

defined( 'ABSPATH' ) || exit;

class WPAV_Results {

	const FILE    = 'results.json';
	const IGNORED = 'ignored.json';
	const SUMMARY = 'wpav_summary';

	public static function load() {
		$results = WPAV_Storage::read_json( self::FILE );
		if ( ! $results ) {
			return null;
		}
		foreach ( $results['findings'] as &$finding ) {
			$finding = self::normalize( $finding );
		}
		unset( $finding );
		return $results;
	}

	/**
	 * Fill fields missing from reports written by older versions.
	 */
	private static function normalize( array $finding ) {
		return array_merge(
			array(
				'key'     => isset( $finding['path'] ) ? $finding['path'] : '',
				'md5'     => '',
				'ignored' => false,
				'is_new'  => false,
				'status'  => 'open',
				'note'    => '',
			),
			$finding
		);
	}

	public static function save( array $results ) {
		update_site_option(
			self::SUMMARY,
			array(
				'finished' => $results['finished'],
				'stats'    => $results['stats'],
			)
		);
		return WPAV_Storage::write_json( self::FILE, $results );
	}

	/**
	 * Lightweight copy of the latest stats (for the menu badge and dashboard widget).
	 */
	public static function summary() {
		$summary = get_site_option( self::SUMMARY );
		return is_array( $summary ) && isset( $summary['stats']['by_severity'] ) ? $summary : null;
	}

	public static function find( $id ) {
		$results = self::load();
		if ( empty( $results['findings'] ) ) {
			return null;
		}
		foreach ( $results['findings'] as $finding ) {
			if ( $finding['id'] === $id ) {
				return $finding;
			}
		}
		return null;
	}

	public static function update( $id, array $changes ) {
		$results = self::load();
		if ( empty( $results['findings'] ) ) {
			return false;
		}
		foreach ( $results['findings'] as &$finding ) {
			if ( $finding['id'] === $id ) {
				$finding = array_merge( $finding, $changes );
			}
		}
		unset( $finding );
		self::recount( $results );
		return self::save( $results );
	}

	/**
	 * Recompute summary counters. Only open, non-ignored findings count as "active".
	 */
	public static function recount( array &$results ) {
		$by_severity   = array_fill_keys( array_keys( WPAV_Util::SEVERITY_RANK ), 0 );
		$active        = 0;
		$repairable    = 0;
		$quarantinable = 0;
		$ignored       = 0;
		$resolved      = 0;
		$database      = 0;
		$new           = 0;

		foreach ( $results['findings'] as $finding ) {
			if ( 'open' !== $finding['status'] ) {
				$resolved++;
				continue;
			}
			if ( ! empty( $finding['ignored'] ) ) {
				$ignored++;
				continue;
			}
			$active++;
			$by_severity[ $finding['severity'] ]++;
			if ( $finding['repairable'] ) {
				$repairable++;
			}
			if ( WPAV_Util::can_quarantine( $finding ) ) {
				$quarantinable++;
			}
			if ( 'database' === $finding['type'] ) {
				$database++;
			}
			if ( ! empty( $finding['is_new'] ) ) {
				$new++;
			}
		}

		$results['stats'] = array_merge(
			isset( $results['stats'] ) ? $results['stats'] : array(),
			array(
				'findings'      => $active,
				'by_severity'   => $by_severity,
				'repairable'    => $repairable,
				'quarantinable' => $quarantinable,
				'ignored'       => $ignored,
				'resolved'      => $resolved,
				'database'      => $database,
				'new'           => $new,
			)
		);
	}

	/**
	 * After a backup is restored, the finding it resolved is open again.
	 */
	public static function reopen_by_backup( $backup_id ) {
		$results = self::load();
		if ( empty( $results['findings'] ) ) {
			return;
		}
		foreach ( $results['findings'] as $finding ) {
			if ( isset( $finding['backup_id'] ) && $finding['backup_id'] === $backup_id ) {
				self::update( $finding['id'], array( 'status' => 'open' ) );
			}
		}
	}

	public static function ignored() {
		return WPAV_Storage::read_json( self::IGNORED, array() );
	}

	/**
	 * Mark a finding as safe. It reappears automatically if the file/content changes (md5 differs).
	 */
	public static function ignore( $id ) {
		$finding = self::find( $id );
		if ( ! $finding ) {
			return new WP_Error( 'wpav_not_found', __( 'Finding not found. Run a new scan.', 'wpav' ) );
		}
		$list                    = self::ignored();
		$list[ $finding['key'] ] = array(
			'md5'  => $finding['md5'],
			'rel'  => $finding['rel'],
			'time' => time(),
			'user' => get_current_user_id(),
		);
		WPAV_Storage::write_json( self::IGNORED, $list );
		self::update( $id, array( 'ignored' => true ) );
		WPAV_Log::add( __( 'Marked as safe', 'wpav' ), $finding['rel'] );
		return array( 'message' => __( 'Marked as safe.', 'wpav' ) );
	}

	public static function unignore( $id ) {
		$finding = self::find( $id );
		if ( ! $finding ) {
			return new WP_Error( 'wpav_not_found', __( 'Finding not found. Run a new scan.', 'wpav' ) );
		}
		$list = self::ignored();
		unset( $list[ $finding['key'] ] );
		WPAV_Storage::write_json( self::IGNORED, $list );
		self::update( $id, array( 'ignored' => false ) );
		WPAV_Log::add( __( 'Stopped ignoring', 'wpav' ), $finding['rel'] );
		return array( 'message' => __( 'No longer ignored.', 'wpav' ) );
	}
}
