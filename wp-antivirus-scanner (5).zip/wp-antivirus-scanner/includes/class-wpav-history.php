<?php
/**
 * Summary of recent scans.
 *
 * @package WPAV
 */

defined( 'ABSPATH' ) || exit;

class WPAV_History {

	const FILE = 'history.json';
	const MAX  = 30;

	public static function all() {
		return WPAV_Storage::read_json( self::FILE, array() );
	}

	public static function add( array $results ) {
		$history = self::all();
		array_unshift(
			$history,
			array(
				'finished'    => $results['finished'],
				'duration'    => $results['finished'] - $results['started'],
				'origin'      => $results['origin'],
				'scanned'     => $results['stats']['scanned'],
				'findings'    => $results['stats']['findings'],
				'new'         => $results['stats']['new'],
				'by_severity' => $results['stats']['by_severity'],
				'changes'     => $results['changes'] ? array(
					'new'      => $results['changes']['new'],
					'modified' => $results['changes']['modified'],
					'deleted'  => $results['changes']['deleted'],
				) : null,
			)
		);
		WPAV_Storage::write_json( self::FILE, array_slice( $history, 0, self::MAX ) );
	}
}
