<?php
/**
 * File backups taken before any file is replaced or restored.
 *
 * Backups are stored as opaque .bak files (never executable) with a JSON manifest
 * recording where each one came from.
 *
 * @package WPAV
 */

defined( 'ABSPATH' ) || exit;

class WPAV_Backup {

	const MANIFEST = 'manifest.json';

	private static function dir() {
		return WPAV_Storage::dir( 'backups' );
	}

	public static function all() {
		$file = self::dir() . '/' . self::MANIFEST;
		if ( ! is_readable( $file ) ) {
			return array();
		}
		$data = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore
		return is_array( $data ) ? $data : array();
	}

	private static function save( array $entries ) {
		return false !== file_put_contents( // phpcs:ignore
			self::dir() . '/' . self::MANIFEST,
			wp_json_encode( array_values( $entries ), JSON_UNESCAPED_SLASHES ),
			LOCK_EX
		);
	}

	public static function get( $id ) {
		foreach ( self::all() as $entry ) {
			if ( $entry['id'] === $id ) {
				return $entry;
			}
		}
		return null;
	}

	/**
	 * @return array|WP_Error Manifest entry.
	 */
	public static function create( $path, $reason ) {
		$path = wp_normalize_path( $path );
		if ( ! is_file( $path ) || ! is_readable( $path ) ) {
			return new WP_Error( 'wpav_backup_read', __( 'The file to back up could not be read.', 'wpav' ) );
		}

		$id   = gmdate( 'Ymd-His' ) . '-' . strtolower( wp_generate_password( 8, false, false ) );
		$dest = self::dir() . '/' . $id . '.bak';

		if ( ! @copy( $path, $dest ) || md5_file( $dest ) !== md5_file( $path ) ) { // phpcs:ignore
			@unlink( $dest ); // phpcs:ignore
			return new WP_Error( 'wpav_backup_write', __( 'The backup could not be created, so the file was not changed. Check that the uploads directory is writable.', 'wpav' ) );
		}

		$entry = array(
			'id'     => $id,
			'path'   => $path,
			'rel'    => WPAV_Util::rel( $path ),
			'time'   => time(),
			'size'   => filesize( $path ),
			'md5'    => md5_file( $path ),
			'reason' => $reason,
		);

		$entries   = self::all();
		$entries[] = $entry;
		if ( ! self::save( $entries ) ) {
			@unlink( $dest ); // phpcs:ignore
			return new WP_Error( 'wpav_backup_manifest', __( 'The backup manifest could not be written, so the file was not changed.', 'wpav' ) );
		}
		return $entry;
	}

	/**
	 * Put a backup back in place. The current file is backed up first.
	 */
	public static function restore( $id ) {
		$entry = self::get( $id );
		if ( ! $entry ) {
			return new WP_Error( 'wpav_backup_missing', __( 'Backup not found.', 'wpav' ) );
		}
		$source = self::dir() . '/' . $entry['id'] . '.bak';
		if ( ! is_readable( $source ) ) {
			return new WP_Error( 'wpav_backup_missing', __( 'The backup file is missing.', 'wpav' ) );
		}
		if ( ! WPAV_Util::is_allowed_path( $entry['path'] ) ) {
			return new WP_Error( 'wpav_path', __( 'The original path is outside the WordPress installation.', 'wpav' ) );
		}
		if ( ! WPAV_Repair::can_modify() ) {
			return new WP_Error( 'wpav_file_mods', __( 'File modifications are disabled on this site (DISALLOW_FILE_MODS).', 'wpav' ) );
		}

		if ( is_file( $entry['path'] ) ) {
			$pre = self::create( $entry['path'], __( 'Before restoring backup', 'wpav' ) . ' ' . $entry['id'] );
			if ( is_wp_error( $pre ) ) {
				return $pre;
			}
		}

		if ( ! @copy( $source, $entry['path'] ) ) { // phpcs:ignore
			return new WP_Error( 'wpav_restore_write', __( 'The file could not be written. Check file permissions.', 'wpav' ) );
		}
		if ( function_exists( 'opcache_invalidate' ) ) {
			@opcache_invalidate( $entry['path'], true ); // phpcs:ignore
		}
		WPAV_Log::add( __( 'Restored backup', 'wpav' ), $entry['rel'], $entry['id'] );
		return $entry;
	}

	public static function delete( $id ) {
		$entries = self::all();
		$kept    = array();
		$found   = false;
		foreach ( $entries as $entry ) {
			if ( $entry['id'] === $id ) {
				$found = true;
				WPAV_Log::add( __( 'Deleted backup', 'wpav' ), $entry['rel'], $entry['id'] );
				@unlink( self::dir() . '/' . $entry['id'] . '.bak' ); // phpcs:ignore
			} else {
				$kept[] = $entry;
			}
		}
		if ( ! $found ) {
			return new WP_Error( 'wpav_backup_missing', __( 'Backup not found.', 'wpav' ) );
		}
		self::save( $kept );
		return true;
	}

	public static function valid_id( $id ) {
		return is_string( $id ) && (bool) preg_match( '/^\d{8}-\d{6}-[a-z0-9]{8}$/', $id );
	}
}
