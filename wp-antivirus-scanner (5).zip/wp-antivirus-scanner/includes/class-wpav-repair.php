<?php
/**
 * Replaces infected core / WordPress.org plugin files with verified originals.
 *
 * @package WPAV
 */

defined( 'ABSPATH' ) || exit;

class WPAV_Repair {

	public static function can_modify() {
		return ! ( defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS );
	}

	/**
	 * @return array|WP_Error
	 */
	public static function repair( $id ) {
		$finding = WPAV_Results::find( $id );
		if ( ! $finding ) {
			return new WP_Error( 'wpav_not_found', __( 'Finding not found. Run a new scan.', 'wpav' ) );
		}
		if ( 'repaired' === $finding['status'] ) {
			return array( 'message' => __( 'Already repaired.', 'wpav' ) );
		}
		if ( empty( $finding['repairable'] ) ) {
			return new WP_Error( 'wpav_report_only', WPAV_Util::manual_reason( $finding ) );
		}
		if ( ! self::can_modify() ) {
			return new WP_Error( 'wpav_file_mods', __( 'File modifications are disabled on this site (DISALLOW_FILE_MODS).', 'wpav' ) );
		}

		$path = $finding['path'];
		if ( ! WPAV_Util::is_allowed_path( $path ) ) {
			return new WP_Error( 'wpav_path', __( 'The file is outside the WordPress installation.', 'wpav' ) );
		}

		// Already clean (e.g. fixed by an update since the scan)?
		if ( is_file( $path ) && in_array( md5_file( $path ), $finding['expected'], true ) ) {
			WPAV_Results::update( $id, array( 'status' => 'repaired', 'repaired_at' => time() ) );
			return array( 'message' => __( 'File already matches the official version.', 'wpav' ) );
		}

		$clean = WPAV_Source::original( $finding );
		if ( is_wp_error( $clean ) ) {
			return $clean;
		}

		$backup_id = '';
		$perms     = null;
		if ( is_file( $path ) ) {
			$backup = WPAV_Backup::create( $path, __( 'Before repair', 'wpav' ) );
			if ( is_wp_error( $backup ) ) {
				return $backup;
			}
			$backup_id = $backup['id'];
			$perms     = fileperms( $path ) & 0777;
		}

		if ( false === @file_put_contents( $path, $clean, LOCK_EX ) ) { // phpcs:ignore
			return new WP_Error( 'wpav_write', __( 'The file could not be written. Check file permissions (a backup was kept).', 'wpav' ) );
		}
		if ( null !== $perms ) {
			@chmod( $path, $perms ); // phpcs:ignore
		}
		clearstatcache( true, $path );
		if ( md5_file( $path ) !== md5( $clean ) ) {
			return new WP_Error( 'wpav_verify', __( 'The file was written but verification failed. Restore it from Backups if needed.', 'wpav' ) );
		}
		if ( function_exists( 'opcache_invalidate' ) ) {
			@opcache_invalidate( $path, true ); // phpcs:ignore
		}

		WPAV_Results::update(
			$id,
			array(
				'status'      => 'repaired',
				'repaired_at' => time(),
				'backup_id'   => $backup_id,
			)
		);

		WPAV_Log::add( __( 'Repaired file', 'wpav' ), $finding['rel'], 'backup ' . $backup_id );
		return array(
			'message' => __( 'Repaired with the official file (backup saved).', 'wpav' ),
			'backup'  => $backup_id,
		);
	}

	/**
	 * Move a file that should not exist into the backup store (restorable from Backups).
	 *
	 * @return array|WP_Error
	 */
	public static function quarantine( $id ) {
		$finding = WPAV_Results::find( $id );
		if ( ! $finding ) {
			return new WP_Error( 'wpav_not_found', __( 'Finding not found. Run a new scan.', 'wpav' ) );
		}
		if ( 'quarantined' === $finding['status'] ) {
			return array( 'message' => __( 'Already quarantined.', 'wpav' ) );
		}
		if ( ! WPAV_Util::can_quarantine( $finding ) ) {
			return new WP_Error( 'wpav_no_quarantine', WPAV_Util::manual_reason( $finding ) );
		}
		if ( ! self::can_modify() ) {
			return new WP_Error( 'wpav_file_mods', __( 'File modifications are disabled on this site (DISALLOW_FILE_MODS).', 'wpav' ) );
		}

		$path = $finding['path'];
		if ( ! WPAV_Util::is_allowed_path( $path ) ) {
			return new WP_Error( 'wpav_path', __( 'The file is outside the WordPress installation.', 'wpav' ) );
		}
		if ( ! is_file( $path ) ) {
			WPAV_Results::update( $id, array( 'status' => 'quarantined' ) );
			return array( 'message' => __( 'File no longer exists.', 'wpav' ) );
		}

		$backup = WPAV_Backup::create( $path, __( 'Quarantined', 'wpav' ) );
		if ( is_wp_error( $backup ) ) {
			return $backup;
		}
		if ( ! @unlink( $path ) ) { // phpcs:ignore
			return new WP_Error( 'wpav_unlink', __( 'The file could not be removed. Check file permissions (a copy was saved to Backups).', 'wpav' ) );
		}
		if ( function_exists( 'opcache_invalidate' ) ) {
			@opcache_invalidate( $path, true ); // phpcs:ignore
		}

		WPAV_Results::update(
			$id,
			array(
				'status'      => 'quarantined',
				'repaired_at' => time(),
				'backup_id'   => $backup['id'],
			)
		);
		WPAV_Log::add( __( 'Quarantined file', 'wpav' ), $finding['rel'], 'backup ' . $backup['id'] );
		return array(
			'message' => __( 'Quarantined (moved to Backups).', 'wpav' ),
			'backup'  => $backup['id'],
		);
	}
}
