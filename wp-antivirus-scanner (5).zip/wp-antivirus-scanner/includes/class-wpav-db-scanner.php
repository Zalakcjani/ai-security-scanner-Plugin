<?php
/**
 * Database phase of the scan. For every site (all sites on multisite):
 * posts, post meta (page-builder content), approved comments, options,
 * scheduled-task arguments and site URLs; then administrator accounts,
 * including admins hidden from the Users screen.
 *
 * Database findings are report-only (they are never changed automatically).
 *
 * @package WPAV
 */

defined( 'ABSPATH' ) || exit;

class WPAV_DB_Scanner {

	const BATCH          = 200;
	const MAX_SITES      = 500;
	const NEW_ADMIN_DAYS = 7;

	const STAGES = array( 'posts', 'postmeta', 'comments', 'options', 'site' );

	const CONTENT_NEEDLES = array( '<script', '<iframe', 'eval(', 'fromCharCode', 'atob(', 'document.write', 'display:none', 'display: none', 'visibility:hidden', '_0x' );
	const OPTION_NEEDLES  = array( '<script', '<iframe', 'eval(', 'base64_decode', 'gzinflate', 'str_rot13', 'fromCharCode', 'atob(', 'display:none' );

	/**
	 * Work until the deadline. Returns true once the database phase is complete.
	 */
	public static function step( array &$progress, $deadline ) {
		if ( empty( $progress['db'] ) ) {
			$progress['db'] = array(
				'blogs' => is_multisite() ? array_map( 'intval', get_sites( array( 'fields' => 'ids', 'number' => self::MAX_SITES ) ) ) : array( get_current_blog_id() ),
				'bi'    => 0,
				'stage' => 'posts',
				'last'  => 0,
			);
		}
		$db = &$progress['db'];

		while ( ! in_array( $db['stage'], array( 'users', 'done' ), true ) && microtime( true ) < $deadline ) {
			$blog     = $db['blogs'][ $db['bi'] ];
			$switched = is_multisite() && get_current_blog_id() !== $blog;
			if ( $switched ) {
				switch_to_blog( $blog );
			}

			$more = false;
			switch ( $db['stage'] ) {
				case 'posts':
					$more = self::posts( $db, $progress, $blog ) > 0;
					break;
				case 'postmeta':
					$more = self::postmeta( $db, $progress, $blog ) > 0;
					break;
				case 'comments':
					$more = self::comments( $db, $progress, $blog ) > 0;
					break;
				case 'options':
					$more = self::options( $db, $progress, $blog ) > 0;
					break;
				case 'site':
					self::site_urls( $progress, $blog );
					self::cron_events( $progress, $blog );
					break;
			}

			if ( $switched ) {
				restore_current_blog();
			}

			if ( ! $more ) {
				$db['last'] = 0;
				$next       = array_search( $db['stage'], self::STAGES, true ) + 1;
				if ( $next < count( self::STAGES ) ) {
					$db['stage'] = self::STAGES[ $next ];
				} elseif ( ++$db['bi'] < count( $db['blogs'] ) ) {
					$db['stage'] = 'posts';
				} else {
					$db['stage'] = 'users';
				}
			}
		}

		if ( 'users' === $db['stage'] ) {
			self::admins( $progress, $db['blogs'] );
			$db['stage'] = 'done';
		}
		return 'done' === $db['stage'];
	}

	/**
	 * Progress within the database phase, 0..1.
	 */
	public static function fraction( $db ) {
		if ( empty( $db['blogs'] ) ) {
			return 0;
		}
		if ( in_array( $db['stage'], array( 'users', 'done' ), true ) ) {
			return 1;
		}
		$stage = (int) array_search( $db['stage'], self::STAGES, true );
		return ( $db['bi'] + $stage / count( self::STAGES ) ) / count( $db['blogs'] );
	}

	private static function like_clause( $column, array $needles, array &$args ) {
		global $wpdb;
		$parts = array();
		foreach ( $needles as $needle ) {
			$parts[] = "{$column} LIKE %s";
			$args[]  = '%' . $wpdb->esc_like( $needle ) . '%';
		}
		return '(' . implode( ' OR ', $parts ) . ')';
	}

	/**
	 * Scan text; JSON/slashed page-builder data is also checked unescaped.
	 */
	private static function scan_text( $text, $kinds ) {
		$issues = WPAV_Signatures::scan( $text, $kinds );
		if ( ! $issues && false !== strpos( $text, '\\' ) ) {
			$issues = WPAV_Signatures::scan( stripslashes( $text ), $kinds );
		}
		return $issues;
	}

	private static function posts( array &$db, array &$progress, $blog ) {
		global $wpdb;

		$args   = array( (int) $db['last'] );
		$where  = self::like_clause( 'post_content', self::CONTENT_NEEDLES, $args );
		$args[] = self::BATCH;

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_title, post_type, post_status, post_content FROM {$wpdb->posts} WHERE ID > %d AND post_type <> 'revision' AND {$where} ORDER BY ID ASC LIMIT %d", $args ) );

		foreach ( (array) $rows as $row ) {
			$db['last'] = (int) $row->ID;
			$progress['stats']['db_rows']++;
			$issues = self::scan_text( $row->post_content, 'db' );
			if ( $issues ) {
				$title                  = '' !== $row->post_title ? $row->post_title : __( '(no title)', 'wpav' );
				$progress['findings'][] = self::finding(
					"db:{$blog}:posts:{$row->ID}",
					sprintf( '%s #%d — %s', $wpdb->posts, $row->ID, wp_html_excerpt( $title, 80, '…' ) ),
					/* translators: 1: post type, 2: post status */
					sprintf( __( 'Content (%1$s, %2$s)', 'wpav' ), $row->post_type, $row->post_status ),
					$issues,
					md5( $row->post_content ),
					array( 'table' => 'posts', 'id' => (int) $row->ID, 'blog' => $blog )
				);
			}
		}
		return count( (array) $rows );
	}

	private static function postmeta( array &$db, array &$progress, $blog ) {
		global $wpdb;

		$args   = array( (int) $db['last'] );
		$where  = self::like_clause( 'meta_value', self::CONTENT_NEEDLES, $args );
		$args[] = self::BATCH;

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT meta_id, post_id, meta_key, meta_value FROM {$wpdb->postmeta} WHERE meta_id > %d AND {$where} ORDER BY meta_id ASC LIMIT %d", $args ) );

		foreach ( (array) $rows as $row ) {
			$db['last'] = (int) $row->meta_id;
			$progress['stats']['db_rows']++;
			$issues = self::scan_text( $row->meta_value, array( 'db', 'php' ) );
			if ( $issues ) {
				$progress['findings'][] = self::finding(
					"db:{$blog}:postmeta:{$row->meta_id}",
					sprintf( '%s #%d — %s (post #%d)', $wpdb->postmeta, $row->meta_id, $row->meta_key, $row->post_id ),
					__( 'Post meta (page builder / custom field)', 'wpav' ),
					$issues,
					md5( $row->meta_value ),
					array( 'table' => 'posts', 'id' => (int) $row->post_id, 'blog' => $blog )
				);
			}
		}
		return count( (array) $rows );
	}

	private static function comments( array &$db, array &$progress, $blog ) {
		global $wpdb;

		$args   = array( (int) $db['last'] );
		$where  = self::like_clause( 'comment_content', self::CONTENT_NEEDLES, $args );
		$args[] = self::BATCH;

		// Only approved comments are rendered to visitors; spam/pending are expected to contain junk.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT comment_ID, comment_post_ID, comment_author, comment_content FROM {$wpdb->comments} WHERE comment_ID > %d AND comment_approved = '1' AND {$where} ORDER BY comment_ID ASC LIMIT %d", $args ) );

		foreach ( (array) $rows as $row ) {
			$db['last'] = (int) $row->comment_ID;
			$progress['stats']['db_rows']++;
			$issues = WPAV_Signatures::scan( $row->comment_content, 'db' );
			if ( $issues ) {
				$progress['findings'][] = self::finding(
					"db:{$blog}:comments:{$row->comment_ID}",
					sprintf( '%s #%d — %s', $wpdb->comments, $row->comment_ID, wp_html_excerpt( $row->comment_author, 60, '…' ) ),
					__( 'Approved comment', 'wpav' ),
					$issues,
					md5( $row->comment_content ),
					array( 'table' => 'comments', 'id' => (int) $row->comment_ID, 'blog' => $blog )
				);
			}
		}
		return count( (array) $rows );
	}

	private static function options( array &$db, array &$progress, $blog ) {
		global $wpdb;

		$args   = array(
			(int) $db['last'],
			$wpdb->esc_like( '_transient_' ) . '%',
			$wpdb->esc_like( '_site_transient_' ) . '%',
			$wpdb->esc_like( 'wpav_' ) . '%',
		);
		$where  = self::like_clause( 'option_value', self::OPTION_NEEDLES, $args );
		$args[] = self::BATCH;

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT option_id, option_name, option_value FROM {$wpdb->options} WHERE option_id > %d AND option_name NOT LIKE %s AND option_name NOT LIKE %s AND option_name NOT LIKE %s AND option_name <> 'cron' AND {$where} ORDER BY option_id ASC LIMIT %d", $args ) );

		foreach ( (array) $rows as $row ) {
			$db['last'] = (int) $row->option_id;
			$progress['stats']['db_rows']++;
			$issues = self::scan_text( $row->option_value, array( 'db', 'php' ) );
			if ( $issues ) {
				$progress['findings'][] = self::finding(
					"db:{$blog}:options:{$row->option_name}",
					sprintf( '%s — %s', $wpdb->options, $row->option_name ),
					__( 'Option', 'wpav' ),
					$issues,
					md5( $row->option_value ),
					array( 'table' => 'options', 'name' => $row->option_name, 'blog' => $blog )
				);
			}
		}
		return count( (array) $rows );
	}

	/**
	 * Malware often rewrites siteurl/home to inject a script or redirect.
	 */
	private static function site_urls( array &$progress, $blog ) {
		global $wpdb;
		foreach ( array( 'siteurl', 'home' ) as $name ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$value = (string) $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $name ) );
			if ( '' !== $value && ! preg_match( '#^https?://[^\s<>"\'`]+$#i', $value ) ) {
				$progress['findings'][] = self::finding(
					"db:{$blog}:options:{$name}",
					sprintf( '%s — %s', $wpdb->options, $name ),
					__( 'Option', 'wpav' ),
					array( WPAV_Scanner::issue( 'db', 'critical', __( 'Site URL option contains code or an invalid value (site hijack)', 'wpav' ), 1, WPAV_Util::clean_text( WPAV_Util::truncate( $value ) ) ) ),
					md5( $value ),
					array( 'table' => 'options', 'name' => $name, 'blog' => $blog )
				);
			}
		}
	}

	/**
	 * Scheduled tasks whose arguments carry code (a common re-infection mechanism).
	 */
	private static function cron_events( array &$progress, $blog ) {
		foreach ( WPAV_Cleanup::cron_events() as $event ) {
			if ( ! $event['args_issues'] ) {
				continue;
			}
			$progress['findings'][] = self::finding(
				"db:{$blog}:cron:{$event['id']}",
				/* translators: %s: hook name */
				sprintf( __( 'Scheduled task “%s”', 'wpav' ), $event['hook'] ),
				__( 'Scheduled task (WP-Cron)', 'wpav' ),
				$event['args_issues'],
				$event['id'],
				array( 'table' => 'cron', 'blog' => $blog )
			);
		}
	}

	/**
	 * Flag administrators hidden from the Users screen (read straight from usermeta,
	 * bypassing the pre_user_query filters malware abuses) and recently created admins.
	 */
	private static function admins( array &$progress, array $blogs ) {
		$cutoff = time() - self::NEW_ADMIN_DAYS * DAY_IN_SECONDS;
		foreach ( WPAV_Cleanup::administrators( $blogs ) as $admin ) {
			$user_line = sprintf( '%s <%s> — %s UTC', $admin['login'], $admin['email'], $admin['registered'] );
			if ( $admin['hidden'] ) {
				$issue = WPAV_Scanner::issue( 'db', 'critical', __( 'Administrator hidden from the Users screen (backdoor account)', 'wpav' ), 0, $user_line );
			} elseif ( $admin['registered_ts'] > $cutoff ) {
				/* translators: %d: days */
				$issue = WPAV_Scanner::issue( 'db', 'medium', sprintf( __( 'Administrator account created in the last %d days — confirm you created it', 'wpav' ), self::NEW_ADMIN_DAYS ), 0, $user_line );
			} else {
				continue;
			}
			$progress['findings'][] = self::finding(
				'db:users:' . $admin['id'],
				/* translators: %s: user login */
				sprintf( __( 'Administrator “%s”', 'wpav' ), $admin['login'] ),
				__( 'User account', 'wpav' ),
				array( $issue ),
				md5( $admin['login'] . $admin['registered'] . (int) $admin['hidden'] ),
				array( 'table' => 'users', 'id' => $admin['id'] )
			);
		}
	}

	private static function finding( $key, $label, $component, array $issues, $md5, array $meta ) {
		return array(
			'key'        => $key,
			'path'       => '',
			'rel'        => $label,
			'type'       => 'database',
			'slug'       => '',
			'file_rel'   => '',
			'component'  => $component,
			'version'    => '',
			'source'     => 'database',
			'locale'     => '',
			'repairable' => false,
			'expected'   => array(),
			'md5'        => $md5,
			'db'         => $meta,
			'issues'     => array_slice( $issues, 0, WPAV_Scanner::MAX_ISSUES ),
			'severity'   => WPAV_Util::max_severity( $issues ),
			'status'     => 'open',
		);
	}

	/**
	 * Admin link to inspect / clean a database finding.
	 */
	public static function edit_url( array $finding ) {
		if ( empty( $finding['db'] ) ) {
			return '';
		}
		$db   = $finding['db'];
		$blog = isset( $db['blog'] ) ? (int) $db['blog'] : null;
		switch ( $db['table'] ) {
			case 'posts':
				return get_admin_url( $blog, 'post.php?post=' . (int) $db['id'] . '&action=edit' );
			case 'comments':
				return get_admin_url( $blog, 'comment.php?action=editcomment&c=' . (int) $db['id'] );
			case 'users':
			case 'cron':
				return WPAV_Util::page_url( 'wpav-cleanup' );
		}
		return '';
	}
}
