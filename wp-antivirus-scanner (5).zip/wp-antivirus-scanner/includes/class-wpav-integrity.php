<?php
/**
 * Official checksums from WordPress.org for the installed core and plugin versions.
 *
 * @package WPAV
 */

defined( 'ABSPATH' ) || exit;

class WPAV_Integrity {

	/**
	 * Core version, locale and checksums (relative path => md5), excluding wp-content/
	 * (bundled themes/plugins are updated independently of core).
	 */
	public static function core_info() {
		global $wp_version, $wp_local_package;

		$locale = empty( $wp_local_package ) ? 'en_US' : $wp_local_package;
		if ( ! function_exists( 'get_core_checksums' ) ) {
			require_once ABSPATH . 'wp-admin/includes/update.php';
		}

		$checksums = get_core_checksums( $wp_version, $locale );
		if ( ! is_array( $checksums ) && 'en_US' !== $locale ) {
			$checksums = get_core_checksums( $wp_version, 'en_US' );
		}

		$filtered = array();
		if ( is_array( $checksums ) ) {
			foreach ( $checksums as $path => $md5 ) {
				if ( 0 !== strpos( $path, 'wp-content/' ) ) {
					$filtered[ $path ] = $md5;
				}
			}
		}

		return array(
			'version'   => $wp_version,
			'locale'    => $locale,
			'checksums' => $filtered ? $filtered : null,
		);
	}

	/**
	 * Installed plugins keyed by directory slug. Single-file plugins are skipped
	 * (they are treated as custom code).
	 */
	public static function installed_plugins() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugins = array();
		foreach ( get_plugins() as $file => $data ) {
			$slug = dirname( $file );
			if ( '.' === $slug || isset( $plugins[ $slug ] ) ) {
				continue;
			}

			$source = 'pending';
			$note   = '';
			$uri    = isset( $data['UpdateURI'] ) ? trim( $data['UpdateURI'] ) : '';
			if ( '' !== $uri ) {
				$host = wp_parse_url( $uri, PHP_URL_HOST );
				if ( ! in_array( $host, array( 'w.org', 'wordpress.org' ), true ) ) {
					$source = 'custom';
					$note   = __( 'Update URI points outside WordPress.org.', 'wpav' );
				}
			}
			if ( empty( $data['Version'] ) ) {
				$source = 'custom';
				$note   = __( 'No Version header.', 'wpav' );
			}

			$plugins[ $slug ] = array(
				'name'      => $data['Name'] ? $data['Name'] : $slug,
				'version'   => $data['Version'],
				'file'      => $file,
				'source'    => $source,
				'note'      => $note,
				'checksums' => null,
			);
		}
		return $plugins;
	}

	public static function installed_themes() {
		$themes = array();
		foreach ( wp_get_themes() as $stylesheet => $theme ) {
			$source = 'pending';
			$note   = '';
			$uri    = trim( (string) $theme->get( 'UpdateURI' ) );
			if ( '' !== $uri ) {
				$host = wp_parse_url( $uri, PHP_URL_HOST );
				if ( ! in_array( $host, array( 'w.org', 'wordpress.org' ), true ) ) {
					$source = 'custom';
					$note   = __( 'Update URI points outside WordPress.org.', 'wpav' );
				}
			}
			if ( '' === (string) $theme->get( 'Version' ) || false !== strpos( $stylesheet, '/' ) ) {
				$source = 'custom';
				$note   = __( 'No Version header.', 'wpav' );
			}
			$themes[ $stylesheet ] = array(
				'name'      => $theme->get( 'Name' ),
				'version'   => $theme->get( 'Version' ),
				'source'    => $source,
				'note'      => $note,
				'checksums' => null,
			);
		}
		return $themes;
	}

	/**
	 * WordPress.org publishes no checksum API for themes, so the official zip of the
	 * installed version is downloaded (cached, shared with repairs) and hashed.
	 *
	 * @return array|null|WP_Error relative path => md5[]; null if the theme/version is not on WordPress.org.
	 */
	public static function theme_checksums( $slug, $version ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'wpav_no_zip', __( 'The PHP Zip extension is required to verify themes.', 'wpav' ) );
		}
		$zip_file = WPAV_Source::package( array( WPAV_Source::theme_zip_url( $slug, $version ) ), 'theme-' . $slug . '-' . $version );
		if ( is_wp_error( $zip_file ) ) {
			return 'http_404' === $zip_file->get_error_code() ? null : $zip_file;
		}

		$zip = new ZipArchive();
		if ( true !== $zip->open( $zip_file ) ) {
			@unlink( $zip_file ); // phpcs:ignore
			return new WP_Error( 'wpav_zip_open', __( 'The downloaded theme package could not be opened.', 'wpav' ) );
		}
		$prefix = $slug . '/';
		$sums   = array();
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$name = $zip->getNameIndex( $i );
			if ( 0 !== strpos( $name, $prefix ) || '/' === substr( $name, -1 ) ) {
				continue;
			}
			$sums[ substr( $name, strlen( $prefix ) ) ] = array( md5( (string) $zip->getFromIndex( $i ) ) );
		}
		$zip->close();
		return $sums ? $sums : null;
	}

	/**
	 * Checksums of the exact plugin version published on WordPress.org.
	 *
	 * @return array|null|WP_Error relative path => md5[]; null if the plugin/version is not on WordPress.org.
	 */
	public static function plugin_checksums( $slug, $version ) {
		$url      = sprintf(
			'https://downloads.wordpress.org/plugin-checksums/%s/%s.json',
			rawurlencode( $slug ),
			rawurlencode( $version )
		);
		$response = wp_remote_get( $url, array( 'timeout' => 20 ) );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 404 === $code ) {
			return null;
		}
		if ( 200 !== $code ) {
			return new WP_Error( 'wpav_http', sprintf( 'HTTP %d', $code ) );
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( empty( $data['files'] ) || ! is_array( $data['files'] ) ) {
			return null;
		}

		$sums = array();
		foreach ( $data['files'] as $path => $hashes ) {
			if ( ! empty( $hashes['md5'] ) ) {
				$sums[ $path ] = array_values( (array) $hashes['md5'] );
			}
		}
		return $sums ? $sums : null;
	}
}
