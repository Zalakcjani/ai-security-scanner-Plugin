<?php
/**
 * Shared helpers: paths, file kinds, severities, text cleanup.
 *
 * @package WPAV
 */

defined( 'ABSPATH' ) || exit;

class WPAV_Util {

	const SEVERITY_RANK = array(
		'low'      => 1,
		'medium'   => 2,
		'high'     => 3,
		'critical' => 4,
	);

	const PHP_EXTENSIONS = array( 'php', 'php3', 'php4', 'php5', 'php7', 'php8', 'pht', 'phtml', 'phar', 'inc' );

	public static function capability() {
		return is_multisite() ? 'manage_network_options' : 'manage_options';
	}

	public static function page_url( $page ) {
		$path = 'admin.php?page=' . $page;
		return is_multisite() ? network_admin_url( $path ) : admin_url( $path );
	}

	public static function abspath() {
		return trailingslashit( wp_normalize_path( ABSPATH ) );
	}

	public static function content_dir() {
		return trailingslashit( wp_normalize_path( WP_CONTENT_DIR ) );
	}

	public static function starts_with( $haystack, $needle ) {
		return '' !== $needle && 0 === strpos( $haystack, $needle );
	}

	/**
	 * Directories to walk. ABSPATH plus any wp-content / plugin dirs that live outside it.
	 */
	public static function roots() {
		$roots = array( self::abspath() );
		foreach ( array( WP_CONTENT_DIR, WP_PLUGIN_DIR, WPMU_PLUGIN_DIR ) as $dir ) {
			$dir    = trailingslashit( wp_normalize_path( $dir ) );
			$inside = false;
			foreach ( $roots as $root ) {
				if ( self::starts_with( $dir, $root ) ) {
					$inside = true;
					break;
				}
			}
			if ( ! $inside && is_dir( $dir ) ) {
				$roots[] = $dir;
			}
		}
		return $roots;
	}

	public static function is_allowed_path( $path ) {
		$path = wp_normalize_path( $path );
		if ( false !== strpos( $path, '../' ) ) {
			return false;
		}
		foreach ( self::roots() as $root ) {
			if ( self::starts_with( $path, $root ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Human-friendly path relative to the WordPress install.
	 */
	public static function rel( $path ) {
		$path = wp_normalize_path( $path );
		if ( self::starts_with( $path, self::abspath() ) ) {
			return substr( $path, strlen( self::abspath() ) );
		}
		if ( self::starts_with( $path, self::content_dir() ) ) {
			return 'wp-content/' . substr( $path, strlen( self::content_dir() ) );
		}
		return $path;
	}

	/**
	 * Which signature group applies to a file, or '' if the file is not scanned.
	 */
	public static function file_kind( $path ) {
		$base = strtolower( basename( $path ) );
		if ( '.htaccess' === $base ) {
			return 'htaccess';
		}
		if ( '.user.ini' === $base || 'php.ini' === $base ) {
			return 'ini';
		}
		$ext = strtolower( pathinfo( $base, PATHINFO_EXTENSION ) );
		if ( in_array( $ext, self::PHP_EXTENSIONS, true ) ) {
			return 'php';
		}
		if ( in_array( $ext, array( 'js', 'html', 'htm' ), true ) ) {
			return 'js';
		}
		if ( 'ico' === $ext ) {
			return 'image';
		}
		return '';
	}

	/**
	 * Media files that are only scanned inside uploads (hidden PHP / scripts).
	 */
	public static function media_kind( $path ) {
		$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
		if ( in_array( $ext, array( 'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp' ), true ) ) {
			return 'image';
		}
		return 'svg' === $ext ? 'svg' : '';
	}

	public static function severity_rank( $severity ) {
		return isset( self::SEVERITY_RANK[ $severity ] ) ? self::SEVERITY_RANK[ $severity ] : 0;
	}

	public static function max_severity( array $issues ) {
		$max = 'low';
		foreach ( $issues as $issue ) {
			if ( self::severity_rank( $issue['severity'] ) > self::severity_rank( $max ) ) {
				$max = $issue['severity'];
			}
		}
		return $max;
	}

	/**
	 * Make arbitrary (possibly binary / malicious) text safe to store as JSON.
	 */
	public static function clean_text( $text ) {
		if ( function_exists( 'mb_convert_encoding' ) ) {
			return mb_convert_encoding( $text, 'UTF-8', 'UTF-8' );
		}
		return wp_check_invalid_utf8( $text, true );
	}

	public static function truncate( $text, $max = 300 ) {
		return strlen( $text ) > $max ? substr( $text, 0, $max ) . '…' : $text;
	}

	public static function source_label( $finding ) {
		switch ( $finding['type'] ) {
			case 'core':
				return __( 'WordPress core', 'wpav' );
			case 'plugin':
				if ( 'wporg' === $finding['source'] ) {
					return __( 'WordPress.org plugin', 'wpav' );
				}
				if ( 'unverified' === $finding['source'] ) {
					return __( 'Plugin (could not verify)', 'wpav' );
				}
				return __( 'Custom plugin', 'wpav' );
			case 'mu-plugin':
				return __( 'Must-use plugin', 'wpav' );
			case 'theme':
				if ( 'wporg' === $finding['source'] ) {
					return __( 'WordPress.org theme', 'wpav' );
				}
				if ( 'unverified' === $finding['source'] ) {
					return __( 'Theme (could not verify)', 'wpav' );
				}
				return __( 'Custom theme', 'wpav' );
			case 'upload':
				return __( 'Uploads', 'wpav' );
			case 'database':
				return __( 'Database', 'wpav' );
			case 'vulnerability':
				return __( 'Known vulnerability', 'wpav' );
			default:
				return __( 'Other', 'wpav' );
		}
	}

	/**
	 * Files that should not exist at all (no official original) can be quarantined:
	 * extra files in core / WordPress.org plugins, uploads and other non-component locations.
	 * Custom themes, custom plugins and mu-plugins stay report-only, and critical config files are never moved.
	 */
	public static function can_quarantine( array $finding ) {
		if ( 'open' !== $finding['status'] || empty( $finding['path'] ) || $finding['repairable'] ) {
			return false;
		}
		if ( in_array( strtolower( basename( $finding['path'] ) ), array( 'wp-config.php', '.htaccess', '.user.ini', 'php.ini' ), true ) ) {
			return false;
		}
		if ( in_array( $finding['type'], array( 'upload', 'other' ), true ) ) {
			return true;
		}
		if ( 'core' === $finding['type'] || ( in_array( $finding['type'], array( 'plugin', 'theme' ), true ) && 'wporg' === $finding['source'] ) ) {
			foreach ( $finding['issues'] as $issue ) {
				if ( 'unknown' === $issue['kind'] ) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Why a finding cannot be repaired automatically.
	 */
	public static function manual_reason( $finding ) {
		if ( ! empty( $finding['note'] ) ) {
			return $finding['note'];
		}
		if ( 'database' === $finding['type'] ) {
			if ( ! empty( $finding['db']['table'] ) && 'users' === $finding['db']['table'] ) {
				return __( 'If you did not create this administrator, demote or delete it on the Cleanup screen, then reset all passwords and security keys.', 'wpav' );
			}
			return __( 'Database content is never changed automatically. Open the item and remove the injected code.', 'wpav' );
		}
		if ( 'vulnerability' === $finding['type'] ) {
			return empty( $finding['fixed_in'] )
				? __( 'No fixed version is known. Remove or replace this component unless you have mitigated the issue.', 'wpav' )
				/* translators: %s: version */
				: sprintf( __( 'Update to version %s or later.', 'wpav' ), $finding['fixed_in'] );
		}
		if ( self::can_quarantine( $finding ) ) {
			return __( 'This file has no official original. If you do not recognise it, quarantine it (it is moved to Backups and can be restored).', 'wpav' );
		}
		foreach ( $finding['issues'] as $issue ) {
			if ( 'unknown' === $issue['kind'] ) {
				return __( 'This file is not part of the official package, so there is no clean original. Review it and delete it manually if it is malicious.', 'wpav' );
			}
		}
		switch ( $finding['type'] ) {
			case 'theme':
				if ( 'unverified' === $finding['source'] ) {
					return __( 'WordPress.org could not be reached to verify this theme. Run the scan again later.', 'wpav' );
				}
				return __( 'Custom or premium theme (not on WordPress.org). Themes like this are never replaced automatically; clean the code manually.', 'wpav' );
			case 'plugin':
				if ( 'unverified' === $finding['source'] ) {
					return __( 'WordPress.org could not be reached to verify this plugin. Run the scan again later.', 'wpav' );
				}
				return __( 'Custom or premium plugin (not on WordPress.org). Report only; clean it manually or reinstall it from the vendor.', 'wpav' );
			case 'core':
				return __( 'No official checksum is available for this file.', 'wpav' );
			default:
				return __( 'No official original exists for this location. Review it manually.', 'wpav' );
		}
	}
}
