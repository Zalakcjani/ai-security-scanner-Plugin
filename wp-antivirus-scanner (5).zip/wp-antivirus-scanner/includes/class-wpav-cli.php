<?php
/**
 * WP-CLI: `wp antivirus scan|report|repair|quarantine`.
 *
 * @package WPAV
 */

defined( 'ABSPATH' ) || exit;

/**
 * Scan WordPress for malware, and repair or quarantine infected files.
 */
class WPAV_CLI {

	/**
	 * Run a full scan.
	 *
	 * ## OPTIONS
	 *
	 * [--format=<format>]
	 * : Output format for findings.
	 * ---
	 * default: table
	 * options:
	 *   - table
	 *   - csv
	 *   - json
	 * ---
	 *
	 * ## EXAMPLES
	 *
	 *     wp antivirus scan
	 *
	 * @when after_wp_load
	 */
	public function scan( $args, $assoc ) {
		$scanner = new WPAV_Scanner( 'cli' );
		$status  = $scanner->start();
		WP_CLI::log( $status['message'] );
		$last = '';
		while ( ! $status['done'] ) {
			$status = ( new WPAV_Scanner( 'cli' ) )->step();
			if ( is_wp_error( $status ) ) {
				WP_CLI::error( $status->get_error_message() );
			}
			if ( $status['phase'] !== $last || 'files' !== $status['phase'] ) {
				WP_CLI::log( sprintf( '[%5.1f%%] %s', $status['percent'], $status['message'] ) );
			}
			$last = $status['phase'];
		}
		$this->report( array(), $assoc );
	}

	/**
	 * Show the last scan report.
	 *
	 * ## OPTIONS
	 *
	 * [--format=<format>]
	 * : Output format.
	 * ---
	 * default: table
	 * options:
	 *   - table
	 *   - csv
	 *   - json
	 * ---
	 *
	 * [--all]
	 * : Include ignored and resolved findings.
	 *
	 * @when after_wp_load
	 */
	public function report( $args, $assoc ) {
		$results = WPAV_Results::load();
		if ( ! $results ) {
			WP_CLI::error( 'No scan results yet. Run `wp antivirus scan`.' );
		}
		$all   = ! empty( $assoc['all'] );
		$items = array();
		foreach ( $results['findings'] as $f ) {
			if ( ! $all && ( 'open' !== $f['status'] || $f['ignored'] ) ) {
				continue;
			}
			$first   = $f['issues'][0];
			$items[] = array(
				'id'        => $f['id'],
				'severity'  => $f['severity'],
				'file'      => $f['rel'],
				'line'      => $first['line'] ? $first['line'] : '',
				'detection' => $first['title'] . ( count( $f['issues'] ) > 1 ? ' (+' . ( count( $f['issues'] ) - 1 ) . ')' : '' ),
				'action'    => $f['repairable'] ? 'repair' : ( WPAV_Util::can_quarantine( $f ) ? 'quarantine' : ( 'vulnerability' === $f['type'] ? 'update' : 'manual' ) ),
				'status'    => $f['ignored'] ? 'ignored' : $f['status'],
			);
		}
		$format = isset( $assoc['format'] ) ? $assoc['format'] : 'table';
		if ( $items ) {
			WP_CLI\Utils\format_items( $format, $items, array( 'id', 'severity', 'file', 'line', 'detection', 'action', 'status' ) );
		}
		if ( 'table' === $format ) {
			$s = $results['stats'];
			WP_CLI::log( sprintf( 'Scanned %d files (%d verified). %d active finding(s): %d critical, %d high. %d repairable, %d quarantinable.', $s['scanned'], $s['verified'], $s['findings'], $s['by_severity']['critical'], $s['by_severity']['high'], $s['repairable'], $s['quarantinable'] ) );
			$s['findings'] ? WP_CLI::warning( 'Suspicious items found.' ) : WP_CLI::success( 'No issues found.' );
		}
	}

	/**
	 * Replace infected core / WordPress.org plugin files with verified originals (backups are kept).
	 *
	 * ## OPTIONS
	 *
	 * [<id>...]
	 * : Finding IDs from `wp antivirus report`.
	 *
	 * [--all]
	 * : Repair every repairable finding.
	 *
	 * [--yes]
	 * : Skip confirmation.
	 *
	 * @when after_wp_load
	 */
	public function repair( $args, $assoc ) {
		$this->bulk( $args, $assoc, 'repair' );
	}

	/**
	 * Move files that should not exist (web shells, extra core files, PHP in uploads) to Backups.
	 *
	 * ## OPTIONS
	 *
	 * [<id>...]
	 * : Finding IDs from `wp antivirus report`.
	 *
	 * [--all]
	 * : Quarantine every quarantinable finding.
	 *
	 * [--yes]
	 * : Skip confirmation.
	 *
	 * @when after_wp_load
	 */
	public function quarantine( $args, $assoc ) {
		$this->bulk( $args, $assoc, 'quarantine' );
	}

	private function bulk( $ids, $assoc, $action ) {
		$results = WPAV_Results::load();
		if ( ! $results ) {
			WP_CLI::error( 'No scan results yet. Run `wp antivirus scan`.' );
		}
		if ( ! empty( $assoc['all'] ) ) {
			$ids = array();
			foreach ( $results['findings'] as $f ) {
				$eligible = 'repair' === $action ? $f['repairable'] && 'open' === $f['status'] : WPAV_Util::can_quarantine( $f );
				if ( $eligible && ! $f['ignored'] ) {
					$ids[] = $f['id'];
				}
			}
		}
		if ( ! $ids ) {
			WP_CLI::success( 'Nothing to do.' );
			return;
		}
		WP_CLI::confirm( sprintf( '%s %d file(s)? Backups are created first.', ucfirst( $action ), count( $ids ) ), $assoc );

		$failed = 0;
		foreach ( $ids as $id ) {
			$finding = WPAV_Results::find( $id );
			$label   = $finding ? $finding['rel'] : $id;
			$result  = 'repair' === $action ? WPAV_Repair::repair( $id ) : WPAV_Repair::quarantine( $id );
			if ( is_wp_error( $result ) ) {
				$failed++;
				WP_CLI::warning( $label . ': ' . $result->get_error_message() );
			} else {
				WP_CLI::log( $label . ': ' . $result['message'] );
			}
		}
		$failed ? WP_CLI::error( sprintf( '%d of %d failed.', $failed, count( $ids ) ) ) : WP_CLI::success( 'Done.' );
	}
}
