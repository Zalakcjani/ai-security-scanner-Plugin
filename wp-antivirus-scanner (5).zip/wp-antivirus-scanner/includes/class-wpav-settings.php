<?php
/**
 * Plugin settings (network-wide on multisite).
 *
 * @package WPAV
 */

defined( 'ABSPATH' ) || exit;

class WPAV_Settings {

	const OPTION = 'wpav_settings';

	public static function defaults() {
		return array(
			'schedule'         => 'off',   // off|daily|weekly.
			'email'            => get_site_option( 'admin_email' ),
			'email_mode'       => 'new',   // new|always|never.
			'scan_database'    => 1,
			'check_vulns'      => 1,
			'scan_images'      => 1,
			'max_file_mb'      => 4,
			'exclusions'       => '',
			'harden_file_edit' => 0,
			'harden_xmlrpc'    => 0,
			'harden_user_enum' => 0,
		);
	}

	public static function get( $key = null ) {
		$settings = wp_parse_args( (array) get_site_option( self::OPTION, array() ), self::defaults() );
		if ( null === $key ) {
			return $settings;
		}
		return isset( $settings[ $key ] ) ? $settings[ $key ] : null;
	}

	public static function update( array $changes ) {
		$settings = array_merge( self::get(), $changes );
		update_site_option( self::OPTION, $settings );
		return $settings;
	}

	/**
	 * Sanitize the Settings form (hardening toggles live on the Hardening screen).
	 */
	public static function sanitize( array $input ) {
		$out = self::get();

		$schedule        = isset( $input['schedule'] ) ? $input['schedule'] : 'off';
		$out['schedule'] = in_array( $schedule, array( 'off', 'daily', 'weekly' ), true ) ? $schedule : 'off';

		$email        = isset( $input['email'] ) ? sanitize_email( $input['email'] ) : '';
		$out['email'] = is_email( $email ) ? $email : '';

		$mode              = isset( $input['email_mode'] ) ? $input['email_mode'] : 'new';
		$out['email_mode'] = in_array( $mode, array( 'new', 'always', 'never' ), true ) ? $mode : 'new';

		$out['scan_database'] = empty( $input['scan_database'] ) ? 0 : 1;
		$out['check_vulns']   = empty( $input['check_vulns'] ) ? 0 : 1;
		$out['scan_images']   = empty( $input['scan_images'] ) ? 0 : 1;
		$out['max_file_mb']   = max( 1, min( 64, isset( $input['max_file_mb'] ) ? absint( $input['max_file_mb'] ) : 4 ) );

		$lines = array();
		foreach ( explode( "\n", str_replace( "\r", '', isset( $input['exclusions'] ) ? (string) $input['exclusions'] : '' ) ) as $line ) {
			$line = ltrim( wp_normalize_path( trim( sanitize_text_field( $line ) ) ), '/' );
			if ( '' !== $line ) {
				$lines[] = $line;
			}
		}
		$out['exclusions'] = implode( "\n", array_unique( $lines ) );

		return $out;
	}

	public static function exclusions() {
		return array_values( array_filter( explode( "\n", (string) self::get( 'exclusions' ) ) ) );
	}

	/**
	 * Match a path relative to the WordPress root against exclusion patterns.
	 * Patterns with * ? [ are globs; anything else is a path prefix.
	 */
	public static function is_excluded( $rel, array $patterns ) {
		foreach ( $patterns as $pattern ) {
			if ( false !== strpbrk( $pattern, '*?[' ) ) {
				if ( fnmatch( $pattern, $rel ) || fnmatch( $pattern, rtrim( $rel, '/' ) ) ) {
					return true;
				}
			} elseif ( 0 === strpos( $rel, $pattern ) ) {
				return true;
			}
		}
		return false;
	}
}
