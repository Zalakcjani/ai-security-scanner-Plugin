<?php
/**
 * Private, web-inaccessible working directory for scan state, reports, backups and package cache.
 *
 * @package WPAV
 */

defined( 'ABSPATH' ) || exit;

class WPAV_Storage {

	const TOKEN_OPTION = 'wpav_storage_token';

	/**
	 * Absolute path (no trailing slash) of the storage dir. The random token keeps it
	 * unguessable on servers that ignore .htaccess (e.g. nginx).
	 */
	public static function dir( $sub = '' ) {
		$token = get_option( self::TOKEN_OPTION );
		if ( ! $token ) {
			$token = strtolower( wp_generate_password( 20, false, false ) );
			update_option( self::TOKEN_OPTION, $token, false );
		}
		$uploads = wp_upload_dir( null, false );
		$dir     = wp_normalize_path( trailingslashit( $uploads['basedir'] ) . 'wpav-' . $token );
		if ( '' !== $sub ) {
			$dir .= '/' . $sub;
		}
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		self::protect( $dir );
		return $dir;
	}

	public static function protect( $dir ) {
		if ( ! file_exists( $dir . '/.htaccess' ) ) {
			@file_put_contents( // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
				$dir . '/.htaccess',
				"<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n"
			);
		}
		if ( ! file_exists( $dir . '/index.php' ) ) {
			@file_put_contents( $dir . '/index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore
		}
	}

	public static function read_json( $name, $default = null ) {
		$file = self::dir() . '/' . $name;
		if ( ! is_readable( $file ) ) {
			return $default;
		}
		$data = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		return null === $data ? $default : $data;
	}

	public static function write_json( $name, $data ) {
		$json = wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE );
		if ( false === $json ) {
			return false;
		}
		return false !== file_put_contents( self::dir() . '/' . $name, $json, LOCK_EX ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
	}

	public static function delete( $name ) {
		$file = self::dir() . '/' . $name;
		if ( file_exists( $file ) ) {
			@unlink( $file ); // phpcs:ignore
		}
	}

	/**
	 * Storage dir path without creating it (used to exclude it from scans).
	 */
	public static function existing_dir() {
		$token = get_option( self::TOKEN_OPTION );
		if ( ! $token ) {
			return '';
		}
		$uploads = wp_upload_dir( null, false );
		return wp_normalize_path( trailingslashit( $uploads['basedir'] ) . 'wpav-' . $token );
	}

	public static function rrmdir( $dir ) {
		if ( ! is_dir( $dir ) || is_link( $dir ) ) {
			return;
		}
		$items = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::CHILD_FIRST
		);
		foreach ( $items as $item ) {
			if ( $item->isDir() && ! $item->isLink() ) {
				@rmdir( $item->getPathname() ); // phpcs:ignore
			} else {
				@unlink( $item->getPathname() ); // phpcs:ignore
			}
		}
		@rmdir( $dir ); // phpcs:ignore
	}
}
