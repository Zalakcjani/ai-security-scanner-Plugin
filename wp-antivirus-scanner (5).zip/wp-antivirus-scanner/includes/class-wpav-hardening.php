<?php
/**
 * Security hardening: runtime protections toggled from the Hardening screen,
 * plus a checklist of common weaknesses.
 *
 * @package WPAV
 */

defined( 'ABSPATH' ) || exit;

class WPAV_Hardening {

	const MARKER = 'WP Anti-Virus';

	/**
	 * Apply enabled protections. Runs on every request.
	 */
	public static function init() {
		$settings = WPAV_Settings::get();

		if ( $settings['harden_file_edit'] && ! defined( 'DISALLOW_FILE_EDIT' ) ) {
			define( 'DISALLOW_FILE_EDIT', true );
		}

		if ( $settings['harden_xmlrpc'] ) {
			add_filter( 'xmlrpc_enabled', '__return_false' );
			add_filter( 'xmlrpc_methods', '__return_empty_array' );
			add_filter(
				'wp_headers',
				static function ( $headers ) {
					unset( $headers['X-Pingback'] );
					return $headers;
				}
			);
		}

		if ( $settings['harden_user_enum'] ) {
			add_action( 'init', array( __CLASS__, 'block_author_scans' ) );
			add_filter( 'rest_endpoints', array( __CLASS__, 'hide_user_endpoints' ) );
		}
	}

	public static function block_author_scans() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! is_admin() && isset( $_GET['author'] ) && ! current_user_can( 'list_users' ) ) {
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	}

	public static function hide_user_endpoints( $endpoints ) {
		if ( current_user_can( 'list_users' ) ) {
			return $endpoints;
		}
		foreach ( array_keys( $endpoints ) as $route ) {
			if ( 0 === strpos( $route, '/wp/v2/users' ) ) {
				unset( $endpoints[ $route ] );
			}
		}
		return $endpoints;
	}

	/* ---- PHP execution in uploads ------------------------------------ */

	private static function uploads_htaccess() {
		$uploads = wp_upload_dir( null, false );
		return trailingslashit( $uploads['basedir'] ) . '.htaccess';
	}

	public static function uploads_php_blocked() {
		$file = self::uploads_htaccess();
		return is_readable( $file ) && false !== strpos( (string) file_get_contents( $file ), '# BEGIN ' . self::MARKER ); // phpcs:ignore
	}

	public static function set_uploads_php( $block ) {
		if ( ! function_exists( 'insert_with_markers' ) ) {
			require_once ABSPATH . 'wp-admin/includes/misc.php';
		}
		$file = self::uploads_htaccess();
		if ( ! $block ) {
			if ( ! file_exists( $file ) ) {
				return true;
			}
			$content = (string) file_get_contents( $file ); // phpcs:ignore
			$content = preg_replace( '/\n?# BEGIN ' . preg_quote( self::MARKER, '/' ) . '.*?# END ' . preg_quote( self::MARKER, '/' ) . '\n?/s', "\n", $content );
			return false !== file_put_contents( $file, ltrim( $content ) ); // phpcs:ignore
		}
		$rules = array(
			'<FilesMatch "\.(?i:php[0-9]?|phtml|phar|pht)$">',
			'  <IfModule mod_authz_core.c>',
			'    Require all denied',
			'  </IfModule>',
			'  <IfModule !mod_authz_core.c>',
			'    Order allow,deny',
			'    Deny from all',
			'  </IfModule>',
			'</FilesMatch>',
		);
		return insert_with_markers( $file, self::MARKER, $rules );
	}

	/* ---- Checklist ---------------------------------------------------- */

	private static function check( $id, $title, $status, $detail, $fix = null ) {
		return compact( 'id', 'title', 'status', 'detail', 'fix' );
	}

	/**
	 * @return array[] id, title, status (ok|warn|bad), detail, fix (toggle key or null)
	 */
	public static function checks() {
		$settings = WPAV_Settings::get();
		$checks   = array();

		// Updates.
		if ( ! function_exists( 'get_core_updates' ) ) {
			require_once ABSPATH . 'wp-admin/includes/update.php';
		}
		$core_update = get_core_updates();
		$core_old    = is_array( $core_update ) && isset( $core_update[0]->response ) && 'upgrade' === $core_update[0]->response;
		$checks[]    = self::check(
			'core-updates',
			__( 'WordPress core is up to date', 'wpav' ),
			$core_old ? 'bad' : 'ok',
			$core_old
				/* translators: %s: version */
				? sprintf( __( 'WordPress %s is available. Outdated core is a common way in.', 'wpav' ), $core_update[0]->current )
				: __( 'You are running the latest version.', 'wpav' )
		);

		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$plugin_updates = get_site_transient( 'update_plugins' );
		$outdated       = array();
		if ( ! empty( $plugin_updates->response ) ) {
			$all = get_plugins();
			foreach ( array_keys( $plugin_updates->response ) as $file ) {
				$outdated[] = isset( $all[ $file ] ) ? $all[ $file ]['Name'] : $file;
			}
		}
		$checks[] = self::check(
			'plugin-updates',
			__( 'Plugins are up to date', 'wpav' ),
			$outdated ? 'bad' : 'ok',
			$outdated
				/* translators: %s: plugin list */
				? sprintf( __( 'Updates available for: %s. Vulnerable plugins are the #1 cause of hacked sites.', 'wpav' ), implode( ', ', $outdated ) )
				: __( 'No plugin updates pending.', 'wpav' )
		);

		$theme_updates = get_site_transient( 'update_themes' );
		$theme_count   = empty( $theme_updates->response ) ? 0 : count( $theme_updates->response );
		$checks[]      = self::check(
			'theme-updates',
			__( 'Themes are up to date', 'wpav' ),
			$theme_count ? 'warn' : 'ok',
			/* translators: %d: count */
			$theme_count ? sprintf( __( '%d theme update(s) available.', 'wpav' ), $theme_count ) : __( 'No theme updates pending.', 'wpav' )
		);

		$inactive = count( get_plugins() ) - count( (array) get_option( 'active_plugins', array() ) );
		$checks[] = self::check(
			'inactive-plugins',
			__( 'No unused plugins installed', 'wpav' ),
			$inactive > 0 ? 'warn' : 'ok',
			$inactive > 0
				/* translators: %d: count */
				? sprintf( __( '%d inactive plugin(s). Inactive plugins can still be exploited; delete the ones you do not need.', 'wpav' ), $inactive )
				: __( 'All installed plugins are active.', 'wpav' )
		);

		// Toggleable protections.
		$uploads_blocked = self::uploads_php_blocked();
		$checks[]        = self::check(
			'uploads-php',
			__( 'PHP execution blocked in uploads', 'wpav' ),
			$uploads_blocked ? 'ok' : 'bad',
			$uploads_blocked
				? __( 'An .htaccess rule denies running PHP files from wp-content/uploads (Apache/LiteSpeed).', 'wpav' )
				: __( 'Uploaded web shells can be executed. Blocking PHP in uploads stops most file-upload attacks. On nginx add an equivalent location rule.', 'wpav' ),
			'uploads_php'
		);

		$editor_off = defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT;
		$checks[]   = self::check(
			'file-edit',
			__( 'Theme/plugin file editor disabled', 'wpav' ),
			$editor_off ? 'ok' : 'warn',
			$editor_off
				? __( 'Attackers with an admin login cannot inject code through the built-in editor.', 'wpav' )
				: __( 'The built-in editor lets anyone with an admin login write PHP to your site.', 'wpav' ),
			$settings['harden_file_edit'] || ! $editor_off ? 'file_edit' : null
		);

		$checks[] = self::check(
			'xmlrpc',
			__( 'XML-RPC disabled', 'wpav' ),
			$settings['harden_xmlrpc'] ? 'ok' : 'warn',
			$settings['harden_xmlrpc']
				? __( 'xmlrpc.php brute-force and pingback abuse are blocked.', 'wpav' )
				: __( 'XML-RPC is used for brute-force attacks and pingback DDoS. Disable it unless you use the mobile app or Jetpack.', 'wpav' ),
			'xmlrpc'
		);

		$checks[] = self::check(
			'user-enum',
			__( 'Username enumeration blocked', 'wpav' ),
			$settings['harden_user_enum'] ? 'ok' : 'warn',
			$settings['harden_user_enum']
				? __( '?author=N scans and the public REST users endpoint are blocked for visitors.', 'wpav' )
				: __( 'Visitors can list your usernames via ?author=1 or /wp-json/wp/v2/users, which helps brute-force attacks.', 'wpav' ),
			'user_enum'
		);

		// Configuration advice.
		$admin_user = get_user_by( 'login', 'admin' );
		$checks[]   = self::check(
			'admin-user',
			__( 'No user named “admin”', 'wpav' ),
			$admin_user ? 'warn' : 'ok',
			$admin_user
				? __( '“admin” is the first username attackers try. Create a new administrator and delete this one (attribute its content to the new user).', 'wpav' )
				: __( 'The default username is not in use.', 'wpav' )
		);

		$debug_display = defined( 'WP_DEBUG' ) && WP_DEBUG && ( ! defined( 'WP_DEBUG_DISPLAY' ) || WP_DEBUG_DISPLAY );
		$checks[]      = self::check(
			'debug-display',
			__( 'Errors are not shown to visitors', 'wpav' ),
			$debug_display ? 'bad' : 'ok',
			$debug_display
				? __( 'WP_DEBUG is on and errors are displayed, leaking paths and code. Set WP_DEBUG_DISPLAY to false in wp-config.php.', 'wpav' )
				: __( 'Debug output is hidden.', 'wpav' )
		);

		$weak_keys = false;
		foreach ( array( 'AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY' ) as $const ) {
			if ( ! defined( $const ) || 'put your unique phrase here' === constant( $const ) || strlen( constant( $const ) ) < 32 ) {
				$weak_keys = true;
			}
		}
		$checks[] = self::check(
			'salts',
			__( 'Security keys and salts are set', 'wpav' ),
			$weak_keys ? 'bad' : 'ok',
			$weak_keys
				? __( 'One or more keys in wp-config.php are missing or default. Generate new ones at https://api.wordpress.org/secret-key/1.1/salt/ (this logs everyone out).', 'wpav' )
				: __( 'Unique keys are configured.', 'wpav' )
		);

		$https    = 0 === strpos( home_url(), 'https://' );
		$checks[] = self::check(
			'https',
			__( 'Site uses HTTPS', 'wpav' ),
			$https ? 'ok' : 'bad',
			$https ? __( 'Logins and cookies are encrypted.', 'wpav' ) : __( 'Passwords and session cookies are sent unencrypted. Install a TLS certificate and switch the site URL to https://.', 'wpav' )
		);

		$config = file_exists( ABSPATH . 'wp-config.php' ) ? ABSPATH . 'wp-config.php' : dirname( ABSPATH ) . '/wp-config.php';
		if ( '\\' !== DIRECTORY_SEPARATOR && file_exists( $config ) ) {
			$perms    = fileperms( $config ) & 0777;
			$checks[] = self::check(
				'config-perms',
				__( 'wp-config.php is not world-accessible', 'wpav' ),
				$perms & 0007 ? 'warn' : 'ok',
				/* translators: %s: octal permissions */
				sprintf( __( 'Current permissions: %s. Recommended: 0640 or 0600.', 'wpav' ), sprintf( '%04o', $perms ) )
			);
		}

		$old_php  = version_compare( PHP_VERSION, '8.1', '<' );
		$checks[] = self::check(
			'php-version',
			__( 'Supported PHP version', 'wpav' ),
			$old_php ? 'warn' : 'ok',
			/* translators: %s: PHP version */
			sprintf( $old_php ? __( 'PHP %s no longer receives security fixes. Ask your host to upgrade.', 'wpav' ) : __( 'PHP %s is supported.', 'wpav' ), PHP_VERSION )
		);

		return $checks;
	}

	/**
	 * Toggle a protection from the Hardening screen.
	 */
	public static function toggle( $key, $enable ) {
		$result = self::apply_toggle( $key, $enable );
		if ( true === $result ) {
			WPAV_Log::add( $enable ? __( 'Enabled protection', 'wpav' ) : __( 'Disabled protection', 'wpav' ), $key );
		}
		return $result;
	}

	private static function apply_toggle( $key, $enable ) {
		switch ( $key ) {
			case 'uploads_php':
				if ( ! WPAV_Repair::can_modify() ) {
					return new WP_Error( 'wpav_file_mods', __( 'File modifications are disabled on this site (DISALLOW_FILE_MODS).', 'wpav' ) );
				}
				return self::set_uploads_php( $enable ) ? true : new WP_Error( 'wpav_htaccess', __( 'Could not write wp-content/uploads/.htaccess. Check permissions.', 'wpav' ) );
			case 'file_edit':
				if ( ! $enable && defined( 'DISALLOW_FILE_EDIT' ) && ! WPAV_Settings::get( 'harden_file_edit' ) ) {
					return new WP_Error( 'wpav_config', __( 'The file editor is disabled in wp-config.php; change it there.', 'wpav' ) );
				}
				WPAV_Settings::update( array( 'harden_file_edit' => $enable ? 1 : 0 ) );
				return true;
			case 'xmlrpc':
				WPAV_Settings::update( array( 'harden_xmlrpc' => $enable ? 1 : 0 ) );
				return true;
			case 'user_enum':
				WPAV_Settings::update( array( 'harden_user_enum' => $enable ? 1 : 0 ) );
				return true;
		}
		return new WP_Error( 'wpav_unknown', __( 'Unknown hardening option.', 'wpav' ) );
	}

	/**
	 * Whether a toggle is currently switched on (drives the button label).
	 */
	public static function is_enabled( $key ) {
		switch ( $key ) {
			case 'uploads_php':
				return self::uploads_php_blocked();
			case 'file_edit':
				return (bool) WPAV_Settings::get( 'harden_file_edit' );
			case 'xmlrpc':
				return (bool) WPAV_Settings::get( 'harden_xmlrpc' );
			case 'user_enum':
				return (bool) WPAV_Settings::get( 'harden_user_enum' );
		}
		return false;
	}
}
