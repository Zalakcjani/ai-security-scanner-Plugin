<?php
/**
 * Admin screens, AJAX endpoints, CSV export and the dashboard widget.
 * Screen markup lives in /views.
 *
 * @package WPAV
 */

defined( 'ABSPATH' ) || exit;

class WPAV_Admin {

	const PAGES = array( 'wpav', 'wpav-report', 'wpav-repair', 'wpav-cleanup', 'wpav-hardening', 'wpav-backups', 'wpav-activity', 'wpav-settings' );

	public function __construct() {
		add_action( is_multisite() ? 'network_admin_menu' : 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( is_multisite() ? 'wp_network_dashboard_setup' : 'wp_dashboard_setup', array( $this, 'dashboard_widget' ) );
		add_action( 'admin_post_wpav_export', array( $this, 'export_csv' ) );
		add_action( 'admin_post_wpav_save_settings', array( $this, 'save_settings' ) );
		add_action( 'admin_post_wpav_dismiss_notice', array( $this, 'dismiss_notice' ) );
		add_action( is_multisite() ? 'network_admin_notices' : 'admin_notices', array( $this, 'critical_notice' ) );

		$actions = array( 'scan_start', 'scan_step', 'repair', 'quarantine', 'ignore', 'unignore', 'diff', 'restore', 'delete_backup', 'harden', 'logout_all', 'regenerate_keys', 'reset_passwords', 'demote', 'delete_cron' );
		foreach ( $actions as $action ) {
			add_action( 'wp_ajax_wpav_' . $action, array( $this, 'ajax_' . $action ) );
		}
	}

	public function menu() {
		$cap     = WPAV_Util::capability();
		$summary = WPAV_Results::summary();
		$count   = $summary ? $summary['stats']['by_severity']['critical'] + $summary['stats']['by_severity']['high'] : 0;
		$bubble  = $count ? ' <span class="awaiting-mod">' . (int) $count . '</span>' : '';

		add_menu_page( __( 'Anti-Virus', 'wpav' ), __( 'Anti-Virus', 'wpav' ) . $bubble, $cap, 'wpav', array( $this, 'page_scan' ), 'dashicons-shield', 80 );
		add_submenu_page( 'wpav', __( 'Scan', 'wpav' ), __( 'Scan', 'wpav' ), $cap, 'wpav', array( $this, 'page_scan' ) );
		add_submenu_page( 'wpav', __( 'Report', 'wpav' ), __( 'Report', 'wpav' ), $cap, 'wpav-report', array( $this, 'page_report' ) );
		add_submenu_page( 'wpav', __( 'Repair', 'wpav' ), __( 'Repair', 'wpav' ), $cap, 'wpav-repair', array( $this, 'page_repair' ) );
		add_submenu_page( 'wpav', __( 'Cleanup', 'wpav' ), __( 'Cleanup', 'wpav' ), $cap, 'wpav-cleanup', array( $this, 'page_cleanup' ) );
		add_submenu_page( 'wpav', __( 'Hardening', 'wpav' ), __( 'Hardening', 'wpav' ), $cap, 'wpav-hardening', array( $this, 'page_hardening' ) );
		add_submenu_page( 'wpav', __( 'Backups', 'wpav' ), __( 'Backups', 'wpav' ), $cap, 'wpav-backups', array( $this, 'page_backups' ) );
		add_submenu_page( 'wpav', __( 'Activity', 'wpav' ), __( 'Activity', 'wpav' ), $cap, 'wpav-activity', array( $this, 'page_activity' ) );
		add_submenu_page( 'wpav', __( 'Settings', 'wpav' ), __( 'Settings', 'wpav' ), $cap, 'wpav-settings', array( $this, 'page_settings' ) );
	}

	public function assets( $hook ) {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! in_array( $page, self::PAGES, true ) && 'index.php' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'wpav-admin', WPAV_URL . 'assets/admin.css', array(), WPAV_VERSION );
		if ( 'index.php' === $hook ) {
			return;
		}
		wp_enqueue_script( 'wpav-admin', WPAV_URL . 'assets/admin.js', array(), WPAV_VERSION, true );
		wp_localize_script(
			'wpav-admin',
			'wpavData',
			array(
				'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
				'nonce'     => wp_create_nonce( 'wpav' ),
				'reportUrl' => WPAV_Util::page_url( 'wpav-report' ),
				'loginUrl'  => wp_login_url( WPAV_Util::page_url( 'wpav-cleanup' ) ),
				'i18n'      => array(
					'starting'          => __( 'Preparing scan (building file list, fetching core checksums)…', 'wpav' ),
					'done'              => __( 'Scan complete. Opening the report…', 'wpav' ),
					'error'             => __( 'Error:', 'wpav' ),
					'retrying'          => __( 'Request failed, retrying…', 'wpav' ),
					'selectFiles'       => __( 'Select at least one file.', 'wpav' ),
					'confirmRepair'     => __( 'Replace %d file(s) with the official WordPress.org originals? A backup of each file is created first.', 'wpav' ),
					'confirmQuarantine' => __( 'Quarantine %d file(s)? Each file is moved to Backups and removed from the site. You can restore it later.', 'wpav' ),
					'working'           => __( 'Working…', 'wpav' ),
					'loadingDiff'       => __( 'Downloading the official file and comparing…', 'wpav' ),
					'noDiff'            => __( 'No line differences (whitespace or line-ending changes only).', 'wpav' ),
					'truncated'         => __( 'Output truncated to the first 500 changed lines.', 'wpav' ),
					'added'             => __( 'Added / changed (local file)', 'wpav' ),
					'removed'           => __( 'Removed (official file)', 'wpav' ),
					'line'              => __( 'Line', 'wpav' ),
					'change'            => __( 'Change', 'wpav' ),
					'code'              => __( 'Code', 'wpav' ),
				),
			)
		);
	}

	/* ------------------------------------------------------------------ */
	/* AJAX                                                                */
	/* ------------------------------------------------------------------ */

	private function guard() {
		check_ajax_referer( 'wpav', 'nonce' );
		if ( ! current_user_can( WPAV_Util::capability() ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'wpav' ) ), 403 );
		}
	}

	private function respond( $result ) {
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		wp_send_json_success( $result );
	}

	private function post_value( $key = 'id' ) {
		return isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
	}

	private function finding_id() {
		return sanitize_key( $this->post_value() );
	}

	public function ajax_scan_start() {
		$this->guard();
		$this->respond( ( new WPAV_Scanner( 'manual' ) )->start() );
	}

	public function ajax_scan_step() {
		$this->guard();
		$this->respond( ( new WPAV_Scanner( 'manual' ) )->step() );
	}

	public function ajax_repair() {
		$this->guard();
		$this->respond( WPAV_Repair::repair( $this->finding_id() ) );
	}

	public function ajax_quarantine() {
		$this->guard();
		$this->respond( WPAV_Repair::quarantine( $this->finding_id() ) );
	}

	public function ajax_ignore() {
		$this->guard();
		$this->respond( WPAV_Results::ignore( $this->finding_id() ) );
	}

	public function ajax_unignore() {
		$this->guard();
		$this->respond( WPAV_Results::unignore( $this->finding_id() ) );
	}

	public function ajax_diff() {
		$this->guard();
		$finding = WPAV_Results::find( $this->finding_id() );
		if ( ! $finding ) {
			wp_send_json_error( array( 'message' => __( 'Finding not found. Run a new scan.', 'wpav' ) ) );
		}
		@set_time_limit( 300 ); // phpcs:ignore
		$this->respond( WPAV_Source::diff( $finding ) );
	}

	public function ajax_restore() {
		$this->guard();
		$id = $this->post_value();
		if ( ! WPAV_Backup::valid_id( $id ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid backup.', 'wpav' ) ) );
		}
		$result = WPAV_Backup::restore( $id );
		if ( ! is_wp_error( $result ) ) {
			WPAV_Results::reopen_by_backup( $id );
		}
		$this->respond( $result );
	}

	public function ajax_delete_backup() {
		$this->guard();
		$id = $this->post_value();
		if ( ! WPAV_Backup::valid_id( $id ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid backup.', 'wpav' ) ) );
		}
		$this->respond( WPAV_Backup::delete( $id ) );
	}

	public function ajax_harden() {
		$this->guard();
		$this->respond( WPAV_Hardening::toggle( sanitize_key( $this->post_value( 'key' ) ), '1' === $this->post_value( 'enable' ) ) );
	}

	public function ajax_logout_all() {
		$this->guard();
		$this->respond( WPAV_Cleanup::logout_all() );
	}

	public function ajax_regenerate_keys() {
		$this->guard();
		$this->respond( WPAV_Cleanup::regenerate_keys() );
	}

	public function ajax_reset_passwords() {
		$this->guard();
		$this->respond( WPAV_Cleanup::reset_passwords( '1' === $this->post_value( 'send' ) ) );
	}

	public function ajax_demote() {
		$this->guard();
		$this->respond( WPAV_Cleanup::demote( absint( $this->post_value() ) ) );
	}

	public function ajax_delete_cron() {
		$this->guard();
		$this->respond( WPAV_Cleanup::delete_cron( sanitize_key( $this->post_value() ) ) );
	}

	/* ------------------------------------------------------------------ */
	/* Site-wide notice                                                    */
	/* ------------------------------------------------------------------ */

	/**
	 * Warn administrators everywhere in wp-admin while critical issues are open.
	 */
	public function critical_notice() {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( in_array( $page, self::PAGES, true ) || ! current_user_can( WPAV_Util::capability() ) ) {
			return;
		}
		$summary = WPAV_Results::summary();
		if ( ! $summary || ! $summary['stats']['by_severity']['critical'] ) {
			return;
		}
		if ( (int) get_user_meta( get_current_user_id(), 'wpav_notice_dismissed', true ) === (int) $summary['finished'] ) {
			return;
		}
		printf(
			'<div class="notice notice-error"><p><strong>%1$s</strong> %2$s <a href="%3$s">%4$s</a> · <a href="%5$s">%6$s</a></p></div>',
			esc_html__( 'Security alert:', 'wpav' ),
			/* translators: %d: number of critical issues */
			esc_html( sprintf( _n( 'the last scan found %d critical issue.', 'the last scan found %d critical issues.', $summary['stats']['by_severity']['critical'], 'wpav' ), $summary['stats']['by_severity']['critical'] ) ),
			esc_url( WPAV_Util::page_url( 'wpav-report' ) ),
			esc_html__( 'View report', 'wpav' ),
			esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpav_dismiss_notice' ), 'wpav_dismiss_notice' ) ),
			esc_html__( 'Dismiss until the next scan', 'wpav' )
		);
	}

	public function dismiss_notice() {
		check_admin_referer( 'wpav_dismiss_notice' );
		$summary = WPAV_Results::summary();
		if ( $summary ) {
			update_user_meta( get_current_user_id(), 'wpav_notice_dismissed', (int) $summary['finished'] );
		}
		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url() );
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* admin-post handlers                                                 */
	/* ------------------------------------------------------------------ */

	public function export_csv() {
		if ( ! current_user_can( WPAV_Util::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wpav' ) );
		}
		check_admin_referer( 'wpav_export' );
		$results = WPAV_Results::load();
		if ( ! $results ) {
			wp_die( esc_html__( 'No scan results yet.', 'wpav' ) );
		}

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=antivirus-report-' . gmdate( 'Ymd-His', $results['finished'] ) . '.csv' );

		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, array( 'Severity', 'Status', 'Location', 'Component', 'Version', 'File / item', 'Line', 'Detection', 'Code', 'Action' ) );
		foreach ( $results['findings'] as $f ) {
			$action = $f['repairable'] ? 'Repairable' : ( WPAV_Util::can_quarantine( $f ) ? 'Quarantine' : 'Manual review' );
			foreach ( $f['issues'] as $issue ) {
				fputcsv(
					$out,
					array_map(
						array( __CLASS__, 'csv_safe' ),
						array(
							$issue['severity'],
							$f['ignored'] ? 'ignored' : $f['status'],
							WPAV_Util::source_label( $f ),
							$f['component'],
							$f['version'],
							$f['rel'],
							$issue['line'] ? $issue['line'] : '',
							$issue['title'],
							$issue['code'],
							$action,
						)
					)
				);
			}
		}
		fclose( $out ); // phpcs:ignore
		exit;
	}

	/**
	 * Prevent spreadsheet formula injection from malicious code excerpts.
	 */
	public static function csv_safe( $value ) {
		$value = (string) $value;
		return ( '' !== $value && false !== strpos( '=+-@', $value[0] ) ) ? "'" . $value : $value;
	}

	public function save_settings() {
		if ( ! current_user_can( WPAV_Util::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wpav' ) );
		}
		check_admin_referer( 'wpav_settings' );
		$input = isset( $_POST['wpav'] ) ? wp_unslash( (array) $_POST['wpav'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized below.
		$old   = WPAV_Settings::get( 'schedule' );
		WPAV_Settings::update( WPAV_Settings::sanitize( $input ) );
		if ( $old !== WPAV_Settings::get( 'schedule' ) || ! WPAV_Cron::next_run() ) {
			WPAV_Cron::reschedule();
		}
		wp_safe_redirect( add_query_arg( 'updated', '1', WPAV_Util::page_url( 'wpav-settings' ) ) );
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* Dashboard widget                                                    */
	/* ------------------------------------------------------------------ */

	public function dashboard_widget() {
		if ( current_user_can( WPAV_Util::capability() ) ) {
			wp_add_dashboard_widget( 'wpav_status', __( 'Anti-Virus status', 'wpav' ), array( $this, 'render_dashboard_widget' ) );
		}
	}

	public function render_dashboard_widget() {
		$summary = WPAV_Results::summary();
		include WPAV_DIR . 'views/widget.php';
	}

	/* ------------------------------------------------------------------ */
	/* Screens                                                             */
	/* ------------------------------------------------------------------ */

	private function render( $view, $title, array $vars = array() ) {
		$tabs = array(
			'wpav'           => __( 'Scan', 'wpav' ),
			'wpav-report'    => __( 'Report', 'wpav' ),
			'wpav-repair'    => __( 'Repair', 'wpav' ),
			'wpav-cleanup'   => __( 'Cleanup', 'wpav' ),
			'wpav-hardening' => __( 'Hardening', 'wpav' ),
			'wpav-backups'   => __( 'Backups', 'wpav' ),
			'wpav-activity'  => __( 'Activity', 'wpav' ),
			'wpav-settings'  => __( 'Settings', 'wpav' ),
		);
		$current = 'scan' === $view ? 'wpav' : 'wpav-' . $view;

		echo '<div class="wrap wpav">';
		echo '<h1><span class="dashicons dashicons-shield"></span> ' . esc_html( $title ) . '</h1>';
		echo '<nav class="nav-tab-wrapper">';
		foreach ( $tabs as $slug => $label ) {
			printf(
				'<a href="%s" class="nav-tab%s">%s</a>',
				esc_url( WPAV_Util::page_url( $slug ) ),
				$slug === $current ? ' nav-tab-active' : '',
				esc_html( $label )
			);
		}
		echo '</nav>';

		extract( $vars ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract
		include WPAV_DIR . 'views/' . $view . '.php';

		echo '</div>';
	}

	public function page_scan() {
		$this->render(
			'scan',
			__( 'Anti-Virus Scanner', 'wpav' ),
			array(
				'results' => WPAV_Results::load(),
				'history' => WPAV_History::all(),
				'running' => WPAV_Scanner::is_running(),
			)
		);
	}

	public function page_report() {
		$this->render(
			'report',
			__( 'Scan Report', 'wpav' ),
			array(
				'results'  => WPAV_Results::load(),
				'show_new' => count( WPAV_History::all() ) > 1,
			)
		);
	}

	public function page_repair() {
		$this->render( 'repair', __( 'Repair & Quarantine', 'wpav' ), array( 'results' => WPAV_Results::load() ) );
	}

	public function page_cleanup() {
		$blogs = is_multisite() ? array_map( 'intval', get_sites( array( 'fields' => 'ids', 'number' => WPAV_DB_Scanner::MAX_SITES ) ) ) : null;
		$this->render(
			'cleanup',
			__( 'Post-hack Cleanup', 'wpav' ),
			array(
				'admins'   => WPAV_Cleanup::administrators( $blogs ),
				'events'   => WPAV_Cleanup::cron_events(),
				'autoload' => WPAV_Cleanup::autoloaded_code(),
				'results'  => WPAV_Results::load(),
			)
		);
	}

	public function page_activity() {
		$this->render( 'activity', __( 'Activity Log', 'wpav' ), array( 'log' => WPAV_Log::all() ) );
	}

	public function page_hardening() {
		$this->render( 'hardening', __( 'Hardening', 'wpav' ), array( 'checks' => WPAV_Hardening::checks() ) );
	}

	public function page_backups() {
		$this->render( 'backups', __( 'Backups', 'wpav' ), array( 'backups' => array_reverse( WPAV_Backup::all() ) ) );
	}

	public function page_settings() {
		$this->render( 'settings', __( 'Settings', 'wpav' ), array( 'settings' => WPAV_Settings::get() ) );
	}

	/* ------------------------------------------------------------------ */
	/* View helpers                                                        */
	/* ------------------------------------------------------------------ */

	public function no_results() {
		printf(
			'<div class="wpav-card wpav-empty"><p>%s</p><p><a class="button button-primary" href="%s">%s</a></p></div>',
			esc_html__( 'No scan results yet.', 'wpav' ),
			esc_url( WPAV_Util::page_url( 'wpav' ) ),
			esc_html__( 'Run your first scan', 'wpav' )
		);
	}

	public function severity_badge( $severity ) {
		return sprintf( '<span class="wpav-badge sev-%1$s">%2$s</span>', esc_attr( $severity ), esc_html( ucfirst( $severity ) ) );
	}

	public function stat( $value, $label, $class = '' ) {
		printf(
			'<div class="wpav-stat %s"><span class="wpav-stat-value">%s</span><span class="wpav-stat-label">%s</span></div>',
			esc_attr( $class ),
			esc_html( is_numeric( $value ) ? number_format_i18n( $value ) : $value ),
			esc_html( $label )
		);
	}

	public function date( $timestamp ) {
		return wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp );
	}

	public function origin_label( $origin ) {
		$labels = array(
			'manual' => __( 'Manual', 'wpav' ),
			'cron'   => __( 'Scheduled', 'wpav' ),
			'cli'    => __( 'WP-CLI', 'wpav' ),
		);
		return isset( $labels[ $origin ] ) ? $labels[ $origin ] : $origin;
	}
}
