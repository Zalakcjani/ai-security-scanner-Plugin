<?php
/**
 * Malware / injected-code signatures.
 *
 * This file is excluded from scanning because its patterns would match themselves.
 * Each rule applies to one or more file kinds (see WPAV_Util::file_kind()).
 *
 * @package WPAV
 */

defined( 'ABSPATH' ) || exit;

class WPAV_Signatures {

	const MAX_HITS_PER_RULE = 5;

	private static $rules = null;

	public static function rules() {
		if ( null !== self::$rules ) {
			return self::$rules;
		}

		$php = array( 'php' );
		$js  = array( 'js', 'php', 'db' );

		self::$rules = array(
			// ---- PHP backdoors -------------------------------------------------
			array(
				'id'       => 'php-eval-decode',
				'title'    => __( 'eval() of decoded / obfuscated data', 'wpav' ),
				'severity' => 'critical',
				'kinds'    => $php,
				'regex'    => '/\b(?:eval|assert)\s*\(\s*@?\s*(?:base64_decode|gzinflate|gzuncompress|gzdecode|str_rot13|strrev|convert_uudecode|hex2bin|rawurldecode|urldecode)\s*\(/i',
			),
			array(
				'id'       => 'php-eval-input',
				'title'    => __( 'Executes code sent in the request (backdoor)', 'wpav' ),
				'severity' => 'critical',
				'kinds'    => $php,
				'regex'    => '/\b(?:eval|assert|create_function)\s*\(\s*@?\s*(?:stripslashes\s*\(\s*)?\$_(?:GET|POST|REQUEST|COOKIE|SERVER|FILES)\b/i',
			),
			array(
				'id'       => 'php-exec-input',
				'title'    => __( 'Runs shell commands from request data (web shell)', 'wpav' ),
				'severity' => 'critical',
				'kinds'    => $php,
				'regex'    => '/\b(?:system|shell_exec|passthru|exec|popen|proc_open|pcntl_exec)\s*\(\s*@?\s*\$_(?:GET|POST|REQUEST|COOKIE|SERVER)\b/i',
			),
			array(
				'id'       => 'php-func-from-input',
				'title'    => __( 'Calls a function whose name comes from the request', 'wpav' ),
				'severity' => 'critical',
				'kinds'    => $php,
				'regex'    => '/\$_(?:GET|POST|REQUEST|COOKIE|SERVER)\s*\[\s*[\'"]?[\w-]+[\'"]?\s*\]\s*\(/i',
			),
			array(
				'id'       => 'php-dynamic-superglobal',
				'title'    => __( 'Obfuscated access to request superglobals', 'wpav' ),
				'severity' => 'high',
				'kinds'    => $php,
				'regex'    => '/\$\{\s*[\'"]_(?:GET|POST|REQUEST|COOKIE)[\'"]\s*\}/i',
			),
			array(
				'id'       => 'php-callback-exec',
				'title'    => __( 'Dangerous function passed as a callback', 'wpav' ),
				'severity' => 'high',
				'kinds'    => $php,
				'regex'    => '/\b(?:call_user_func(?:_array)?|array_map|array_filter|usort|uasort|register_shutdown_function|register_tick_function)\s*\(\s*[\'"](?:assert|eval|system|exec|shell_exec|passthru|popen|proc_open)[\'"]/i',
			),
			array(
				'id'       => 'php-preg-e',
				'title'    => __( 'preg_replace() with the /e (code execution) modifier', 'wpav' ),
				'severity' => 'high',
				'kinds'    => $php,
				'regex'    => '/preg_replace\s*\(\s*([\'"])([^\w\s\\\\])[^\'"]*?\2[a-zA-Z]*e[a-zA-Z]*\1\s*,/',
			),
			array(
				'id'       => 'php-eval-dynamic',
				'title'    => __( 'eval() of a dynamic value', 'wpav' ),
				'severity' => 'high',
				'kinds'    => $php,
				'regex'    => '/\beval\s*\(\s*\$\w+\s*[\(\[\)]/i',
			),
			array(
				'id'       => 'php-webshell-marker',
				'title'    => __( 'Known web shell / defacement marker', 'wpav' ),
				'severity' => 'critical',
				'kinds'    => array( 'php', 'js' ),
				'regex'    => '/(?:FilesMan|WSOsetcookie|wso_version|c99shell|c99_buff_prepare|r57shell|b374k|IndoXploit|AnonymousFox|Mister\s?Spy|Hacked\s+By\b)/i',
			),
			array(
				'id'       => 'php-nested-decode',
				'title'    => __( 'Nested decoding functions (typical obfuscation)', 'wpav' ),
				'severity' => 'high',
				'kinds'    => $php,
				'regex'    => '/\b(?:gzinflate|gzuncompress|gzdecode|str_rot13|base64_decode)\s*\(\s*(?:base64_decode|str_rot13|gzinflate|gzuncompress|strrev)\s*\(/i',
			),
			array(
				'id'       => 'php-large-base64',
				'title'    => __( 'Large base64-encoded payload', 'wpav' ),
				'severity' => 'high',
				'kinds'    => $php,
				'regex'    => '/base64_decode\s*\(\s*[\'"][A-Za-z0-9+\/=\s]{500,}[\'"]\s*\)/',
			),
			array(
				'id'       => 'php-hex-string',
				'title'    => __( 'Long hex-escaped string (obfuscation)', 'wpav' ),
				'severity' => 'medium',
				'kinds'    => $php,
				'regex'    => '/(?:\\\\x[0-9a-fA-F]{2}){30,}/',
			),
			array(
				'id'       => 'php-octal-string',
				'title'    => __( 'Long octal-escaped string (obfuscation)', 'wpav' ),
				'severity' => 'medium',
				'kinds'    => $php,
				'regex'    => '/(?:\\\\[0-7]{3}){20,}/',
			),
			array(
				'id'       => 'php-chr-chain',
				'title'    => __( 'String built from chr() calls (obfuscation)', 'wpav' ),
				'severity' => 'high',
				'kinds'    => $php,
				'regex'    => '/(?:chr\s*\(\s*\d+\s*\)\s*\.\s*){8,}/i',
			),
			array(
				'id'       => 'php-globals-obfuscation',
				'title'    => __( '$GLOBALS array obfuscation', 'wpav' ),
				'severity' => 'high',
				'kinds'    => $php,
				'regex'    => '/\$GLOBALS\s*\[\s*[\'"][^\'"]{1,40}[\'"]\s*\]\s*\[\s*\d+\s*\]\s*\.\s*\$GLOBALS/',
			),
			array(
				'id'       => 'php-include-obfuscated',
				'title'    => __( 'include/require of an obfuscated path', 'wpav' ),
				'severity' => 'critical',
				'kinds'    => $php,
				'regex'    => '/\b(?:include|require)(?:_once)?\s*\(?\s*[\'"](?:\\\\x[0-9a-fA-F]{2}|\\\\[0-7]{3})/i',
			),
			array(
				'id'       => 'php-include-remote',
				'title'    => __( 'include/require of a remote or stream URL', 'wpav' ),
				'severity' => 'critical',
				'kinds'    => $php,
				'regex'    => '/\b(?:include|require)(?:_once)?\s*\(?\s*[\'"](?:https?|ftp|php|data|expect):/i',
			),
			array(
				'id'       => 'php-include-image',
				'title'    => __( 'include/require of an image or text file', 'wpav' ),
				'severity' => 'high',
				'kinds'    => $php,
				'regex'    => '/\b(?:include|require)(?:_once)?\b[^;\n]{0,200}\.(?:ico|png|gif|jpe?g|bmp|txt)[\'"]\s*\)?\s*;/i',
			),
			array(
				'id'       => 'php-write-decoded',
				'title'    => __( 'Writes decoded data to a file (dropper)', 'wpav' ),
				'severity' => 'medium',
				'kinds'    => $php,
				'regex'    => '/\b(?:file_put_contents|fwrite|fputs)\s*\([^;]{0,300}?(?:base64_decode|gzinflate|gzuncompress|str_rot13)\s*\(/i',
			),
			array(
				'id'       => 'php-raw-uploader',
				'title'    => __( 'File uploader trusting the client-supplied file name', 'wpav' ),
				'severity' => 'high',
				'kinds'    => $php,
				'regex'    => '/move_uploaded_file\s*\(\s*\$_FILES\s*\[[^\]]+\]\s*\[\s*[\'"]tmp_name[\'"]\s*\]\s*,[^;]{0,100}\$_FILES\s*\[[^\]]+\]\s*\[\s*[\'"]name[\'"]\s*\]/i',
			),
			array(
				'id'       => 'php-eval-remote',
				'title'    => __( 'Executes code downloaded from a remote server', 'wpav' ),
				'severity' => 'critical',
				'kinds'    => $php,
				'regex'    => '/\b(?:eval|assert)\s*\(\s*@?\s*(?:file_get_contents|curl_exec|wp_remote_retrieve_body|stream_get_contents)\s*\(/i',
			),
			array(
				'id'       => 'php-func-name-var',
				'title'    => __( 'Dangerous function name stored in a variable', 'wpav' ),
				'severity' => 'high',
				'kinds'    => $php,
				'regex'    => '/\$\w+\s*=\s*[\'"](?:base64_decode|gzinflate|gzuncompress|str_rot13|assert|create_function|shell_exec|passthru)[\'"]\s*;/i',
			),
			array(
				'id'       => 'php-hide-user',
				'title'    => __( 'Hides a user from the admin users list', 'wpav' ),
				'severity' => 'high',
				'kinds'    => $php,
				'regex'    => '/query_where\s*=\s*str_replace\s*\(\s*[\'"]WHERE 1=1[\'"]/i',
			),
			array(
				'id'       => 'php-create-admin',
				'title'    => __( 'Creates an administrator account in code', 'wpav' ),
				'severity' => 'medium',
				'kinds'    => $php,
				'regex'    => '/\bwp_(?:create|insert)_user\s*\([^;]{0,400}?;[\s\S]{0,400}?[\'"]administrator[\'"]/i',
			),

			// ---- JavaScript injections ----------------------------------------
			array(
				'id'       => 'js-eval-charcode',
				'title'    => __( 'eval() of String.fromCharCode (JS injection)', 'wpav' ),
				'severity' => 'critical',
				'kinds'    => $js,
				'regex'    => '/\beval\s*\(\s*String\.fromCharCode\s*\(/i',
			),
			array(
				'id'       => 'js-eval-decode',
				'title'    => __( 'eval() of decoded data (JS injection)', 'wpav' ),
				'severity' => 'critical',
				'kinds'    => $js,
				'regex'    => '/\beval\s*\(\s*(?:window\.)?(?:atob|unescape|decodeURIComponent)\s*\(/i',
			),
			array(
				'id'       => 'js-document-write-decode',
				'title'    => __( 'document.write() of decoded data', 'wpav' ),
				'severity' => 'high',
				'kinds'    => $js,
				'regex'    => '/document\.write\s*\(\s*(?:unescape|atob|decodeURIComponent)\s*\(/i',
			),
			array(
				'id'       => 'js-long-charcode',
				'title'    => __( 'Long String.fromCharCode() payload', 'wpav' ),
				'severity' => 'high',
				'kinds'    => $js,
				'regex'    => '/String\.fromCharCode\s*\(\s*(?:\d{2,3}\s*,\s*){60,}/i',
			),
			array(
				'id'       => 'js-packer',
				'title'    => __( 'Packed JavaScript (eval(function(p,a,c,k,e,d)))', 'wpav' ),
				'severity' => 'medium',
				'kinds'    => $js,
				'regex'    => '/\beval\s*\(\s*function\s*\(\s*p\s*,\s*a\s*,\s*c\s*,\s*k\s*,\s*e\s*,\s*[dr]\s*\)/',
			),
			array(
				'id'       => 'js-known-domain',
				'title'    => __( 'Reference to a known malware-campaign domain', 'wpav' ),
				'severity' => 'critical',
				'kinds'    => $js,
				'regex'    => '/(?:lovegreenpencils|trackstatisticsss|donatelloflowfirstly|dolohen)\./i',
			),
			array(
				'id'       => 'js-risky-tld-script',
				'title'    => __( 'Script loaded from a high-risk free TLD', 'wpav' ),
				'severity' => 'medium',
				'kinds'    => $js,
				'regex'    => '/<script[^>]+src\s*=\s*[\'"]?https?:\/\/[^\'"\s>]+\.(?:tk|ml|ga|cf|gq)[\/\'"\s>]/i',
			),

			array(
				'id'       => 'js-obfuscator',
				'title'    => __( 'Obfuscated JavaScript (_0x… identifiers)', 'wpav' ),
				'severity' => 'medium',
				'kinds'    => array( 'php', 'db' ),
				'regex'    => '/(?:var|let|const)\s+_0x[a-f0-9]{4,6}\s*=\s*(?:\[|function)/i',
			),

			// ---- Database content (posts / options) ---------------------------
			array(
				'id'       => 'db-hidden-iframe',
				'title'    => __( 'Hidden iframe', 'wpav' ),
				'severity' => 'high',
				'kinds'    => array( 'db', 'php' ),
				'regex'    => '/<iframe\b[^>]*(?:\b(?:width|height)\s*=\s*["\']?[01](?:px)?["\'\s>]|display\s*:\s*none|visibility\s*:\s*hidden)/i',
			),
			array(
				'id'       => 'db-hidden-links',
				'title'    => __( 'Hidden block of links (SEO spam)', 'wpav' ),
				'severity' => 'medium',
				'kinds'    => array( 'db' ),
				'regex'    => '/<(?:div|span|p)\b[^>]*style\s*=\s*["\'][^"\']*(?:display\s*:\s*none|visibility\s*:\s*hidden|(?:left|top)\s*:\s*-\d{3,}px)[^"\']*["\'][^>]*>\s*(?:[^<]{0,100}<a\s[^>]*href=[^>]*>[^<]{0,100}<\/a>){3,}/i',
			),

			// ---- Server config ------------------------------------------------
			array(
				'id'       => 'cfg-auto-prepend',
				'title'    => __( 'auto_prepend/append_file directive (verify it points to a trusted file)', 'wpav' ),
				'severity' => 'medium',
				'kinds'    => array( 'htaccess', 'ini' ),
				'regex'    => '/auto_(?:prepend|append)_file(?![^\n]*wordfence-waf\.php)[^\n]*/i',
			),
			array(
				'id'       => 'htaccess-referer-redirect',
				'title'    => __( 'Redirects visitors coming from search engines (SEO spam)', 'wpav' ),
				'severity' => 'high',
				'kinds'    => array( 'htaccess' ),
				'regex'    => '/RewriteCond\s+%\{HTTP_REFERER\}[^\n]*(?:google|bing|yahoo|yandex|baidu|aol)/i',
			),
			array(
				'id'       => 'htaccess-image-as-php',
				'title'    => __( 'Image / text files configured to execute as PHP', 'wpav' ),
				'severity' => 'critical',
				'kinds'    => array( 'htaccess' ),
				'regex'    => '/(?:(?:AddHandler|AddType)\s+[^\n]*(?:php|x-httpd)[^\n]*\s\.(?:jpe?g|png|gif|ico|txt|bmp|svg)\b|<FilesMatch\s+[^>]*(?:jpe?g|png|gif|ico|txt)[^>]*>\s*(?:SetHandler|ForceType)\s+[^\n]*php)/i',
			),

			// ---- Code hidden in non-code files --------------------------------
			array(
				// No short "<?=" tag: three random bytes match it too often in binary image data.
				'id'       => 'image-php-code',
				'title'    => __( 'PHP code hidden inside an image file', 'wpav' ),
				'severity' => 'critical',
				'kinds'    => array( 'image', 'svg' ),
				'regex'    => '/<\?php|\beval\s*\(|\bbase64_decode\s*\(|\$_(?:GET|POST|REQUEST|COOKIE)\s*\[/i',
			),
			array(
				'id'       => 'svg-script',
				'title'    => __( 'Script inside an SVG image (stored XSS)', 'wpav' ),
				'severity' => 'high',
				'kinds'    => array( 'svg' ),
				'regex'    => '/<script\b|<foreignObject\b[^>]*>[\s\S]{0,500}?<iframe/i',
			),
			array(
				'id'       => 'svg-event-handler',
				'title'    => __( 'JavaScript event handler or javascript: URL inside an SVG image', 'wpav' ),
				'severity' => 'medium',
				'kinds'    => array( 'svg' ),
				'regex'    => '/\son(?:load|error|click|mouseover|focus|begin|activate)\s*=|(?:href|xlink:href)\s*=\s*["\']\s*javascript:/i',
			),
		);

		return self::$rules;
	}

	/**
	 * Scan file contents and return issues with line numbers and code excerpts.
	 */
	public static function scan( $content, $kinds ) {
		$issues = array();
		$kinds  = array_filter( (array) $kinds );
		if ( ! $kinds || '' === $content ) {
			return $issues;
		}
		foreach ( self::rules() as $rule ) {
			if ( ! array_intersect( $kinds, $rule['kinds'] ) ) {
				continue;
			}
			if ( ! preg_match_all( $rule['regex'], $content, $matches, PREG_OFFSET_CAPTURE ) ) {
				continue;
			}
			$seen_lines = array();
			foreach ( array_slice( $matches[0], 0, self::MAX_HITS_PER_RULE ) as $hit ) {
				list( $line, $code ) = self::excerpt( $content, $hit[1] );
				if ( isset( $seen_lines[ $line ] ) ) {
					continue;
				}
				$seen_lines[ $line ] = true;
				$issues[] = array(
					'kind'     => 'signature',
					'rule'     => $rule['id'],
					'title'    => $rule['title'],
					'severity' => $rule['severity'],
					'line'     => $line,
					'code'     => $code,
				);
			}
		}
		return $issues;
	}

	/**
	 * Line number and a readable excerpt around a byte offset (long/minified lines are windowed).
	 */
	private static function excerpt( $content, $offset ) {
		$before = substr( $content, 0, $offset );
		$line   = substr_count( $before, "\n" ) + 1;
		$start  = strrpos( $before, "\n" );
		$start  = false === $start ? 0 : $start + 1;
		$end    = strpos( $content, "\n", $offset );
		$end    = false === $end ? strlen( $content ) : $end;
		$text   = rtrim( substr( $content, $start, $end - $start ), "\r" );

		if ( strlen( $text ) > 300 ) {
			$col  = $offset - $start;
			$from = max( 0, $col - 80 );
			$text = ( $from > 0 ? '…' : '' ) . substr( $text, $from, 300 ) . ( $from + 300 < strlen( $text ) ? '…' : '' );
		}
		return array( $line, WPAV_Util::clean_text( trim( $text ) ) );
	}
}
