<?php
/**
 * Activity log: every change the plugin makes (repair, quarantine, restore, cleanup, hardening…).
 *
 * @package WPAV
 */

defined( 'ABSPATH' ) || exit;

class WPAV_Log {

	const FILE = 'activity.json';
	const MAX  = 500;

	public static function all() {
		return WPAV_Storage::read_json( self::FILE, array() );
	}

	public static function add( $action, $target = '', $detail = '' ) {
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			$actor = 'WP-CLI';
		} elseif ( wp_doing_cron() ) {
			$actor = 'WP-Cron';
		} else {
			$user  = wp_get_current_user();
			$actor = $user->exists() ? $user->user_login : __( 'unknown', 'wpav' );
		}

		$log = self::all();
		array_unshift(
			$log,
			array(
				'time'   => time(),
				'user'   => $actor,
				'ip'     => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
				'action' => $action,
				'target' => WPAV_Util::truncate( (string) $target, 200 ),
				'detail' => WPAV_Util::truncate( (string) $detail, 300 ),
			)
		);
		WPAV_Storage::write_json( self::FILE, array_slice( $log, 0, self::MAX ) );
	}
}
