<?php
/**
 * Scheduled background scans (WP-Cron) and email alerts.
 *
 * A scheduled scan is started by the recurring hook and then continued by
 * chained single events, each running for a bounded time, until it completes.
 *
 * @package WPAV
 */

defined( 'ABSPATH' ) || exit;

class WPAV_Cron {

	const HOOK        = 'wpav_scheduled_scan';
	const STEP_HOOK   = 'wpav_cron_step';
	const SCAN_OPTION = 'wpav_cron_scan_id';
	const RUN_BUDGET  = 25;

	public static function init() {
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) );
		add_action( self::HOOK, array( __CLASS__, 'run' ) );
		add_action( self::STEP_HOOK, array( __CLASS__, 'continue_scan' ) );
		add_action( 'wpav_scan_finished', array( __CLASS__, 'notify' ), 10, 2 );
	}

	public static function schedules( $schedules ) {
		if ( ! isset( $schedules['weekly'] ) ) {
			$schedules['weekly'] = array(
				'interval' => WEEK_IN_SECONDS,
				'display'  => __( 'Once Weekly', 'wpav' ),
			);
		}
		return $schedules;
	}

	public static function reschedule() {
		wp_clear_scheduled_hook( self::HOOK );
		$schedule = WPAV_Settings::get( 'schedule' );
		if ( in_array( $schedule, array( 'daily', 'weekly' ), true ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, $schedule, self::HOOK );
		}
	}

	public static function unschedule() {
		wp_clear_scheduled_hook( self::HOOK );
		wp_clear_scheduled_hook( self::STEP_HOOK );
	}

	public static function next_run() {
		return wp_next_scheduled( self::HOOK );
	}

	public static function run() {
		if ( WPAV_Scanner::is_running() ) {
			return; // Never interrupt a scan an administrator started.
		}
		$scanner = new WPAV_Scanner( 'cron' );
		$status  = $scanner->start();
		update_site_option( self::SCAN_OPTION, $status['scan_id'] );
		self::continue_scan();
	}

	public static function continue_scan() {
		$scan_id = get_site_option( self::SCAN_OPTION );
		if ( ! $scan_id || WPAV_Scanner::current_scan_id() !== $scan_id ) {
			delete_site_option( self::SCAN_OPTION ); // Superseded by a manual scan.
			return;
		}

		$until = time() + self::RUN_BUDGET;
		do {
			$status = ( new WPAV_Scanner( 'cron' ) )->step();
			if ( is_wp_error( $status ) ) {
				delete_site_option( self::SCAN_OPTION );
				return;
			}
		} while ( ! $status['done'] && time() < $until );

		if ( $status['done'] ) {
			delete_site_option( self::SCAN_OPTION );
		} else {
			wp_schedule_single_event( time() + 10, self::STEP_HOOK );
		}
	}

	/**
	 * Email the site owner after a scheduled scan.
	 */
	public static function notify( array $results, $origin ) {
		if ( 'cron' !== $origin ) {
			return;
		}
		$settings = WPAV_Settings::get();
		$to       = $settings['email'];
		$stats    = $results['stats'];
		if ( ! $to || 'never' === $settings['email_mode'] ) {
			return;
		}
		if ( 'new' === $settings['email_mode'] && ! $stats['new'] ) {
			return;
		}

		$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		if ( $stats['findings'] ) {
			/* translators: 1: site name, 2: number of issues */
			$subject = sprintf( __( '[%1$s] Security alert: %2$d suspicious item(s) found', 'wpav' ), $site, $stats['findings'] );
		} else {
			/* translators: %s: site name */
			$subject = sprintf( __( '[%s] Security scan: no issues found', 'wpav' ), $site );
		}

		$lines   = array();
		$lines[] = sprintf( __( 'Scheduled scan finished for %s', 'wpav' ), home_url() );
		$lines[] = '';
		/* translators: 1: files scanned, 2: verified */
		$lines[] = sprintf( __( 'Files scanned: %1$s (%2$s verified against WordPress.org)', 'wpav' ), number_format_i18n( $stats['scanned'] ), number_format_i18n( $stats['verified'] ) );
		/* translators: 1: total, 2: new */
		$lines[] = sprintf( __( 'Suspicious items: %1$d (%2$d new since the last scan)', 'wpav' ), $stats['findings'], $stats['new'] );
		/* translators: 1: critical, 2: high, 3: medium, 4: low */
		$lines[] = sprintf( __( 'Critical: %1$d  High: %2$d  Medium: %3$d  Low: %4$d', 'wpav' ), $stats['by_severity']['critical'], $stats['by_severity']['high'], $stats['by_severity']['medium'], $stats['by_severity']['low'] );
		$vulnerable = 0;
		foreach ( $results['findings'] as $finding ) {
			if ( 'vulnerability' === $finding['type'] && 'open' === $finding['status'] && empty( $finding['ignored'] ) ) {
				$vulnerable++;
			}
		}
		if ( $vulnerable ) {
			/* translators: %d: number of components */
			$lines[] = sprintf( __( 'Components with known vulnerabilities: %d — update them as soon as possible', 'wpav' ), $vulnerable );
		}
		if ( ! empty( $results['changes'] ) ) {
			/* translators: 1: new, 2: modified, 3: deleted */
			$lines[] = sprintf( __( 'File changes since last scan: %1$d new, %2$d modified, %3$d deleted', 'wpav' ), $results['changes']['new'], $results['changes']['modified'], $results['changes']['deleted'] );
		}

		$new_items = array();
		foreach ( $results['findings'] as $finding ) {
			if ( 'open' === $finding['status'] && empty( $finding['ignored'] ) && ! empty( $finding['is_new'] ) ) {
				$new_items[] = sprintf( '  [%s] %s — %s', strtoupper( $finding['severity'] ), $finding['rel'], $finding['issues'][0]['title'] );
			}
		}
		if ( $new_items ) {
			$lines[] = '';
			$lines[] = __( 'New findings:', 'wpav' );
			$lines   = array_merge( $lines, array_slice( $new_items, 0, 50 ) );
			if ( count( $new_items ) > 50 ) {
				/* translators: %d: number of additional items */
				$lines[] = sprintf( __( '  …and %d more', 'wpav' ), count( $new_items ) - 50 );
			}
		}
		$lines[] = '';
		$lines[] = __( 'Full report:', 'wpav' ) . ' ' . WPAV_Util::page_url( 'wpav-report' );

		wp_mail( $to, $subject, implode( "\n", $lines ) );
	}
}
