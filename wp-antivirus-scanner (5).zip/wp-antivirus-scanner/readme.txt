=== WP Anti-Virus Scanner ===
Tags: security, malware, antivirus, scanner, integrity
Requires at least: 5.3
Tested up to: 6.8
Requires PHP: 7.2
Stable tag: 3.0.1
License: GPLv2 or later

Scans WordPress files and the database for malware, verifies core and WordPress.org plugins and themes against the official files for the installed version, repairs infected files from clean originals with automatic backups, flags known vulnerabilities and walks you through post-hack cleanup.

== Description ==

**Scan** (Anti-Virus → Scan)

* Walks every PHP, JS, HTML, .htaccess, .user.ini and .ico file in the installation (including wp-content outside ABSPATH).
* WordPress core: every file is compared with the official md5 checksum for the *installed version and locale* (api.wordpress.org). Extra files inside wp-admin/ and wp-includes/ are flagged.
* Plugins: each plugin is looked up on WordPress.org for its *installed version* (downloads.wordpress.org/plugin-checksums). Modified files and extra PHP files are flagged.
* Everything (custom plugins, themes, mu-plugins, uploads, root files) is also checked against ~30 malware signatures: eval/base64 backdoors, web shells, request-driven function calls, obfuscation, hidden includes, JS injections, SEO-spam redirects, PHP inside images, PHP files in uploads.
* Files that match the official checksum are trusted and not signature-scanned (no false positives on clean core/plugin code).
* The scan runs in small AJAX batches, so it never hits PHP time limits.

**Report** (Anti-Virus → Report)

* File path, line number, detection name, severity and the suspicious code excerpt.
* "View changes vs. official file" downloads the original and shows the exact added/removed lines with line numbers, so injected code is visible even when no signature matched.
* Filter by severity, location and path.

**Repair** (Anti-Virus → Repair)

* Only WordPress core files and WordPress.org plugin files that differ from the official version can be repaired.
* The clean file is downloaded for the same version (SVN tag first, official release zip as fallback) and is verified against the official md5 before anything is written.
* A backup of the current file is created first; if the backup fails, the file is not touched.
* Custom themes, custom/premium plugins, mu-plugins, uploads and files that are not part of any official package are **never replaced**; they are listed under "Manual review required".
* Safety net: if most files of a "WordPress.org" plugin differ from the official copy (a fork or custom build that shares the slug), auto-repair is disabled for it.
* Respects DISALLOW_FILE_MODS.

**Backups** (Anti-Virus → Backups)

* Stored as non-executable .bak files in a random, .htaccess-protected folder inside uploads (wpav-<random>).
* Restore (the current file is backed up again first) or delete.

**Quarantine**

* Files that should not exist (extra files in core or WordPress.org plugins, PHP in uploads, suspicious files outside any theme/plugin) can be quarantined: moved to Backups and removed from the site. Custom themes/plugins and config files are never quarantined.

**Database scan**

* Posts and options are checked for injected scripts, hidden iframes and hidden SEO-spam links; siteurl/home are checked for tampering; administrator accounts created in the last 7 days are flagged. Database content is report-only.

**File change detection**

* Every scan is compared with the previous one: new, modified and deleted files (excluding files verified against WordPress.org).

**Mark as safe**

* Hide a false positive. It reappears automatically if the file or content changes.

**Scheduled scans & email alerts** (Settings)

* Daily or weekly background scans via WP-Cron, with email only when new issues appear (or always / never).

**Hardening**

* Checklist with a score: outdated core/plugins/themes, inactive plugins, debug display, salts, HTTPS, admin username, wp-config permissions, PHP version.
* One-click protections: block PHP execution in uploads, disable the file editor, disable XML-RPC, block username enumeration.

**Also**

* Scan history, CSV export, dashboard widget, menu badge with critical/high count, path exclusions and max file size.
* WP-CLI: wp antivirus scan | report [--format=csv|json] | repair [--all] | quarantine [--all].

**WordPress.org themes** (v3)

* Themes published on WordPress.org are verified file-by-file against the official package of the installed version and can be repaired like plugins. Custom and premium themes remain report-only.

**Known vulnerabilities** (v3)

* Installed WordPress, plugin and theme versions are checked against the free WPVulnerability.net database: CVE, CVSS score, fixed-in version and a details link. Plugins closed on WordPress.org are flagged. Only slugs and versions are sent; results are cached for 12 hours.

**Post-hack Cleanup** (v3)

* Lists every administrator read directly from the database and flags accounts hidden from the Users screen; one-click demote.
* Lists WP-Cron tasks, flags tasks whose arguments contain code or that have no registered handler, and deletes them.
* Lists must-use plugins and drop-ins with their scan result.
* Force a password reset for privileged users (with reset emails), log out all users except you, and generate new security keys in wp-config.php (backed up and syntax-checked first).

**Deeper scanning** (v3)

* Database: post meta (page-builder data, including slashed JSON), approved comments, scheduled-task arguments, and every site on multisite.
* Uploads: PHP hidden in images (head/tail sampling keeps large libraries fast), scripts in SVG files, hidden .php files and disguised names like photo.jpg.php.

**Activity log & alerts** (v3)

* Every repair, quarantine, restore, cleanup and hardening action is logged with user and IP.
* Site-wide admin notice while critical issues are open (dismissible until the next scan).

== Notes ==

* Requires outbound HTTPS to api.wordpress.org, downloads.wordpress.org, core.svn.wordpress.org and plugins.svn.wordpress.org.
* Multisite: the menu lives in Network Admin and requires manage_network_options.
* Signatures report *suspicious* code. A hit in custom code is not always malware; review before deleting.
* Multisite: the database scan covers every site (up to 500).
* Uninstalling the plugin deletes its folder in uploads (including backups), its settings and scheduled events.
