<?php
/**
 * Removes the plugin's storage directory (scan data, backups, cache), options and cron jobs.
 *
 * @package WPAV
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

require_once __DIR__ . '/includes/class-wpav-storage.php';

$wpav_dir = WPAV_Storage::existing_dir();
if ( $wpav_dir ) {
	WPAV_Storage::rrmdir( $wpav_dir );
}

wp_clear_scheduled_hook( 'wpav_scheduled_scan' );
wp_clear_scheduled_hook( 'wpav_cron_step' );

delete_option( WPAV_Storage::TOKEN_OPTION );
foreach ( array( 'wpav_settings', 'wpav_summary', 'wpav_cron_scan_id' ) as $wpav_option ) {
	delete_site_option( $wpav_option );
}

global $wpdb;
// Cached vulnerability lookups and per-user notice dismissals.
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_site\_transient\_wpav\_vuln\_%' OR option_name LIKE '\_site\_transient\_timeout\_wpav\_vuln\_%' OR option_name LIKE '\_transient\_wpav\_vuln\_%' OR option_name LIKE '\_transient\_timeout\_wpav\_vuln\_%'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
if ( is_multisite() ) {
	$wpdb->query( "DELETE FROM {$wpdb->sitemeta} WHERE meta_key LIKE '\_site\_transient\_%wpav\_vuln\_%'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}
delete_metadata( 'user', 0, 'wpav_notice_dismissed', '', true );
