/* WP Anti-Virus Scanner admin UI. */
(function () {
	'use strict';

	var cfg = window.wpavData || {};
	var t = cfg.i18n || {};

	function $(sel, ctx) { return (ctx || document).querySelector(sel); }
	function $$(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }
	function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

	function post(action, data) {
		var body = new FormData();
		body.append('action', action);
		body.append('nonce', cfg.nonce);
		Object.keys(data || {}).forEach(function (k) { body.append(k, data[k]); });

		return fetch(cfg.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body })
			.then(function (res) {
				return res.text().then(function (text) {
					var json;
					try { json = JSON.parse(text); } catch (e) {
						throw new Error('HTTP ' + res.status + ' (invalid response — check the PHP error log)');
					}
					if (!json.success) {
						throw new Error((json.data && json.data.message) || 'Request failed');
					}
					return json.data;
				});
			});
	}

	/* ---- Scan ------------------------------------------------------- */

	var scanBtn = $('#wpav-scan-start');
	if (scanBtn) {
		scanBtn.addEventListener('click', function () {
			var box = $('#wpav-progress');
			var fill = $('.wpav-bar-fill', box);
			var msg = $('.wpav-progress-msg', box);

			function render(s) {
				fill.style.width = s.percent + '%';
				msg.textContent = s.message + ' (' + s.percent + '%)';
			}

			async function run() {
				var state = await post('wpav_scan_start');
				render(state);
				var failures = 0;
				while (!state.done) {
					try {
						state = await post('wpav_scan_step');
						failures = 0;
						render(state);
					} catch (err) {
						if (++failures > 3) { throw err; }
						msg.textContent = t.retrying;
						await sleep(2000 * failures);
					}
				}
				msg.textContent = t.done;
				window.location.href = cfg.reportUrl;
			}

			scanBtn.disabled = true;
			box.hidden = false;
			box.classList.remove('is-error');
			fill.style.width = '0';
			msg.textContent = t.starting;

			run().catch(function (err) {
				box.classList.add('is-error');
				msg.textContent = t.error + ' ' + err.message;
				scanBtn.disabled = false;
			});
		});
	}

	/* ---- Report filters -------------------------------------------- */

	var sevSel = $('#wpav-filter-severity');
	var typeSel = $('#wpav-filter-type');
	var textIn = $('#wpav-filter-text');
	var inactiveCb = $('#wpav-filter-inactive');

	function applyFilters() {
		var min = parseInt(sevSel.value, 10) || 1;
		var type = typeSel.value;
		var q = textIn.value.trim().toLowerCase();
		var showInactive = inactiveCb && inactiveCb.checked;
		$$('.wpav-finding').forEach(function (el) {
			var show = parseInt(el.dataset.severity, 10) >= min &&
				(!type || el.dataset.type === type) &&
				(!q || el.dataset.text.indexOf(q) !== -1) &&
				(showInactive || el.dataset.state === 'active');
			el.hidden = !show;
		});
	}
	if (sevSel && typeSel && textIn) {
		[sevSel, typeSel, inactiveCb].forEach(function (el) { if (el) { el.addEventListener('change', applyFilters); } });
		textIn.addEventListener('input', applyFilters);

		// Deep links (#f-id) from the Repair screen should show the target even if it is inactive.
		var target = window.location.hash && document.getElementById(window.location.hash.slice(1));
		if (target && target.classList.contains('wpav-finding')) {
			target.hidden = false;
			target.scrollIntoView();
		}
	}

	/* ---- Diff viewer ----------------------------------------------- */

	function renderDiff(panel, data) {
		panel.textContent = '';
		if (!data.lines.length) {
			panel.textContent = t.noDiff;
			return;
		}
		var table = document.createElement('table');
		table.className = 'wpav-diff';
		var head = table.createTHead().insertRow();
		[t.change, t.line, t.code].forEach(function (label) {
			var th = document.createElement('th');
			th.textContent = label;
			head.appendChild(th);
		});
		var tbody = table.createTBody();
		data.lines.forEach(function (l) {
			var row = tbody.insertRow();
			row.className = l.t === '+' ? 'is-add' : 'is-del';
			row.insertCell().textContent = l.t === '+' ? t.added : t.removed;
			row.insertCell().textContent = l.line;
			var code = document.createElement('code');
			code.textContent = l.code;
			row.insertCell().appendChild(code);
		});
		panel.appendChild(table);
		if (data.truncated) {
			var p = document.createElement('p');
			p.textContent = t.truncated;
			panel.appendChild(p);
		}
	}

	/* ---- Click handlers --------------------------------------------- */

	document.addEventListener('click', function (ev) {
		var diffBtn = ev.target.closest('.wpav-diff-btn');
		if (diffBtn) {
			var panel = document.getElementById('wpav-diff-' + diffBtn.dataset.id);
			if (!panel) { return; }
			if (panel.dataset.loaded) {
				panel.hidden = !panel.hidden;
				return;
			}
			panel.hidden = false;
			panel.textContent = t.loadingDiff;
			diffBtn.disabled = true;
			post('wpav_diff', { id: diffBtn.dataset.id })
				.then(function (data) { renderDiff(panel, data); panel.dataset.loaded = '1'; })
				.catch(function (err) { panel.textContent = t.error + ' ' + err.message; })
				.then(function () { diffBtn.disabled = false; });
			return;
		}

		// Single-item actions (repair, quarantine, ignore, restore, delete backup): run, then reload.
		var actionBtn = ev.target.closest('.wpav-action');
		if (actionBtn) {
			if (actionBtn.dataset.confirm && !window.confirm(actionBtn.dataset.confirm)) { return; }
			actionBtn.disabled = true;
			var original = actionBtn.textContent;
			actionBtn.textContent = t.working;

			// data-id plus any data-arg-foo="…" attributes are sent as POST fields.
			var fields = { id: actionBtn.dataset.id || '' };
			Object.keys(actionBtn.dataset).forEach(function (key) {
				if (key.indexOf('arg') === 0 && key.length > 3) {
					fields[key.charAt(3).toLowerCase() + key.slice(4)] = actionBtn.dataset[key];
				}
			});

			post(actionBtn.dataset.action, fields)
				.then(function (res) {
					if (res && res.message && actionBtn.dataset.action !== 'wpav_ignore' && actionBtn.dataset.action !== 'wpav_unignore') {
						window.alert(res.message);
					}
					if (res && res.relogin) {
						window.location.href = cfg.loginUrl;
						return;
					}
					window.location.reload();
				})
				.catch(function (err) {
					window.alert(t.error + ' ' + err.message);
					actionBtn.disabled = false;
					actionBtn.textContent = original;
				});
			return;
		}

		var hardenBtn = ev.target.closest('.wpav-harden');
		if (hardenBtn) {
			hardenBtn.disabled = true;
			post('wpav_harden', { key: hardenBtn.dataset.key, enable: hardenBtn.dataset.enable })
				.then(function () { window.location.reload(); })
				.catch(function (err) { window.alert(t.error + ' ' + err.message); hardenBtn.disabled = false; });
		}
	});

	/* ---- Bulk repair / quarantine ----------------------------------- */

	$$('.wpav-select-all').forEach(function (all) {
		all.addEventListener('change', function () {
			$$('.wpav-bulk-cb[data-group="' + all.dataset.group + '"]').forEach(function (cb) {
				if (!cb.disabled) { cb.checked = all.checked; }
			});
		});
	});

	$$('.wpav-bulk-run').forEach(function (btn) {
		btn.addEventListener('click', async function () {
			var boxes = $$('.wpav-bulk-cb[data-group="' + btn.dataset.group + '"]:checked');
			if (!boxes.length) {
				window.alert(t.selectFiles);
				return;
			}
			if (!window.confirm((t[btn.dataset.confirmKey] || '').replace('%d', boxes.length))) {
				return;
			}
			btn.disabled = true;
			for (var i = 0; i < boxes.length; i++) {
				var cb = boxes[i];
				var status = $('.wpav-status', cb.closest('tr'));
				status.className = 'wpav-status is-working';
				status.textContent = t.working;
				try {
					var res = await post(btn.dataset.action, { id: cb.value });
					status.className = 'wpav-status is-ok';
					status.textContent = res.message;
					cb.checked = false;
					cb.disabled = true;
				} catch (err) {
					status.className = 'wpav-status is-error';
					status.textContent = err.message;
				}
			}
			btn.disabled = false;
		});
	});
}());
