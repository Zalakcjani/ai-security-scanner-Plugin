<?php
/**
 * Repair & Quarantine screen.
 *
 * @package WPAV
 * @var WPAV_Admin $this
 * @var array|null $results
 */

defined( 'ABSPATH' ) || exit;

if ( ! $results ) {
	$this->no_results();
	return;
}

$wpav_repair     = array();
$wpav_quarantine = array();
$wpav_manual     = array();
foreach ( $results['findings'] as $f ) {
	if ( $f['ignored'] ) {
		continue;
	}
	if ( $f['repairable'] || 'repaired' === $f['status'] ) {
		$wpav_repair[] = $f;
	} elseif ( WPAV_Util::can_quarantine( $f ) || 'quarantined' === $f['status'] ) {
		$wpav_quarantine[] = $f;
	} else {
		$wpav_manual[] = $f;
	}
}
$wpav_can_modify = WPAV_Repair::can_modify();

/**
 * Checkbox table shared by the repair and quarantine sections.
 */
$wpav_table = function ( array $items, $group, $done_status, $done_label, $open_label ) use ( $wpav_can_modify ) {
	?>
	<table class="widefat striped wpav-bulk-table" data-group="<?php echo esc_attr( $group ); ?>">
		<thead>
			<tr>
				<td class="check-column"><input type="checkbox" class="wpav-select-all" data-group="<?php echo esc_attr( $group ); ?>" <?php disabled( ! $wpav_can_modify ); ?>></td>
				<th><?php esc_html_e( 'File', 'wpav' ); ?></th>
				<th><?php esc_html_e( 'Component', 'wpav' ); ?></th>
				<th><?php esc_html_e( 'Detection', 'wpav' ); ?></th>
				<th><?php esc_html_e( 'Severity', 'wpav' ); ?></th>
				<th><?php esc_html_e( 'Status', 'wpav' ); ?></th>
			</tr>
		</thead>
		<tbody>
		<?php foreach ( $items as $f ) : ?>
			<?php $done = $done_status === $f['status']; ?>
			<tr>
				<th class="check-column"><input type="checkbox" class="wpav-bulk-cb" data-group="<?php echo esc_attr( $group ); ?>" value="<?php echo esc_attr( $f['id'] ); ?>" <?php disabled( $done || ! $wpav_can_modify ); ?>></th>
				<td><a href="<?php echo esc_url( WPAV_Util::page_url( 'wpav-report' ) . '#f-' . $f['id'] ); ?>"><code><?php echo esc_html( $f['rel'] ); ?></code></a></td>
				<td><?php echo esc_html( trim( $f['component'] . ' ' . $f['version'] ) ); ?></td>
				<td><?php echo esc_html( $f['issues'][0]['title'] ); ?></td>
				<td><?php echo $this->severity_badge( $f['severity'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
				<td class="wpav-status <?php echo $done ? 'is-ok' : ''; ?>"><?php echo esc_html( $done ? $done_label : $open_label ); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<?php
};
?>
<?php if ( ! $wpav_can_modify ) : ?>
	<div class="notice notice-error inline"><p><?php esc_html_e( 'DISALLOW_FILE_MODS is enabled, so this site does not allow plugins to change files. Repair and quarantine are disabled.', 'wpav' ); ?></p></div>
<?php endif; ?>

<div class="wpav-card">
	<h2><?php esc_html_e( '1. Repair: WordPress core, WordPress.org plugins & themes', 'wpav' ); ?></h2>
	<p><?php esc_html_e( 'Each selected file is backed up, then replaced with the official file for the same version downloaded from WordPress.org. The download is verified against the official checksum before anything is written.', 'wpav' ); ?></p>
	<?php if ( ! $wpav_repair ) : ?>
		<p><em><?php esc_html_e( 'No repairable files.', 'wpav' ); ?></em></p>
	<?php else : ?>
		<?php $wpav_table( $wpav_repair, 'repair', 'repaired', __( 'Repaired', 'wpav' ), __( 'Infected / modified', 'wpav' ) ); ?>
		<p><button type="button" class="button button-primary wpav-bulk-run" data-group="repair" data-action="wpav_repair" data-confirm-key="confirmRepair" <?php disabled( ! $wpav_can_modify ); ?>><?php esc_html_e( 'Backup & Repair Selected', 'wpav' ); ?></button></p>
	<?php endif; ?>
</div>

<div class="wpav-card">
	<h2><?php esc_html_e( '2. Quarantine: files that should not exist', 'wpav' ); ?></h2>
	<p><?php esc_html_e( 'Extra files inside WordPress core or WordPress.org plugins/themes, PHP files in uploads and suspicious files outside any theme/plugin. There is no clean original, so they are moved to Backups (removed from the site) and can be restored if needed.', 'wpav' ); ?></p>
	<?php if ( ! $wpav_quarantine ) : ?>
		<p><em><?php esc_html_e( 'Nothing to quarantine.', 'wpav' ); ?></em></p>
	<?php else : ?>
		<?php $wpav_table( $wpav_quarantine, 'quarantine', 'quarantined', __( 'Quarantined', 'wpav' ), __( 'Suspicious', 'wpav' ) ); ?>
		<p><button type="button" class="button wpav-danger wpav-bulk-run" data-group="quarantine" data-action="wpav_quarantine" data-confirm-key="confirmQuarantine" <?php disabled( ! $wpav_can_modify ); ?>><?php esc_html_e( 'Backup & Quarantine Selected', 'wpav' ); ?></button></p>
	<?php endif; ?>
</div>

<div class="wpav-card">
	<h2><?php esc_html_e( '3. Manual review required', 'wpav' ); ?></h2>
	<p><?php esc_html_e( 'Custom/premium themes and plugins, must-use plugins, configuration files, database content and vulnerable components are never changed automatically. Clean them by hand, or reinstall the theme/plugin from its vendor.', 'wpav' ); ?></p>
	<?php if ( ! $wpav_manual ) : ?>
		<p><em><?php esc_html_e( 'Nothing needs manual review.', 'wpav' ); ?></em></p>
	<?php else : ?>
		<table class="widefat striped">
			<thead><tr><th><?php esc_html_e( 'File / item', 'wpav' ); ?></th><th><?php esc_html_e( 'Location', 'wpav' ); ?></th><th><?php esc_html_e( 'Severity', 'wpav' ); ?></th><th><?php esc_html_e( 'What to do', 'wpav' ); ?></th></tr></thead>
			<tbody>
			<?php foreach ( $wpav_manual as $f ) : ?>
				<tr>
					<td><a href="<?php echo esc_url( WPAV_Util::page_url( 'wpav-report' ) . '#f-' . $f['id'] ); ?>"><code><?php echo esc_html( $f['rel'] ); ?></code></a></td>
					<td><?php echo esc_html( WPAV_Util::source_label( $f ) ); ?></td>
					<td><?php echo $this->severity_badge( $f['severity'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
					<td><?php echo esc_html( WPAV_Util::manual_reason( $f ) ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>
</div>
