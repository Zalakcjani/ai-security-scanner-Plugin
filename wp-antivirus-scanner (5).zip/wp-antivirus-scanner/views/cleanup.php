<?php
/**
 * Post-hack cleanup screen.
 *
 * @package WPAV
 * @var WPAV_Admin $this
 * @var array[]    $admins
 * @var array[]    $events
 * @var array[]    $autoload
 * @var array|null $results
 */

defined( 'ABSPATH' ) || exit;

$wpav_flagged = array();
if ( $results ) {
	foreach ( $results['findings'] as $f ) {
		if ( $f['path'] && 'open' === $f['status'] ) {
			$wpav_flagged[ $f['path'] ] = $f;
		}
	}
}
$wpav_hidden = count( wp_list_filter( $admins, array( 'hidden' => true ) ) );
?>
<div class="wpav-card">
	<p><?php esc_html_e( 'Removing malware is only half the job. Attackers usually keep a way back in: stolen passwords, logged-in sessions, extra administrator accounts, scheduled tasks that re-download the malware, or code in must-use plugins. After cleaning files, work through this page from top to bottom.', 'wpav' ); ?></p>
	<ol class="wpav-steps">
		<li><?php esc_html_e( 'Remove administrator accounts you do not recognise.', 'wpav' ); ?></li>
		<li><?php esc_html_e( 'Delete suspicious scheduled tasks and check must-use plugins.', 'wpav' ); ?></li>
		<li><?php esc_html_e( 'Reset passwords, log everyone out and generate new security keys.', 'wpav' ); ?></li>
		<li><?php esc_html_e( 'Update everything and apply the Hardening fixes, then scan again.', 'wpav' ); ?></li>
	</ol>
</div>

<div class="wpav-card">
	<h2><?php esc_html_e( '1. Administrator accounts', 'wpav' ); ?></h2>
	<?php if ( $wpav_hidden ) : ?>
		<div class="notice notice-error inline"><p>
			<?php
			/* translators: %d: number of accounts */
			printf( esc_html( _n( '%d administrator is hidden from the Users screen. This is a typical backdoor.', '%d administrators are hidden from the Users screen. This is a typical backdoor.', $wpav_hidden, 'wpav' ) ), (int) $wpav_hidden );
			?>
		</p></div>
	<?php endif; ?>
	<table class="widefat striped">
		<thead><tr><th><?php esc_html_e( 'Username', 'wpav' ); ?></th><th><?php esc_html_e( 'Email', 'wpav' ); ?></th><th><?php esc_html_e( 'Registered', 'wpav' ); ?></th><th><?php esc_html_e( 'Status', 'wpav' ); ?></th><th></th></tr></thead>
		<tbody>
		<?php foreach ( $admins as $admin ) : ?>
			<tr>
				<td><strong><?php echo esc_html( $admin['login'] ); ?></strong></td>
				<td><?php echo esc_html( $admin['email'] ); ?></td>
				<td><?php echo esc_html( $this->date( $admin['registered_ts'] ) ); ?></td>
				<td>
					<?php if ( $admin['hidden'] ) : ?>
						<span class="wpav-badge sev-critical"><?php esc_html_e( 'Hidden', 'wpav' ); ?></span>
					<?php elseif ( $admin['registered_ts'] > time() - WPAV_DB_Scanner::NEW_ADMIN_DAYS * DAY_IN_SECONDS ) : ?>
						<span class="wpav-badge sev-medium"><?php esc_html_e( 'New', 'wpav' ); ?></span>
					<?php else : ?>
						<span class="wpav-pill"><?php esc_html_e( 'Visible', 'wpav' ); ?></span>
					<?php endif; ?>
					<?php if ( get_current_user_id() === $admin['id'] ) : ?>
						<span class="wpav-pill is-ok"><?php esc_html_e( 'You', 'wpav' ); ?></span>
					<?php endif; ?>
				</td>
				<td class="wpav-right">
					<?php if ( get_current_user_id() !== $admin['id'] ) : ?>
						<button type="button" class="button wpav-danger wpav-action" data-action="wpav_demote" data-id="<?php echo esc_attr( $admin['id'] ); ?>"
							data-confirm="<?php echo esc_attr( sprintf( /* translators: %s: login */ __( 'Remove administrator rights from %s and log them out? Their content is kept; you can delete the account later from Users.', 'wpav' ), $admin['login'] ) ); ?>">
							<?php esc_html_e( 'Demote to subscriber', 'wpav' ); ?>
						</button>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>

<div class="wpav-card">
	<h2><?php esc_html_e( '2. Scheduled tasks (WP-Cron)', 'wpav' ); ?></h2>
	<p><?php esc_html_e( 'Malware often schedules a task that re-downloads itself. Tasks with no registered code usually belong to a removed plugin; tasks whose arguments contain code are almost always malicious.', 'wpav' ); ?></p>
	<table class="widefat striped wpav-cron">
		<thead><tr><th><?php esc_html_e( 'Hook', 'wpav' ); ?></th><th><?php esc_html_e( 'Next run', 'wpav' ); ?></th><th><?php esc_html_e( 'Recurrence', 'wpav' ); ?></th><th><?php esc_html_e( 'Arguments', 'wpav' ); ?></th><th><?php esc_html_e( 'Status', 'wpav' ); ?></th><th></th></tr></thead>
		<tbody>
		<?php
		// Most suspicious first: code in arguments, then tasks with no registered code.
		$wpav_rank = static function ( $event ) {
			return $event['args_issues'] ? 0 : ( $event['has_callback'] ? 2 : 1 );
		};
		usort(
			$events,
			static function ( $a, $b ) use ( $wpav_rank ) {
				return $wpav_rank( $a ) - $wpav_rank( $b );
			}
		);
		foreach ( $events as $event ) :
			?>
			<tr>
				<td><code><?php echo esc_html( $event['hook'] ); ?></code></td>
				<td><?php echo esc_html( $this->date( $event['timestamp'] ) ); ?></td>
				<td><?php echo esc_html( $event['schedule'] ? $event['schedule'] : __( 'once', 'wpav' ) ); ?></td>
				<td><?php echo '[]' === $event['args_preview'] ? '—' : '<code>' . esc_html( $event['args_preview'] ) . '</code>'; ?></td>
				<td>
					<?php if ( $event['args_issues'] ) : ?>
						<span class="wpav-badge sev-critical"><?php esc_html_e( 'Code in arguments', 'wpav' ); ?></span>
					<?php elseif ( ! $event['has_callback'] ) : ?>
						<span class="wpav-badge sev-low"><?php esc_html_e( 'No registered code', 'wpav' ); ?></span>
					<?php else : ?>
						<span class="wpav-pill is-ok"><?php esc_html_e( 'OK', 'wpav' ); ?></span>
					<?php endif; ?>
				</td>
				<td class="wpav-right">
					<button type="button" class="button-link-delete wpav-action" data-action="wpav_delete_cron" data-id="<?php echo esc_attr( $event['id'] ); ?>" data-confirm="<?php esc_attr_e( 'Delete this scheduled task? If it belongs to an active plugin, that plugin may schedule it again (which is harmless).', 'wpav' ); ?>"><?php esc_html_e( 'Delete', 'wpav' ); ?></button>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>

<div class="wpav-card">
	<h2><?php esc_html_e( '3. Must-use plugins & drop-ins', 'wpav' ); ?></h2>
	<p><?php esc_html_e( 'These files load on every request and cannot be deactivated from the Plugins screen, which makes them a favourite place for persistent malware. Remove any you did not install (via FTP / file manager).', 'wpav' ); ?></p>
	<?php if ( ! $autoload ) : ?>
		<p><em><?php esc_html_e( 'None installed.', 'wpav' ); ?></em></p>
	<?php else : ?>
		<table class="widefat striped">
			<thead><tr><th><?php esc_html_e( 'Type', 'wpav' ); ?></th><th><?php esc_html_e( 'Name', 'wpav' ); ?></th><th><?php esc_html_e( 'File', 'wpav' ); ?></th><th><?php esc_html_e( 'Scan result', 'wpav' ); ?></th></tr></thead>
			<tbody>
			<?php foreach ( $autoload as $item ) : ?>
				<?php $wpav_f = isset( $wpav_flagged[ $item['path'] ] ) ? $wpav_flagged[ $item['path'] ] : null; ?>
				<tr>
					<td><?php echo esc_html( $item['type'] ); ?></td>
					<td><?php echo esc_html( $item['name'] ); ?></td>
					<td><code><?php echo esc_html( WPAV_Util::rel( $item['path'] ) ); ?></code></td>
					<td>
						<?php if ( $wpav_f ) : ?>
							<a href="<?php echo esc_url( WPAV_Util::page_url( 'wpav-report' ) . '#f-' . $wpav_f['id'] ); ?>"><?php echo $this->severity_badge( $wpav_f['severity'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <?php echo esc_html( $wpav_f['issues'][0]['title'] ); ?></a>
						<?php else : ?>
							<span class="wpav-pill"><?php esc_html_e( 'No detections', 'wpav' ); ?></span>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>
</div>

<div class="wpav-card">
	<h2><?php esc_html_e( '4. Lock out the attacker', 'wpav' ); ?></h2>
	<table class="widefat wpav-lockout">
		<tbody>
			<tr>
				<td>
					<strong><?php esc_html_e( 'Force password reset for privileged users', 'wpav' ); ?></strong>
					<p class="description"><?php esc_html_e( 'Administrators (including hidden ones), editors and shop managers get a random password and are logged out. Your own account is skipped — change your password yourself.', 'wpav' ); ?></p>
				</td>
				<td class="wpav-right">
					<button type="button" class="button wpav-action" data-action="wpav_reset_passwords" data-arg-send="1" data-confirm="<?php esc_attr_e( 'Reset passwords for all privileged users (except you) and email them a reset link?', 'wpav' ); ?>"><?php esc_html_e( 'Reset & email links', 'wpav' ); ?></button>
				</td>
			</tr>
			<tr>
				<td>
					<strong><?php esc_html_e( 'Log out all users', 'wpav' ); ?></strong>
					<p class="description"><?php esc_html_e( 'Ends every login session on every device, except the browser you are using now.', 'wpav' ); ?></p>
				</td>
				<td class="wpav-right">
					<button type="button" class="button wpav-action" data-action="wpav_logout_all" data-confirm="<?php esc_attr_e( 'Log out every user on every device (except you)?', 'wpav' ); ?>"><?php esc_html_e( 'Log out everyone', 'wpav' ); ?></button>
				</td>
			</tr>
			<tr>
				<td>
					<strong><?php esc_html_e( 'Generate new security keys', 'wpav' ); ?></strong>
					<p class="description">
						<?php esc_html_e( 'Replaces the keys and salts in wp-config.php (backed up and syntax-checked first). Stolen login cookies stop working immediately. You will have to log in again.', 'wpav' ); ?>
						<?php if ( ! WPAV_Cleanup::config_path() || ! is_writable( WPAV_Cleanup::config_path() ) ) : ?>
							<br><strong><?php esc_html_e( 'wp-config.php is not writable; keys stored in the database will be rotated instead.', 'wpav' ); ?></strong>
						<?php endif; ?>
					</p>
				</td>
				<td class="wpav-right">
					<button type="button" class="button button-primary wpav-action" data-action="wpav_regenerate_keys" data-confirm="<?php esc_attr_e( 'Generate new security keys? Everyone, including you, will be logged out.', 'wpav' ); ?>" <?php disabled( ! WPAV_Repair::can_modify() ); ?>><?php esc_html_e( 'Generate new keys', 'wpav' ); ?></button>
				</td>
			</tr>
		</tbody>
	</table>
</div>
