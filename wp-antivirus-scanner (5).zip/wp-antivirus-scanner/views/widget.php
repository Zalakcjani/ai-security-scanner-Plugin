<?php
/**
 * Dashboard widget.
 *
 * @package WPAV
 * @var WPAV_Admin $this
 * @var array|null $summary
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wpav-widget">
	<?php if ( ! $summary ) : ?>
		<p><?php esc_html_e( 'This site has not been scanned yet.', 'wpav' ); ?></p>
		<p><a class="button button-primary" href="<?php echo esc_url( WPAV_Util::page_url( 'wpav' ) ); ?>"><?php esc_html_e( 'Run a scan', 'wpav' ); ?></a></p>
	<?php else : ?>
		<?php $s = $summary['stats']; ?>
		<p class="wpav-widget-status <?php echo $s['findings'] ? 'is-bad' : 'is-ok'; ?>">
			<span class="dashicons <?php echo $s['findings'] ? 'dashicons-warning' : 'dashicons-yes-alt'; ?>"></span>
			<?php
			if ( $s['findings'] ) {
				/* translators: %d: number of issues */
				printf( esc_html( _n( '%d security issue needs attention', '%d security issues need attention', $s['findings'], 'wpav' ) ), (int) $s['findings'] );
			} else {
				esc_html_e( 'No security issues found', 'wpav' );
			}
			?>
		</p>
		<?php if ( $s['findings'] ) : ?>
			<p>
				<?php echo $this->severity_badge( 'critical' ) . ' ' . (int) $s['by_severity']['critical']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				&nbsp; <?php echo $this->severity_badge( 'high' ) . ' ' . (int) $s['by_severity']['high']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				&nbsp; <?php echo $this->severity_badge( 'medium' ) . ' ' . (int) $s['by_severity']['medium']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</p>
		<?php endif; ?>
		<p class="description">
			<?php
			/* translators: 1: date, 2: files */
			printf( esc_html__( 'Last scan %1$s — %2$s files checked.', 'wpav' ), esc_html( $this->date( $summary['finished'] ) ), esc_html( number_format_i18n( $s['scanned'] ) ) );
			?>
		</p>
		<p>
			<a class="button button-primary" href="<?php echo esc_url( WPAV_Util::page_url( 'wpav-report' ) ); ?>"><?php esc_html_e( 'View report', 'wpav' ); ?></a>
			<a class="button" href="<?php echo esc_url( WPAV_Util::page_url( 'wpav' ) ); ?>"><?php esc_html_e( 'Scan now', 'wpav' ); ?></a>
		</p>
	<?php endif; ?>
</div>
