<?php
/**
 * Activity log screen.
 *
 * @package WPAV
 * @var WPAV_Admin $this
 * @var array[]    $log
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wpav-card">
	<p><?php esc_html_e( 'Every change made through this plugin — scans, repairs, quarantines, restores, cleanup and hardening actions — with who did it and from where.', 'wpav' ); ?></p>
	<?php if ( ! $log ) : ?>
		<p><em><?php esc_html_e( 'No activity yet.', 'wpav' ); ?></em></p>
	<?php else : ?>
		<table class="widefat striped">
			<thead><tr><th><?php esc_html_e( 'When', 'wpav' ); ?></th><th><?php esc_html_e( 'User', 'wpav' ); ?></th><th><?php esc_html_e( 'IP', 'wpav' ); ?></th><th><?php esc_html_e( 'Action', 'wpav' ); ?></th><th><?php esc_html_e( 'Target', 'wpav' ); ?></th><th><?php esc_html_e( 'Details', 'wpav' ); ?></th></tr></thead>
			<tbody>
			<?php foreach ( $log as $entry ) : ?>
				<tr>
					<td><?php echo esc_html( $this->date( $entry['time'] ) ); ?></td>
					<td><?php echo esc_html( $entry['user'] ); ?></td>
					<td><?php echo esc_html( $entry['ip'] ); ?></td>
					<td><strong><?php echo esc_html( $entry['action'] ); ?></strong></td>
					<td><?php echo '' !== $entry['target'] ? '<code>' . esc_html( $entry['target'] ) . '</code>' : '—'; ?></td>
					<td><?php echo esc_html( $entry['detail'] ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>
</div>
