<?php
/**
 * Scan screen.
 *
 * @package WPAV
 * @var WPAV_Admin $this
 * @var array|null $results
 * @var array      $history
 * @var bool       $running
 */

defined( 'ABSPATH' ) || exit;

$wpav_next = WPAV_Cron::next_run();
?>
<?php if ( $running ) : ?>
	<div class="notice notice-info inline"><p><?php esc_html_e( 'A scan is already running (possibly a scheduled scan). Starting a new scan will replace it.', 'wpav' ); ?></p></div>
<?php endif; ?>

<div class="wpav-card">
	<h2><?php esc_html_e( 'Malware scan', 'wpav' ); ?></h2>
	<p><?php esc_html_e( 'Checks every PHP, JavaScript, HTML, .htaccess and .user.ini file, plus the database. WordPress core and WordPress.org plugins are compared byte-for-byte with the official files for the exact installed version; everything else (custom themes, custom plugins, uploads) is checked against malware signatures and compared with the previous scan to detect changes.', 'wpav' ); ?></p>
	<p>
		<button type="button" class="button button-primary button-hero" id="wpav-scan-start"><?php esc_html_e( 'Start Scan', 'wpav' ); ?></button>
	</p>
	<div id="wpav-progress" class="wpav-progress" hidden>
		<div class="wpav-bar"><div class="wpav-bar-fill"></div></div>
		<p class="wpav-progress-msg"></p>
	</div>
</div>

<?php if ( $results ) : ?>
	<?php $s = $results['stats']; ?>
	<div class="wpav-card">
		<h2>
			<?php
			/* translators: 1: date/time, 2: origin */
			printf( esc_html__( 'Last scan: %1$s (%2$s)', 'wpav' ), esc_html( $this->date( $results['finished'] ) ), esc_html( $this->origin_label( $results['origin'] ?? 'manual' ) ) );
			?>
		</h2>
		<div class="wpav-stats">
			<?php
			$this->stat( $s['scanned'], __( 'Files scanned', 'wpav' ) );
			$this->stat( $s['verified'], __( 'Verified clean vs. official', 'wpav' ), 'is-ok' );
			$this->stat( $s['findings'], __( 'Active issues', 'wpav' ), $s['findings'] ? 'is-bad' : 'is-ok' );
			$this->stat( $s['by_severity']['critical'], __( 'Critical', 'wpav' ), $s['by_severity']['critical'] ? 'is-bad' : '' );
			$this->stat( $s['by_severity']['high'], __( 'High', 'wpav' ), $s['by_severity']['high'] ? 'is-warn' : '' );
			$this->stat( $s['repairable'], __( 'Auto-repairable', 'wpav' ) );
			$this->stat( $s['quarantinable'], __( 'Can be quarantined', 'wpav' ) );
			?>
		</div>
		<p>
			<a class="button button-primary" href="<?php echo esc_url( WPAV_Util::page_url( 'wpav-report' ) ); ?>"><?php esc_html_e( 'View Report', 'wpav' ); ?></a>
			<a class="button" href="<?php echo esc_url( WPAV_Util::page_url( 'wpav-repair' ) ); ?>"><?php esc_html_e( 'Repair & Quarantine', 'wpav' ); ?></a>
		</p>
	</div>
<?php endif; ?>

<?php if ( $history ) : ?>
	<div class="wpav-card">
		<h2><?php esc_html_e( 'Scan history', 'wpav' ); ?></h2>
		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Finished', 'wpav' ); ?></th>
					<th><?php esc_html_e( 'Type', 'wpav' ); ?></th>
					<th><?php esc_html_e( 'Duration', 'wpav' ); ?></th>
					<th><?php esc_html_e( 'Files', 'wpav' ); ?></th>
					<th><?php esc_html_e( 'Issues', 'wpav' ); ?></th>
					<th><?php esc_html_e( 'New', 'wpav' ); ?></th>
					<th><?php esc_html_e( 'Critical / High', 'wpav' ); ?></th>
					<th><?php esc_html_e( 'File changes (new / modified / deleted)', 'wpav' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( array_slice( $history, 0, 10 ) as $h ) : ?>
				<tr>
					<td><?php echo esc_html( $this->date( $h['finished'] ) ); ?></td>
					<td><?php echo esc_html( $this->origin_label( $h['origin'] ) ); ?></td>
					<td><?php echo esc_html( human_time_diff( 0, max( 1, $h['duration'] ) ) ); ?></td>
					<td><?php echo esc_html( number_format_i18n( $h['scanned'] ) ); ?></td>
					<td><?php echo esc_html( $h['findings'] ); ?></td>
					<td><?php echo esc_html( $h['new'] ); ?></td>
					<td><?php echo esc_html( $h['by_severity']['critical'] . ' / ' . $h['by_severity']['high'] ); ?></td>
					<td><?php echo $h['changes'] ? esc_html( $h['changes']['new'] . ' / ' . $h['changes']['modified'] . ' / ' . $h['changes']['deleted'] ) : '—'; ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
<?php endif; ?>

<div class="wpav-card">
	<h2><?php esc_html_e( 'Environment', 'wpav' ); ?></h2>
	<table class="widefat striped wpav-env">
		<tbody>
			<tr><th><?php esc_html_e( 'WordPress version', 'wpav' ); ?></th><td><?php echo esc_html( get_bloginfo( 'version' ) ); ?></td></tr>
			<?php if ( $results ) : ?>
				<tr><th><?php esc_html_e( 'Core checksums', 'wpav' ); ?></th><td><?php echo 'verified' === $results['core_status'] ? esc_html__( 'Available from WordPress.org', 'wpav' ) : '<strong>' . esc_html__( 'Unavailable (core files were only signature-scanned)', 'wpav' ) . '</strong>'; ?></td></tr>
			<?php endif; ?>
			<tr>
				<th><?php esc_html_e( 'Scheduled scans', 'wpav' ); ?></th>
				<td>
					<?php
					if ( $wpav_next ) {
						/* translators: %s: date/time */
						printf( esc_html__( 'Next run: %s', 'wpav' ), esc_html( $this->date( $wpav_next ) ) );
					} else {
						esc_html_e( 'Off', 'wpav' );
					}
					?>
					— <a href="<?php echo esc_url( WPAV_Util::page_url( 'wpav-settings' ) ); ?>"><?php esc_html_e( 'Settings', 'wpav' ); ?></a>
				</td>
			</tr>
			<tr><th><?php esc_html_e( 'File repairs', 'wpav' ); ?></th><td><?php echo WPAV_Repair::can_modify() ? esc_html__( 'Allowed', 'wpav' ) : '<strong>' . esc_html__( 'Disabled by DISALLOW_FILE_MODS (report only)', 'wpav' ) . '</strong>'; ?></td></tr>
			<tr><th><?php esc_html_e( 'Zip extension (package fallback)', 'wpav' ); ?></th><td><?php echo class_exists( 'ZipArchive' ) ? esc_html__( 'Available', 'wpav' ) : esc_html__( 'Missing (repairs use WordPress.org SVN only)', 'wpav' ); ?></td></tr>
			<tr><th><?php esc_html_e( 'WP-CLI', 'wpav' ); ?></th><td><code>wp antivirus scan</code> · <code>wp antivirus report</code> · <code>wp antivirus repair --all</code> · <code>wp antivirus quarantine --all</code></td></tr>
		</tbody>
	</table>
</div>
