<?php
/**
 * Backups screen.
 *
 * @package WPAV
 * @var WPAV_Admin $this
 * @var array[]    $backups
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wpav-card">
	<p><?php esc_html_e( 'A copy of every file is saved here before it is repaired, quarantined or restored. Backups are stored in a protected folder inside uploads and are never executable.', 'wpav' ); ?></p>
	<?php if ( ! $backups ) : ?>
		<p><em><?php esc_html_e( 'No backups yet.', 'wpav' ); ?></em></p>
	<?php else : ?>
		<table class="widefat striped">
			<thead><tr><th><?php esc_html_e( 'Date', 'wpav' ); ?></th><th><?php esc_html_e( 'File', 'wpav' ); ?></th><th><?php esc_html_e( 'Reason', 'wpav' ); ?></th><th><?php esc_html_e( 'Size', 'wpav' ); ?></th><th><?php esc_html_e( 'Actions', 'wpav' ); ?></th></tr></thead>
			<tbody>
			<?php foreach ( $backups as $b ) : ?>
				<tr>
					<td><?php echo esc_html( $this->date( $b['time'] ) ); ?></td>
					<td><code><?php echo esc_html( $b['rel'] ); ?></code></td>
					<td><?php echo esc_html( $b['reason'] ); ?></td>
					<td><?php echo esc_html( size_format( $b['size'] ) ); ?></td>
					<td>
						<button type="button" class="button wpav-action" data-action="wpav_restore" data-id="<?php echo esc_attr( $b['id'] ); ?>" data-confirm="<?php esc_attr_e( 'Restore this backup to its original location? If a file exists there it is backed up first.', 'wpav' ); ?>" <?php disabled( ! WPAV_Repair::can_modify() ); ?>><?php esc_html_e( 'Restore', 'wpav' ); ?></button>
						<button type="button" class="button-link-delete wpav-action" data-action="wpav_delete_backup" data-id="<?php echo esc_attr( $b['id'] ); ?>" data-confirm="<?php esc_attr_e( 'Delete this backup permanently?', 'wpav' ); ?>"><?php esc_html_e( 'Delete', 'wpav' ); ?></button>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>
</div>
