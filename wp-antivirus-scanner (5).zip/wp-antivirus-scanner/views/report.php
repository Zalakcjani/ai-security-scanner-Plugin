<?php
/**
 * Report screen.
 *
 * @package WPAV
 * @var WPAV_Admin $this
 * @var array|null $results
 * @var bool       $show_new
 */

defined( 'ABSPATH' ) || exit;

if ( ! $results ) {
	$this->no_results();
	return;
}

$findings = $results['findings'];
$stats    = $results['stats'];
$changes  = isset( $results['changes'] ) ? $results['changes'] : null;
?>
<div class="wpav-card">
	<div class="wpav-report-head">
		<p class="wpav-summary">
			<?php
			printf(
				/* translators: 1: active issues, 2: scanned files, 3: date */
				esc_html__( '%1$s active issue(s) — %2$s files scanned — %3$s.', 'wpav' ),
				'<strong>' . esc_html( number_format_i18n( $stats['findings'] ) ) . '</strong>',
				esc_html( number_format_i18n( $stats['scanned'] ) ),
				esc_html( $this->date( $results['finished'] ) )
			);
			if ( $stats['ignored'] || $stats['resolved'] ) {
				echo ' ';
				/* translators: 1: ignored, 2: resolved */
				printf( esc_html__( '(%1$d marked safe, %2$d resolved)', 'wpav' ), (int) $stats['ignored'], (int) $stats['resolved'] );
			}
			?>
		</p>
		<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpav_export' ), 'wpav_export' ) ); ?>">
			<span class="dashicons dashicons-download"></span> <?php esc_html_e( 'Export CSV', 'wpav' ); ?>
		</a>
	</div>

	<?php if ( $changes ) : ?>
		<details class="wpav-details">
			<summary>
				<?php
				/* translators: 1: new, 2: modified, 3: deleted */
				printf( esc_html__( 'File changes since the previous scan: %1$d new, %2$d modified, %3$d deleted', 'wpav' ), (int) $changes['new'], (int) $changes['modified'], (int) $changes['deleted'] );
				?>
			</summary>
			<p class="description"><?php esc_html_e( 'Files verified against official WordPress.org checksums are excluded. Changes after updating a custom plugin or theme are expected; unexpected changes deserve a look.', 'wpav' ); ?></p>
			<div class="wpav-changes">
				<?php
				$wpav_change_labels = array(
					'new'      => __( 'New', 'wpav' ),
					'modified' => __( 'Modified', 'wpav' ),
					'deleted'  => __( 'Deleted', 'wpav' ),
				);
				foreach ( $wpav_change_labels as $wpav_type => $wpav_label ) :
					if ( empty( $changes['lists'][ $wpav_type ] ) ) {
						continue;
					}
					?>
					<div>
						<h4><?php echo esc_html( $wpav_label ); ?> (<?php echo (int) $changes[ $wpav_type ]; ?>)</h4>
						<ul>
							<?php foreach ( $changes['lists'][ $wpav_type ] as $wpav_path ) : ?>
								<li><code><?php echo esc_html( $wpav_path ); ?></code></li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endforeach; ?>
			</div>
		</details>
	<?php elseif ( 1 === count( WPAV_History::all() ) ) : ?>
		<p class="description"><?php esc_html_e( 'This was the first scan; file change detection starts with the next one.', 'wpav' ); ?></p>
	<?php endif; ?>

	<details class="wpav-details">
		<summary><?php esc_html_e( 'Plugin & theme verification status', 'wpav' ); ?></summary>
		<table class="widefat striped">
			<thead><tr><th><?php esc_html_e( 'Plugin / theme', 'wpav' ); ?></th><th><?php esc_html_e( 'Version', 'wpav' ); ?></th><th><?php esc_html_e( 'Status', 'wpav' ); ?></th></tr></thead>
			<tbody>
			<?php
			$wpav_components = array();
			foreach ( $results['plugins'] as $plugin ) {
				$wpav_components[] = array_merge( $plugin, array( 'kind' => __( 'Plugin', 'wpav' ) ) );
			}
			foreach ( isset( $results['themes'] ) ? $results['themes'] : array() as $theme ) {
				$wpav_components[] = array_merge( $theme, array( 'kind' => __( 'Theme', 'wpav' ) ) );
			}
			foreach ( $wpav_components as $plugin ) :
				?>
				<tr>
					<td><span class="wpav-meta"><?php echo esc_html( $plugin['kind'] ); ?>:</span> <?php echo esc_html( $plugin['name'] ); ?></td>
					<td><?php echo esc_html( $plugin['version'] ); ?></td>
					<td>
						<?php
						if ( 'wporg' === $plugin['source'] && empty( $plugin['diverged'] ) ) {
							echo '<span class="wpav-pill is-ok">' . esc_html__( 'Verified against WordPress.org — repairable', 'wpav' ) . '</span>';
						} elseif ( 'wporg' === $plugin['source'] ) {
							echo '<span class="wpav-pill">' . esc_html__( 'Heavily modified — report only', 'wpav' ) . '</span>';
						} elseif ( 'unverified' === $plugin['source'] ) {
							echo '<span class="wpav-pill is-warn">' . esc_html__( 'Could not verify', 'wpav' ) . '</span> ' . esc_html( $plugin['note'] );
						} else {
							echo '<span class="wpav-pill">' . esc_html__( 'Custom — report only', 'wpav' ) . '</span> ' . esc_html( $plugin['note'] );
						}
						?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</details>
</div>

<?php if ( ! $findings ) : ?>
	<div class="wpav-card wpav-clean"><p><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'No malware or modified files were found.', 'wpav' ); ?></p></div>
	<?php
	return;
endif;
?>

<div class="wpav-filters">
	<label><?php esc_html_e( 'Minimum severity', 'wpav' ); ?>
		<select id="wpav-filter-severity">
			<option value="1"><?php esc_html_e( 'All', 'wpav' ); ?></option>
			<option value="2"><?php esc_html_e( 'Medium+', 'wpav' ); ?></option>
			<option value="3"><?php esc_html_e( 'High+', 'wpav' ); ?></option>
			<option value="4"><?php esc_html_e( 'Critical', 'wpav' ); ?></option>
		</select>
	</label>
	<label><?php esc_html_e( 'Location', 'wpav' ); ?>
		<select id="wpav-filter-type">
			<option value=""><?php esc_html_e( 'All', 'wpav' ); ?></option>
			<option value="core"><?php esc_html_e( 'WordPress core', 'wpav' ); ?></option>
			<option value="plugin"><?php esc_html_e( 'Plugins', 'wpav' ); ?></option>
			<option value="theme"><?php esc_html_e( 'Themes', 'wpav' ); ?></option>
			<option value="mu-plugin"><?php esc_html_e( 'Must-use plugins', 'wpav' ); ?></option>
			<option value="upload"><?php esc_html_e( 'Uploads', 'wpav' ); ?></option>
			<option value="database"><?php esc_html_e( 'Database', 'wpav' ); ?></option>
			<option value="vulnerability"><?php esc_html_e( 'Known vulnerabilities', 'wpav' ); ?></option>
			<option value="other"><?php esc_html_e( 'Other', 'wpav' ); ?></option>
		</select>
	</label>
	<input type="search" id="wpav-filter-text" placeholder="<?php esc_attr_e( 'Filter by path…', 'wpav' ); ?>">
	<label><input type="checkbox" id="wpav-filter-inactive"> <?php esc_html_e( 'Show marked-safe & resolved', 'wpav' ); ?></label>
</div>

<?php foreach ( $findings as $f ) : ?>
	<?php
	$wpav_state = 'open' !== $f['status'] ? 'resolved' : ( $f['ignored'] ? 'ignored' : 'active' );
	$wpav_edit  = 'database' === $f['type'] ? WPAV_DB_Scanner::edit_url( $f ) : '';
	?>
	<div class="wpav-finding is-<?php echo esc_attr( $wpav_state ); ?>" id="f-<?php echo esc_attr( $f['id'] ); ?>"
		data-severity="<?php echo esc_attr( WPAV_Util::severity_rank( $f['severity'] ) ); ?>"
		data-type="<?php echo esc_attr( $f['type'] ); ?>"
		data-state="<?php echo esc_attr( $wpav_state ); ?>"
		data-text="<?php echo esc_attr( strtolower( $f['rel'] . ' ' . $f['component'] ) ); ?>"
		<?php echo 'active' === $wpav_state ? '' : 'hidden'; ?>>
		<div class="wpav-finding-head">
			<?php echo $this->severity_badge( $f['severity'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<code class="wpav-path"><?php echo esc_html( $f['rel'] ); ?></code>
			<span class="wpav-meta"><?php echo esc_html( trim( $f['component'] . ' ' . $f['version'] ) . ' · ' . WPAV_Util::source_label( $f ) ); ?></span>
			<?php if ( $show_new && $f['is_new'] && 'active' === $wpav_state ) : ?>
				<span class="wpav-pill is-new"><?php esc_html_e( 'New', 'wpav' ); ?></span>
			<?php endif; ?>
			<?php if ( 'repaired' === $f['status'] ) : ?>
				<span class="wpav-pill is-ok"><?php esc_html_e( 'Repaired', 'wpav' ); ?></span>
			<?php elseif ( 'quarantined' === $f['status'] ) : ?>
				<span class="wpav-pill is-ok"><?php esc_html_e( 'Quarantined', 'wpav' ); ?></span>
			<?php elseif ( $f['ignored'] ) : ?>
				<span class="wpav-pill"><?php esc_html_e( 'Marked safe', 'wpav' ); ?></span>
			<?php elseif ( $f['repairable'] ) : ?>
				<span class="wpav-pill is-repair"><?php esc_html_e( 'Repairable', 'wpav' ); ?></span>
			<?php elseif ( WPAV_Util::can_quarantine( $f ) ) : ?>
				<span class="wpav-pill is-warn"><?php esc_html_e( 'Can be quarantined', 'wpav' ); ?></span>
			<?php else : ?>
				<span class="wpav-pill"><?php esc_html_e( 'Report only', 'wpav' ); ?></span>
			<?php endif; ?>
		</div>
		<table class="widefat wpav-issues">
			<thead><tr><th class="col-line"><?php esc_html_e( 'Line', 'wpav' ); ?></th><th class="col-rule"><?php esc_html_e( 'Detection', 'wpav' ); ?></th><th><?php esc_html_e( 'Suspicious code', 'wpav' ); ?></th></tr></thead>
			<tbody>
			<?php foreach ( $f['issues'] as $issue ) : ?>
				<tr>
					<td class="col-line"><?php echo $issue['line'] ? esc_html( $issue['line'] ) : '—'; ?></td>
					<td class="col-rule">
						<?php echo $this->severity_badge( $issue['severity'] ) . ' ' . esc_html( $issue['title'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php if ( ! empty( $issue['link'] ) ) : ?>
							<a href="<?php echo esc_url( $issue['link'] ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Details', 'wpav' ); ?></a>
						<?php endif; ?>
					</td>
					<td>
						<?php if ( '' !== $issue['code'] ) : ?>
							<code class="wpav-code"><?php echo esc_html( $issue['code'] ); ?></code>
						<?php elseif ( 'vulnerability' === $issue['kind'] ) : ?>
							<em><?php esc_html_e( 'Installed version is affected', 'wpav' ); ?></em>
						<?php elseif ( 'modified' === $issue['kind'] ) : ?>
							<em><?php esc_html_e( 'Use “View changes” to see exactly which lines differ from the official file.', 'wpav' ); ?></em>
						<?php else : ?>
							<em><?php esc_html_e( 'Whole file', 'wpav' ); ?></em>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>

		<?php if ( 'active' === $wpav_state && ! $f['repairable'] ) : ?>
			<p class="wpav-note"><?php echo esc_html( WPAV_Util::manual_reason( $f ) ); ?></p>
		<?php endif; ?>

		<div class="wpav-actions">
			<?php if ( 'open' === $f['status'] ) : ?>
				<?php if ( ! empty( $f['expected'] ) ) : ?>
					<button type="button" class="button wpav-diff-btn" data-id="<?php echo esc_attr( $f['id'] ); ?>"><?php esc_html_e( 'View changes vs. official file', 'wpav' ); ?></button>
				<?php endif; ?>
				<?php if ( ! $f['ignored'] && $f['repairable'] ) : ?>
					<button type="button" class="button button-primary wpav-action" data-action="wpav_repair" data-id="<?php echo esc_attr( $f['id'] ); ?>" data-confirm="<?php esc_attr_e( 'Back up this file and replace it with the official original?', 'wpav' ); ?>" <?php disabled( ! WPAV_Repair::can_modify() ); ?>><?php esc_html_e( 'Backup & Repair', 'wpav' ); ?></button>
				<?php endif; ?>
				<?php if ( ! $f['ignored'] && WPAV_Util::can_quarantine( $f ) ) : ?>
					<button type="button" class="button wpav-action wpav-danger" data-action="wpav_quarantine" data-id="<?php echo esc_attr( $f['id'] ); ?>" data-confirm="<?php esc_attr_e( 'Move this file to quarantine? It is removed from the site and can be restored from Backups.', 'wpav' ); ?>" <?php disabled( ! WPAV_Repair::can_modify() ); ?>><?php esc_html_e( 'Quarantine', 'wpav' ); ?></button>
				<?php endif; ?>
				<?php if ( $wpav_edit ) : ?>
					<a class="button" href="<?php echo esc_url( $wpav_edit ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Open to clean', 'wpav' ); ?></a>
				<?php endif; ?>
				<?php if ( 'vulnerability' === $f['type'] ) : ?>
					<a class="button button-primary" href="<?php echo esc_url( is_multisite() ? network_admin_url( 'update-core.php' ) : admin_url( 'update-core.php' ) ); ?>"><?php esc_html_e( 'Go to Updates', 'wpav' ); ?></a>
				<?php endif; ?>
				<?php if ( $f['ignored'] ) : ?>
					<button type="button" class="button-link wpav-action" data-action="wpav_unignore" data-id="<?php echo esc_attr( $f['id'] ); ?>"><?php esc_html_e( 'Stop ignoring', 'wpav' ); ?></button>
				<?php else : ?>
					<button type="button" class="button-link wpav-action" data-action="wpav_ignore" data-id="<?php echo esc_attr( $f['id'] ); ?>" data-confirm="<?php esc_attr_e( 'Mark this item as safe? It will be hidden until its content changes.', 'wpav' ); ?>"><?php esc_html_e( 'Mark as safe', 'wpav' ); ?></button>
				<?php endif; ?>
			<?php endif; ?>
		</div>
		<?php if ( ! empty( $f['expected'] ) ) : ?>
			<div class="wpav-diff-panel" id="wpav-diff-<?php echo esc_attr( $f['id'] ); ?>" hidden></div>
		<?php endif; ?>
	</div>
<?php endforeach; ?>
