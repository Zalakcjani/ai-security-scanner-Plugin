<?php
/**
 * Hardening screen.
 *
 * @package WPAV
 * @var WPAV_Admin $this
 * @var array[]    $checks
 */

defined( 'ABSPATH' ) || exit;

$wpav_counts = array_count_values( wp_list_pluck( $checks, 'status' ) );
$wpav_score  = (int) round( 100 * ( isset( $wpav_counts['ok'] ) ? $wpav_counts['ok'] : 0 ) / max( 1, count( $checks ) ) );
$wpav_icons  = array(
	'ok'   => 'dashicons-yes-alt',
	'warn' => 'dashicons-warning',
	'bad'  => 'dashicons-dismiss',
);
?>
<div class="wpav-card">
	<div class="wpav-score-row">
		<div class="wpav-score <?php echo $wpav_score >= 80 ? 'is-ok' : ( $wpav_score >= 50 ? 'is-warn' : 'is-bad' ); ?>">
			<span class="wpav-score-value"><?php echo (int) $wpav_score; ?>%</span>
			<span class="wpav-stat-label"><?php esc_html_e( 'Hardening score', 'wpav' ); ?></span>
		</div>
		<p><?php esc_html_e( 'Malware removal only helps if the way in is closed. These checks cover the most common entry points. Protections marked with a button can be switched on here; the rest need a change on your server or in wp-config.php.', 'wpav' ); ?></p>
	</div>
</div>

<div class="wpav-card">
	<table class="widefat striped wpav-hardening">
		<tbody>
		<?php foreach ( $checks as $check ) : ?>
			<tr class="is-<?php echo esc_attr( $check['status'] ); ?>">
				<td class="col-icon"><span class="dashicons <?php echo esc_attr( $wpav_icons[ $check['status'] ] ); ?>"></span></td>
				<td>
					<strong><?php echo esc_html( $check['title'] ); ?></strong>
					<p class="description"><?php echo esc_html( $check['detail'] ); ?></p>
				</td>
				<td class="col-action">
					<?php if ( $check['fix'] ) : ?>
						<?php $wpav_on = WPAV_Hardening::is_enabled( $check['fix'] ); ?>
						<button type="button" class="button <?php echo $wpav_on ? '' : 'button-primary'; ?> wpav-harden" data-key="<?php echo esc_attr( $check['fix'] ); ?>" data-enable="<?php echo $wpav_on ? '0' : '1'; ?>">
							<?php echo $wpav_on ? esc_html__( 'Turn off', 'wpav' ) : esc_html__( 'Fix it', 'wpav' ); ?>
						</button>
					<?php elseif ( 'plugin-updates' === $check['id'] || 'core-updates' === $check['id'] || 'theme-updates' === $check['id'] ) : ?>
						<?php if ( 'ok' !== $check['status'] ) : ?>
							<a class="button" href="<?php echo esc_url( is_multisite() ? network_admin_url( 'update-core.php' ) : admin_url( 'update-core.php' ) ); ?>"><?php esc_html_e( 'Update', 'wpav' ); ?></a>
						<?php endif; ?>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
