<?php
/**
 * Settings screen.
 *
 * @package WPAV
 * @var WPAV_Admin $this
 * @var array      $settings
 */

defined( 'ABSPATH' ) || exit;

$wpav_next = WPAV_Cron::next_run();
?>
<?php if ( isset( $_GET['updated'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
	<div class="notice notice-success is-dismissible inline"><p><?php esc_html_e( 'Settings saved.', 'wpav' ); ?></p></div>
<?php endif; ?>

<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wpav-card">
	<input type="hidden" name="action" value="wpav_save_settings">
	<?php wp_nonce_field( 'wpav_settings' ); ?>

	<h2><?php esc_html_e( 'Scheduled scans & alerts', 'wpav' ); ?></h2>
	<table class="form-table" role="presentation">
		<tr>
			<th scope="row"><label for="wpav-schedule"><?php esc_html_e( 'Automatic scan', 'wpav' ); ?></label></th>
			<td>
				<select id="wpav-schedule" name="wpav[schedule]">
					<option value="off" <?php selected( $settings['schedule'], 'off' ); ?>><?php esc_html_e( 'Off', 'wpav' ); ?></option>
					<option value="daily" <?php selected( $settings['schedule'], 'daily' ); ?>><?php esc_html_e( 'Daily', 'wpav' ); ?></option>
					<option value="weekly" <?php selected( $settings['schedule'], 'weekly' ); ?>><?php esc_html_e( 'Weekly', 'wpav' ); ?></option>
				</select>
				<?php if ( $wpav_next ) : ?>
					<p class="description">
						<?php
						/* translators: %s: date/time */
						printf( esc_html__( 'Next scheduled scan: %s', 'wpav' ), esc_html( $this->date( $wpav_next ) ) );
						?>
					</p>
				<?php endif; ?>
				<p class="description"><?php esc_html_e( 'Runs in the background via WP-Cron. On low-traffic sites, configure a real server cron that calls wp-cron.php (or use `wp antivirus scan`).', 'wpav' ); ?></p>
			</td>
		</tr>
		<tr>
			<th scope="row"><label for="wpav-email"><?php esc_html_e( 'Alert email', 'wpav' ); ?></label></th>
			<td><input type="email" class="regular-text" id="wpav-email" name="wpav[email]" value="<?php echo esc_attr( $settings['email'] ); ?>"></td>
		</tr>
		<tr>
			<th scope="row"><?php esc_html_e( 'Send email', 'wpav' ); ?></th>
			<td>
				<fieldset>
					<label><input type="radio" name="wpav[email_mode]" value="new" <?php checked( $settings['email_mode'], 'new' ); ?>> <?php esc_html_e( 'Only when new issues are found (recommended)', 'wpav' ); ?></label><br>
					<label><input type="radio" name="wpav[email_mode]" value="always" <?php checked( $settings['email_mode'], 'always' ); ?>> <?php esc_html_e( 'After every scheduled scan', 'wpav' ); ?></label><br>
					<label><input type="radio" name="wpav[email_mode]" value="never" <?php checked( $settings['email_mode'], 'never' ); ?>> <?php esc_html_e( 'Never', 'wpav' ); ?></label>
				</fieldset>
			</td>
		</tr>
	</table>

	<h2><?php esc_html_e( 'Scan options', 'wpav' ); ?></h2>
	<table class="form-table" role="presentation">
		<tr>
			<th scope="row"><?php esc_html_e( 'Database', 'wpav' ); ?></th>
			<td><label><input type="checkbox" name="wpav[scan_database]" value="1" <?php checked( $settings['scan_database'] ); ?>> <?php esc_html_e( 'Scan posts, post meta, comments, options, scheduled tasks and administrator accounts (all sites on multisite)', 'wpav' ); ?></label></td>
		</tr>
		<tr>
			<th scope="row"><?php esc_html_e( 'Known vulnerabilities', 'wpav' ); ?></th>
			<td>
				<label><input type="checkbox" name="wpav[check_vulns]" value="1" <?php checked( $settings['check_vulns'] ); ?>> <?php esc_html_e( 'Check installed WordPress, plugin and theme versions against the WPVulnerability.net database', 'wpav' ); ?></label>
				<p class="description"><?php esc_html_e( 'Sends only component slugs and the WordPress version to wpvulnerability.net (results are cached for 12 hours).', 'wpav' ); ?></p>
			</td>
		</tr>
		<tr>
			<th scope="row"><?php esc_html_e( 'Uploaded media', 'wpav' ); ?></th>
			<td>
				<label><input type="checkbox" name="wpav[scan_images]" value="1" <?php checked( $settings['scan_images'] ); ?>> <?php esc_html_e( 'Check images in uploads for hidden PHP and SVG files for scripts', 'wpav' ); ?></label>
				<p class="description"><?php esc_html_e( 'Only the first and last 32 KB of each image are read, so large media libraries stay fast.', 'wpav' ); ?></p>
			</td>
		</tr>
		<tr>
			<th scope="row"><label for="wpav-max-size"><?php esc_html_e( 'Max file size for signature scan', 'wpav' ); ?></label></th>
			<td><input type="number" min="1" max="64" id="wpav-max-size" name="wpav[max_file_mb]" value="<?php echo esc_attr( $settings['max_file_mb'] ); ?>" class="small-text"> MB
				<p class="description"><?php esc_html_e( 'Larger files are still checksum-verified but not pattern-scanned.', 'wpav' ); ?></p></td>
		</tr>
		<tr>
			<th scope="row"><label for="wpav-exclusions"><?php esc_html_e( 'Exclude paths', 'wpav' ); ?></label></th>
			<td>
				<textarea id="wpav-exclusions" name="wpav[exclusions]" rows="6" class="large-text code" placeholder="wp-content/cache/&#10;wp-content/uploads/backups/*&#10;*.min.js"><?php echo esc_textarea( $settings['exclusions'] ); ?></textarea>
				<p class="description"><?php esc_html_e( 'One per line, relative to the WordPress folder. Plain paths match as a prefix; use * and ? for wildcards. Exclude only locations you trust — attackers like to hide in cache folders.', 'wpav' ); ?></p>
			</td>
		</tr>
	</table>

	<?php submit_button(); ?>
</form>
