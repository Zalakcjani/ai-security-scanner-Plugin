<?php
/**
 * Uninstall handler. Only runs when the plugin is deleted from the Plugins
 * screen (not on deactivation). Removes plugin database tables and options.
 *
 * The one exception to "never touches files outside the plugin's own data":
 * if File Lock Protection was left enabled, baseline files were chmod'd
 * read-only, and that permission would otherwise survive deletion of the
 * plugin that applied it. We restore normal permissions first so a site is
 * never left stuck read-only just because this plugin was removed.
 *
 * @package AI_Security_Scanner
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

require_once __DIR__ . '/includes/class-database.php';
require_once __DIR__ . '/includes/class-settings.php';
require_once __DIR__ . '/includes/class-file-scanner.php';
require_once __DIR__ . '/includes/class-baseline.php';
require_once __DIR__ . '/includes/class-integrity-lock.php';

if ( AISS_Integrity_Lock::is_enabled() ) {
	AISS_Integrity_Lock::disable();
}
wp_clear_scheduled_hook( AISS_Integrity_Lock::CRON_HOOK );

AISS_Database::drop_tables();

delete_option( 'aiss_settings' );
delete_option( 'aiss_db_version' );
delete_option( 'aiss_watchdog_cursor' );
delete_option( 'aiss_watchdog_last_run' );

global $wpdb;
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_aiss\_%' OR option_name LIKE '\_transient\_timeout\_aiss\_%'" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery
