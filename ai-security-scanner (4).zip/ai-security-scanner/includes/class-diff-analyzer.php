<?php
/**
 * Simple line-based diff (longest common subsequence) for visualising
 * baseline-vs-current file comparisons in the admin UI.
 *
 * @package AI_Security_Scanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AISS_Diff_Analyzer {

	const MAX_LINES = 4000;

	/**
	 * Build an ordered list of diff operations between two texts.
	 *
	 * @return array List of array( 'type' => 'equal'|'add'|'remove', 'old_line' => int|null, 'new_line' => int|null, 'text' => string ).
	 */
	public static function diff( $old_text, $new_text ) {
		$old_lines = explode( "\n", (string) $old_text );
		$new_lines = explode( "\n", (string) $new_text );

		if ( count( $old_lines ) > self::MAX_LINES || count( $new_lines ) > self::MAX_LINES ) {
			return array(
				array(
					'type' => 'truncated',
					'text' => sprintf(
						/* translators: %d: maximum line count */
						__( 'File is too large to display an inline comparison (limit: %d lines). Please compare manually.', 'ai-security-scanner' ),
						self::MAX_LINES
					),
				),
			);
		}

		$m = count( $old_lines );
		$n = count( $new_lines );

		// Build LCS length table.
		$lcs = array_fill( 0, $m + 1, array_fill( 0, $n + 1, 0 ) );

		for ( $i = $m - 1; $i >= 0; $i-- ) {
			for ( $j = $n - 1; $j >= 0; $j-- ) {
				if ( $old_lines[ $i ] === $new_lines[ $j ] ) {
					$lcs[ $i ][ $j ] = $lcs[ $i + 1 ][ $j + 1 ] + 1;
				} else {
					$lcs[ $i ][ $j ] = max( $lcs[ $i + 1 ][ $j ], $lcs[ $i ][ $j + 1 ] );
				}
			}
		}

		$ops = array();
		$i   = 0;
		$j   = 0;

		while ( $i < $m && $j < $n ) {
			if ( $old_lines[ $i ] === $new_lines[ $j ] ) {
				$ops[] = array(
					'type'     => 'equal',
					'old_line' => $i + 1,
					'new_line' => $j + 1,
					'text'     => $old_lines[ $i ],
				);
				$i++;
				$j++;
			} elseif ( $lcs[ $i + 1 ][ $j ] >= $lcs[ $i ][ $j + 1 ] ) {
				$ops[] = array(
					'type'     => 'remove',
					'old_line' => $i + 1,
					'new_line' => null,
					'text'     => $old_lines[ $i ],
				);
				$i++;
			} else {
				$ops[] = array(
					'type'     => 'add',
					'old_line' => null,
					'new_line' => $j + 1,
					'text'     => $new_lines[ $j ],
				);
				$j++;
			}
		}

		while ( $i < $m ) {
			$ops[] = array(
				'type'     => 'remove',
				'old_line' => $i + 1,
				'new_line' => null,
				'text'     => $old_lines[ $i ],
			);
			$i++;
		}

		while ( $j < $n ) {
			$ops[] = array(
				'type'     => 'add',
				'old_line' => null,
				'new_line' => $j + 1,
				'text'     => $new_lines[ $j ],
			);
			$j++;
		}

		return self::collapse_context( $ops );
	}

	/**
	 * Collapse long unchanged runs to a handful of context lines around each
	 * change, keeping large-file diffs readable.
	 */
	private static function collapse_context( array $ops, $context = 3 ) {
		$total = count( $ops );
		$keep  = array_fill( 0, $total, false );

		foreach ( $ops as $idx => $op ) {
			if ( 'equal' !== $op['type'] ) {
				for ( $k = max( 0, $idx - $context ); $k <= min( $total - 1, $idx + $context ); $k++ ) {
					$keep[ $k ] = true;
				}
			}
		}

		$result = array();
		$idx    = 0;
		while ( $idx < $total ) {
			if ( ! $keep[ $idx ] ) {
				$start = $idx;
				while ( $idx < $total && ! $keep[ $idx ] ) {
					$idx++;
				}
				$result[] = array(
					'type' => 'skip',
					'text' => sprintf(
						/* translators: %d: number of unchanged lines skipped */
						__( '%d unchanged lines hidden', 'ai-security-scanner' ),
						$idx - $start
					),
				);
				continue;
			}
			$result[] = $ops[ $idx ];
			$idx++;
		}

		return $result;
	}
}
