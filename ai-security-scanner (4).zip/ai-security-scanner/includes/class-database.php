<?php
/**
 * Database table creation and access helpers.
 *
 * @package AI_Security_Scanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AISS_Database {

	const DB_VERSION_OPTION = 'aiss_db_version';
	const DB_VERSION        = '1.0.2';

	/**
	 * Get table name helpers.
	 */
	public static function table_scan_history() {
		global $wpdb;
		return $wpdb->prefix . 'aiss_scan_history';
	}

	public static function table_scan_files() {
		global $wpdb;
		return $wpdb->prefix . 'aiss_scan_files';
	}

	public static function table_findings() {
		global $wpdb;
		return $wpdb->prefix . 'aiss_findings';
	}

	public static function table_baseline() {
		global $wpdb;
		return $wpdb->prefix . 'aiss_baseline';
	}

	public static function table_scan_queue() {
		global $wpdb;
		return $wpdb->prefix . 'aiss_scan_queue';
	}

	public static function table_backups() {
		global $wpdb;
		return $wpdb->prefix . 'aiss_backups';
	}

	/**
	 * Create / upgrade database tables using dbDelta().
	 */
	public static function install() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();

		$scan_history = self::table_scan_history();
		$scan_files   = self::table_scan_files();
		$findings     = self::table_findings();
		$baseline     = self::table_baseline();
		$scan_queue   = self::table_scan_queue();
		$backups      = self::table_backups();

		$sql = "CREATE TABLE {$scan_history} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			status VARCHAR(20) NOT NULL DEFAULT 'queued',
			scan_type VARCHAR(20) NOT NULL DEFAULT 'full',
			started_at DATETIME NULL DEFAULT NULL,
			finished_at DATETIME NULL DEFAULT NULL,
			total_files BIGINT UNSIGNED NOT NULL DEFAULT 0,
			files_scanned BIGINT UNSIGNED NOT NULL DEFAULT 0,
			modified_files BIGINT UNSIGNED NOT NULL DEFAULT 0,
			new_files BIGINT UNSIGNED NOT NULL DEFAULT 0,
			deleted_files BIGINT UNSIGNED NOT NULL DEFAULT 0,
			suspicious_files BIGINT UNSIGNED NOT NULL DEFAULT 0,
			critical_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
			high_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
			medium_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
			low_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
			info_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
			initiated_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			create_baseline TINYINT(1) NOT NULL DEFAULT 0,
			error_message TEXT NULL,
			PRIMARY KEY  (id),
			KEY status (status)
		) {$charset_collate};";

		$sql .= "CREATE TABLE {$scan_files} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			scan_id BIGINT UNSIGNED NOT NULL,
			file_path VARCHAR(1000) NOT NULL,
			file_path_hash CHAR(40) NOT NULL,
			file_hash CHAR(64) NULL,
			file_size BIGINT UNSIGNED NULL,
			file_mtime DATETIME NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			change_status VARCHAR(20) NULL,
			risk_level VARCHAR(20) NULL,
			risk_score INT NOT NULL DEFAULT 0,
			content_gz LONGBLOB NULL,
			claim_token VARCHAR(40) NULL,
			claimed_at DATETIME NULL,
			error_message TEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY scan_id (scan_id),
			KEY status (status),
			KEY file_path_hash (file_path_hash),
			KEY change_status (change_status),
			KEY risk_level (risk_level),
			KEY claim_token (claim_token)
		) {$charset_collate};";

		$sql .= "CREATE TABLE {$findings} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			scan_id BIGINT UNSIGNED NOT NULL,
			scan_file_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			file_path VARCHAR(1000) NOT NULL,
			line_number INT NOT NULL DEFAULT 0,
			risk_level VARCHAR(20) NOT NULL DEFAULT 'low',
			risk_score INT NOT NULL DEFAULT 0,
			rule_id VARCHAR(100) NOT NULL DEFAULT '',
			category VARCHAR(100) NOT NULL DEFAULT '',
			reason TEXT NULL,
			matched_pattern TEXT NULL,
			code_snippet LONGTEXT NULL,
			recommendation TEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'open',
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY scan_id (scan_id),
			KEY scan_file_id (scan_file_id),
			KEY risk_level (risk_level),
			KEY status (status)
		) {$charset_collate};";

		$sql .= "CREATE TABLE {$baseline} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			file_path VARCHAR(1000) NOT NULL,
			file_path_hash CHAR(40) NOT NULL,
			file_hash CHAR(64) NOT NULL,
			file_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
			file_mtime DATETIME NULL,
			content_gz LONGBLOB NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY file_path_hash (file_path_hash)
		) {$charset_collate};";

		$sql .= "CREATE TABLE {$scan_queue} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			scan_id BIGINT UNSIGNED NOT NULL,
			relative_dir VARCHAR(1000) NOT NULL,
			claim_token VARCHAR(40) NULL,
			claimed_at DATETIME NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY scan_id (scan_id),
			KEY claim_token (claim_token)
		) {$charset_collate};";

		$sql .= "CREATE TABLE {$backups} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			file_path VARCHAR(1000) NOT NULL,
			action VARCHAR(30) NOT NULL,
			source VARCHAR(30) NOT NULL DEFAULT '',
			original_content_gz LONGBLOB NULL,
			original_existed TINYINT(1) NOT NULL DEFAULT 1,
			new_content_gz LONGBLOB NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'applied',
			performed_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			notes TEXT NULL,
			created_at DATETIME NOT NULL,
			undone_at DATETIME NULL,
			PRIMARY KEY  (id),
			KEY file_path_lookup (file_path(191)),
			KEY status (status)
		) {$charset_collate};";

		dbDelta( $sql );

		update_option( self::DB_VERSION_OPTION, self::DB_VERSION );
	}

	/**
	 * Drop all plugin tables (used on uninstall only).
	 */
	public static function drop_tables() {
		global $wpdb;

		$tables = array(
			self::table_scan_queue(),
			self::table_findings(),
			self::table_scan_files(),
			self::table_baseline(),
			self::table_scan_history(),
			self::table_backups(),
		);

		foreach ( $tables as $table ) {
			$wpdb->query( "DROP TABLE IF EXISTS {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		}

		delete_option( self::DB_VERSION_OPTION );
	}

	/**
	 * Maybe upgrade DB schema if version changed.
	 */
	public static function maybe_upgrade() {
		$installed = get_option( self::DB_VERSION_OPTION, '' );
		if ( $installed !== self::DB_VERSION ) {
			self::install();
		}
	}
}
