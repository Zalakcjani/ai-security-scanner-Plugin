<?php
/**
 * Optional AI analysis layer.
 *
 * The scanner is fully functional without this. When enabled in Settings,
 * a flagged code snippet (never the whole site) can be sent to a configured
 * AI provider for a plain-language explanation. API keys are read from
 * WordPress options server-side only and are never exposed to the browser.
 *
 * @package AI_Security_Scanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Base class for AI providers. Concrete providers implement request().
 */
abstract class Security_AI_Analyzer {

	/**
	 * Analyze a single suspicious code snippet and return a structured explanation.
	 *
	 * @param array $context {
	 *     @type string $file_path   Relative file path (for context only).
	 *     @type string $snippet     The suspicious code snippet (not the full file).
	 *     @type array  $indicators  List of rule descriptions that triggered on this file.
	 *     @type int    $risk_score  Aggregate risk score computed by the rule engine.
	 * }
	 *
	 * @return array|WP_Error {
	 *     @type string $explanation Why the code is suspicious / what it appears to do.
	 *     @type array  $indicators  Indicators considered.
	 *     @type string $recommendation Suggested remediation.
	 *     @type string $confidence  'low'|'medium'|'high'.
	 * }
	 */
	abstract public function analyze( array $context );

	/**
	 * Build the prompt sent to the AI provider. Kept shared so every
	 * provider implementation asks the same question in the same way.
	 */
	protected function build_prompt( array $context ) {
		$indicators = isset( $context['indicators'] ) ? implode( "\n- ", $context['indicators'] ) : '';

		return sprintf(
			"You are assisting with WordPress malware triage. A static rule engine flagged the code below in file \"%s\" with an aggregate risk score of %d.\n\n" .
			"Detected indicators:\n- %s\n\n" .
			"Code snippet:\n```\n%s\n```\n\n" .
			"Respond ONLY with a JSON object with these keys: " .
			"\"explanation\" (why this code is suspicious and what it appears to do), " .
			"\"recommendation\" (suggested remediation, do not claim you can take action), " .
			"\"confidence\" (one of: low, medium, high). Do not include any text outside the JSON object.",
			isset( $context['file_path'] ) ? $context['file_path'] : 'unknown',
			isset( $context['risk_score'] ) ? (int) $context['risk_score'] : 0,
			$indicators,
			isset( $context['snippet'] ) ? mb_substr( $context['snippet'], 0, 4000 ) : ''
		);
	}

	/**
	 * Best-effort extraction of a JSON object from a raw model response.
	 */
	protected function extract_json( $raw_text ) {
		$start = strpos( $raw_text, '{' );
		$end   = strrpos( $raw_text, '}' );

		if ( false === $start || false === $end || $end < $start ) {
			return null;
		}

		$json = substr( $raw_text, $start, $end - $start + 1 );
		$data = json_decode( $json, true );

		return is_array( $data ) ? $data : null;
	}
}

/**
 * Generic HTTP JSON provider: works with any OpenAI-compatible chat
 * completions endpoint (OpenAI, Azure OpenAI, self-hosted, etc.) configured
 * via Settings. Kept intentionally generic rather than hard-coding a single
 * vendor SDK, since this plugin ships with AI analysis disabled by default.
 */
class Security_AI_Analyzer_Generic extends Security_AI_Analyzer {

	private $endpoint;
	private $api_key;
	private $model;

	public function __construct( $endpoint, $api_key, $model ) {
		$this->endpoint = $endpoint;
		$this->api_key  = $api_key;
		$this->model    = $model ? $model : 'gpt-4o-mini';
	}

	public function analyze( array $context ) {
		if ( empty( $this->endpoint ) || empty( $this->api_key ) ) {
			return new WP_Error( 'aiss_ai_not_configured', __( 'AI analysis is enabled but no endpoint/API key is configured in Settings.', 'ai-security-scanner' ) );
		}

		$prompt = $this->build_prompt( $context );

		$body = array(
			'model'    => $this->model,
			'messages' => array(
				array(
					'role'    => 'system',
					'content' => 'You are a precise, cautious WordPress security analyst. You never fabricate certainty.',
				),
				array(
					'role'    => 'user',
					'content' => $prompt,
				),
			),
			'temperature' => 0.1,
			'max_tokens'  => 500,
		);

		$response = wp_remote_post(
			$this->endpoint,
			array(
				'timeout' => 30,
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Authorization' => 'Bearer ' . $this->api_key,
				),
				'body'    => wp_json_encode( $body ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( $code < 200 || $code >= 300 ) {
			return new WP_Error( 'aiss_ai_http_error', sprintf( 'AI provider returned HTTP %d', $code ) );
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		$text = isset( $data['choices'][0]['message']['content'] ) ? $data['choices'][0]['message']['content'] : '';

		$parsed = $this->extract_json( $text );

		if ( null === $parsed ) {
			return new WP_Error( 'aiss_ai_parse_error', __( 'Could not parse a structured response from the AI provider.', 'ai-security-scanner' ) );
		}

		return array(
			'explanation'    => isset( $parsed['explanation'] ) ? sanitize_textarea_field( $parsed['explanation'] ) : '',
			'recommendation' => isset( $parsed['recommendation'] ) ? sanitize_textarea_field( $parsed['recommendation'] ) : '',
			'confidence'     => isset( $parsed['confidence'] ) ? sanitize_key( $parsed['confidence'] ) : 'low',
			'indicators'     => isset( $context['indicators'] ) ? $context['indicators'] : array(),
		);
	}
}

/**
 * Null provider used whenever AI analysis is disabled (the default).
 */
class Security_AI_Analyzer_Null extends Security_AI_Analyzer {
	public function analyze( array $context ) {
		return new WP_Error( 'aiss_ai_disabled', __( 'AI analysis is disabled. Enable it in Settings and configure a provider to use this feature.', 'ai-security-scanner' ) );
	}
}

/**
 * Factory: returns the configured provider instance.
 */
class AISS_AI_Factory {
	public static function get_analyzer() {
		$settings = AISS_Settings::get_settings();

		if ( empty( $settings['ai_enabled'] ) || 'none' === $settings['ai_provider'] ) {
			return new Security_AI_Analyzer_Null();
		}

		switch ( $settings['ai_provider'] ) {
			case 'generic':
			default:
				return new Security_AI_Analyzer_Generic( $settings['ai_endpoint'], $settings['ai_api_key'], $settings['ai_model'] );
		}
	}
}
