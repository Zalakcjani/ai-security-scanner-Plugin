<?php
/**
 * File baseline: trusted snapshot of file hashes used for change detection.
 *
 * @package AI_Security_Scanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AISS_Baseline {

	/**
	 * Does a baseline currently exist?
	 */
	public static function exists() {
		global $wpdb;
		$table = AISS_Database::table_baseline();
		$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return $count > 0;
	}

	public static function count() {
		global $wpdb;
		$table = AISS_Database::table_baseline();
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}

	public static function last_updated() {
		global $wpdb;
		$table = AISS_Database::table_baseline();
		return $wpdb->get_var( "SELECT MAX(updated_at) FROM {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}

	/**
	 * Look up a baseline row by relative file path.
	 */
	public static function get_by_path( $relative_path ) {
		global $wpdb;
		$table = AISS_Database::table_baseline();
		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE file_path_hash = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				sha1( $relative_path )
			)
		);
	}

	/**
	 * Insert or update a single baseline entry.
	 */
	public static function upsert( $relative_path, $file_hash, $file_size, $mtime ) {
		global $wpdb;
		$table = AISS_Database::table_baseline();
		$now   = current_time( 'mysql' );

		$existing = self::get_by_path( $relative_path );

		if ( $existing ) {
			$wpdb->update(
				$table,
				array(
					'file_hash'  => $file_hash,
					'file_size'  => $file_size,
					'file_mtime' => $mtime,
					'updated_at' => $now,
				),
				array( 'id' => $existing->id ),
				array( '%s', '%d', '%s', '%s' ),
				array( '%d' )
			);
		} else {
			$wpdb->insert(
				$table,
				array(
					'file_path'      => $relative_path,
					'file_path_hash' => sha1( $relative_path ),
					'file_hash'      => $file_hash,
					'file_size'      => $file_size,
					'file_mtime'     => $mtime,
					'created_at'     => $now,
					'updated_at'     => $now,
				),
				array( '%s', '%s', '%s', '%d', '%s', '%s', '%s' )
			);
		}
	}

	/**
	 * Replace the entire baseline with the results of the given scan.
	 * Used when the administrator explicitly creates/updates the baseline.
	 */
	public static function rebuild_from_scan( $scan_id ) {
		global $wpdb;

		$files_table    = AISS_Database::table_scan_files();
		$baseline_table = AISS_Database::table_baseline();
		$now            = current_time( 'mysql' );

		$wpdb->query( "TRUNCATE TABLE {$baseline_table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		$batch_size = 500;
		$offset     = 0;

		do {
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT file_path, file_path_hash, file_hash, file_size, file_mtime, content_gz FROM {$files_table} WHERE scan_id = %d AND status = 'scanned' AND file_hash IS NOT NULL ORDER BY id ASC LIMIT %d OFFSET %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					$scan_id,
					$batch_size,
					$offset
				)
			);

			if ( empty( $rows ) ) {
				break;
			}

			foreach ( $rows as $row ) {
				$wpdb->query(
					$wpdb->prepare(
						"INSERT INTO {$baseline_table} (file_path, file_path_hash, file_hash, file_size, file_mtime, content_gz, created_at, updated_at) VALUES (%s, %s, %s, %d, %s, %s, %s, %s)", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
						$row->file_path,
						$row->file_path_hash,
						$row->file_hash,
						$row->file_size,
						$row->file_mtime,
						$row->content_gz,
						$now,
						$now
					)
				);
			}

			$offset += $batch_size;
		} while ( count( $rows ) === $batch_size );
	}

	/**
	 * Decompress a baseline row's stored content snapshot, if any.
	 */
	public static function get_content( $baseline_row ) {
		if ( ! $baseline_row || empty( $baseline_row->content_gz ) ) {
			return null;
		}
		$decompressed = @gzuncompress( $baseline_row->content_gz ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		return false === $decompressed ? null : $decompressed;
	}

	/**
	 * Determine which baseline files were not seen in the given scan (i.e. deleted).
	 * Returns an array of relative file paths.
	 */
	public static function find_deleted_files( $scan_id ) {
		global $wpdb;

		$files_table    = AISS_Database::table_scan_files();
		$baseline_table = AISS_Database::table_baseline();

		$sql = "SELECT b.file_path FROM {$baseline_table} b
			LEFT JOIN {$files_table} f ON f.file_path_hash = b.file_path_hash AND f.scan_id = %d
			WHERE f.id IS NULL";

		return $wpdb->get_col( $wpdb->prepare( $sql, $scan_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}
}
