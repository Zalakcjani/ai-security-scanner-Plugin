<?php
/**
 * AJAX endpoints. Every handler verifies the nonce and the required
 * capability before doing anything, and never accepts a raw filesystem path
 * from the client — only relative paths that are re-validated against
 * ABSPATH via AISS_File_Scanner::to_absolute_path().
 *
 * @package AI_Security_Scanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AISS_Ajax {

	public static function init() {
		$actions = array(
			'aiss_start_scan'      => 'start_scan',
			'aiss_scan_progress'   => 'scan_progress',
			'aiss_cancel_scan'     => 'cancel_scan',
			'aiss_get_finding'     => 'get_finding',
			'aiss_ignore_finding'  => 'ignore_finding',
			'aiss_get_diff'        => 'get_diff',
			'aiss_create_baseline' => 'create_baseline',
			'aiss_check_core'      => 'check_core',
			'aiss_export_report'   => 'export_report',
			'aiss_ai_analyze'      => 'ai_analyze',
			'aiss_save_settings'   => 'save_settings',
			'aiss_fix_action'      => 'fix_action',
			'aiss_fix_undo'        => 'fix_undo',
			'aiss_toggle_lock'     => 'toggle_lock',
		);

		foreach ( $actions as $action => $method ) {
			add_action( 'wp_ajax_' . $action, array( __CLASS__, $method ) );
		}
	}

	private static function verify_request() {
		if ( ! current_user_can( AISS_Admin::capability() ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'ai-security-scanner' ) ), 403 );
		}

		check_ajax_referer( 'aiss_ajax_nonce', 'nonce' );
	}

	/**
	 * Fix actions write to the filesystem, so they're checked against a
	 * separate nonce from the rest of the (read-only) AJAX surface, on top
	 * of the same capability check and the AISS_Remediation::is_enabled()
	 * gate each action performs itself.
	 */
	private static function verify_fix_request() {
		if ( ! current_user_can( AISS_Admin::capability() ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'ai-security-scanner' ) ), 403 );
		}

		check_ajax_referer( 'aiss_fix_nonce', 'nonce' );

		if ( ! AISS_Remediation::is_enabled() ) {
			wp_send_json_error( array( 'message' => __( 'Fix actions are disabled. Enable them under Security Scanner → Settings first.', 'ai-security-scanner' ) ) );
		}
	}

	/**
	 * Capability + nonce only, no feature-flag gate — for actions that must
	 * stay available regardless of whether Fix Actions is currently toggled
	 * on: toggling File Lock Protection itself (its own independent gate),
	 * and undoing a past fix/auto-revert (undo is corrective/safe and must
	 * not depend on whichever feature happened to create the backup entry —
	 * e.g. a watchdog auto-revert from File Lock Protection must still be
	 * undoable even if the separate Fix Actions toggle is off).
	 */
	private static function verify_write_request() {
		if ( ! current_user_can( AISS_Admin::capability() ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'ai-security-scanner' ) ), 403 );
		}

		check_ajax_referer( 'aiss_fix_nonce', 'nonce' );
	}

	public static function start_scan() {
		self::verify_request();

		$create_baseline = isset( $_POST['create_baseline'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['create_baseline'] ) );

		$scan_id = AISS_Scanner::start_scan( $create_baseline );

		wp_send_json_success( array( 'scan_id' => $scan_id ) );
	}

	public static function scan_progress() {
		self::verify_request();

		$scan_id = isset( $_POST['scan_id'] ) ? absint( $_POST['scan_id'] ) : 0;
		if ( ! $scan_id ) {
			wp_send_json_error( array( 'message' => __( 'Missing scan ID.', 'ai-security-scanner' ) ) );
		}

		$payload = AISS_Scanner::process_next_batch( $scan_id );

		wp_send_json_success( $payload );
	}

	public static function cancel_scan() {
		self::verify_request();

		$scan_id = isset( $_POST['scan_id'] ) ? absint( $_POST['scan_id'] ) : 0;
		if ( ! $scan_id ) {
			wp_send_json_error( array( 'message' => __( 'Missing scan ID.', 'ai-security-scanner' ) ) );
		}

		AISS_Scanner::cancel_scan( $scan_id );

		wp_send_json_success();
	}

	public static function get_finding() {
		self::verify_request();

		global $wpdb;

		$finding_id = isset( $_POST['finding_id'] ) ? absint( $_POST['finding_id'] ) : 0;
		if ( ! $finding_id ) {
			wp_send_json_error( array( 'message' => __( 'Missing finding ID.', 'ai-security-scanner' ) ) );
		}

		$table   = AISS_Database::table_findings();
		$finding = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $finding_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if ( ! $finding ) {
			wp_send_json_error( array( 'message' => __( 'Finding not found.', 'ai-security-scanner' ) ) );
		}

		wp_send_json_success( $finding );
	}

	public static function ignore_finding() {
		self::verify_request();

		global $wpdb;

		$finding_id = isset( $_POST['finding_id'] ) ? absint( $_POST['finding_id'] ) : 0;
		$new_status = isset( $_POST['ignored'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['ignored'] ) ) ? 'ignored' : 'open';

		if ( ! $finding_id ) {
			wp_send_json_error( array( 'message' => __( 'Missing finding ID.', 'ai-security-scanner' ) ) );
		}

		$table = AISS_Database::table_findings();
		$wpdb->update( $table, array( 'status' => $new_status ), array( 'id' => $finding_id ), array( '%s' ), array( '%d' ) );

		wp_send_json_success();
	}

	/**
	 * Compare the baseline snapshot of a file against its current content.
	 * The file path never comes from the client as a raw filesystem path —
	 * only a relative scan_file_id/finding lookup is accepted, and the
	 * resolved path is re-validated to stay within ABSPATH.
	 */
	public static function get_diff() {
		self::verify_request();

		global $wpdb;

		$scan_file_id = isset( $_POST['scan_file_id'] ) ? absint( $_POST['scan_file_id'] ) : 0;
		if ( ! $scan_file_id ) {
			wp_send_json_error( array( 'message' => __( 'Missing file reference.', 'ai-security-scanner' ) ) );
		}

		$files_table = AISS_Database::table_scan_files();
		$file_row    = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$files_table} WHERE id = %d", $scan_file_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if ( ! $file_row ) {
			wp_send_json_error( array( 'message' => __( 'Scanned file record not found.', 'ai-security-scanner' ) ) );
		}

		$absolute_path = AISS_File_Scanner::to_absolute_path( $file_row->file_path );
		if ( false === $absolute_path ) {
			wp_send_json_error( array( 'message' => __( 'Invalid file path.', 'ai-security-scanner' ) ) );
		}

		$baseline_row = AISS_Baseline::get_by_path( $file_row->file_path );
		$old_content  = AISS_Baseline::get_content( $baseline_row );

		$settings    = AISS_Settings::get_settings();
		$new_content = AISS_File_Scanner::read_file_capped( $absolute_path, $settings['max_file_size'] );

		if ( null === $old_content && null === $new_content ) {
			wp_send_json_error( array( 'message' => __( 'No content is available to compare for this file (it may exceed the maximum inspected file size).', 'ai-security-scanner' ) ) );
		}

		$diff = AISS_Diff_Analyzer::diff( (string) $old_content, (string) $new_content );

		wp_send_json_success(
			array(
				'file_path'    => $file_row->file_path,
				'has_baseline' => null !== $old_content,
				'diff'         => $diff,
			)
		);
	}

	public static function create_baseline() {
		self::verify_request();

		$scan_id = isset( $_POST['scan_id'] ) ? absint( $_POST['scan_id'] ) : 0;

		if ( ! $scan_id ) {
			$latest = AISS_Scanner::get_latest_completed_scan();
			$scan_id = $latest ? (int) $latest->id : 0;
		}

		if ( ! $scan_id ) {
			wp_send_json_error( array( 'message' => __( 'No completed scan is available to build a baseline from. Run a full scan first.', 'ai-security-scanner' ) ) );
		}

		AISS_Baseline::rebuild_from_scan( $scan_id );

		wp_send_json_success(
			array(
				'count'        => AISS_Baseline::count(),
				'last_updated' => AISS_Baseline::last_updated(),
			)
		);
	}

	public static function check_core() {
		self::verify_request();

		$result = AISS_Core_Checker::check_core_integrity();

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( $result );
	}

	public static function export_report() {
		if ( ! current_user_can( AISS_Admin::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'ai-security-scanner' ), 403 );
		}

		check_admin_referer( 'aiss_export_report' );

		$scan_id = isset( $_GET['scan_id'] ) ? absint( $_GET['scan_id'] ) : 0;
		$format  = isset( $_GET['format'] ) ? sanitize_key( $_GET['format'] ) : 'csv';

		if ( ! $scan_id ) {
			wp_die( esc_html__( 'Missing scan ID.', 'ai-security-scanner' ) );
		}

		if ( 'json' === $format ) {
			$body = AISS_Report_Exporter::to_json( $scan_id );
			if ( null === $body ) {
				wp_die( esc_html__( 'Scan not found.', 'ai-security-scanner' ) );
			}
			nocache_headers();
			header( 'Content-Type: application/json; charset=utf-8' );
			header( 'Content-Disposition: attachment; filename="security-scan-' . $scan_id . '.json"' );
			echo $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			exit;
		}

		$body = AISS_Report_Exporter::to_csv( $scan_id );
		if ( null === $body ) {
			wp_die( esc_html__( 'Scan not found.', 'ai-security-scanner' ) );
		}
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="security-scan-' . $scan_id . '.csv"' );
		echo $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	public static function ai_analyze() {
		self::verify_request();

		global $wpdb;

		$finding_id = isset( $_POST['finding_id'] ) ? absint( $_POST['finding_id'] ) : 0;
		if ( ! $finding_id ) {
			wp_send_json_error( array( 'message' => __( 'Missing finding ID.', 'ai-security-scanner' ) ) );
		}

		$table   = AISS_Database::table_findings();
		$finding = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $finding_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if ( ! $finding ) {
			wp_send_json_error( array( 'message' => __( 'Finding not found.', 'ai-security-scanner' ) ) );
		}

		$analyzer = AISS_AI_Factory::get_analyzer();

		$result = $analyzer->analyze(
			array(
				'file_path'  => $finding->file_path,
				'snippet'    => $finding->code_snippet,
				'indicators' => array( $finding->reason ),
				'risk_score' => $finding->risk_score,
			)
		);

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( $result );
	}

	public static function save_settings() {
		if ( ! current_user_can( AISS_Admin::capability() ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'ai-security-scanner' ) ), 403 );
		}

		check_ajax_referer( 'aiss_settings_nonce', 'nonce' );

		$input = isset( $_POST['settings'] ) && is_array( $_POST['settings'] )
			? wp_unslash( $_POST['settings'] )
			: array();

		$saved = AISS_Settings::save_from_request( $input );

		wp_send_json_success( array( 'settings' => $saved ) );
	}

	/**
	 * Apply one confirmation-gated fix action to a single file. The client
	 * sends a relative file path (never trusted as-is — every method in
	 * AISS_Remediation re-validates it against ABSPATH) and a method name
	 * selecting which trusted source to restore from.
	 */
	public static function fix_action() {
		self::verify_fix_request();

		$relative_path = isset( $_POST['file_path'] ) ? sanitize_text_field( wp_unslash( $_POST['file_path'] ) ) : '';
		$method        = isset( $_POST['method'] ) ? sanitize_key( $_POST['method'] ) : '';

		if ( '' === $relative_path ) {
			wp_send_json_error( array( 'message' => __( 'Missing file path.', 'ai-security-scanner' ) ) );
		}

		switch ( $method ) {
			case 'restore_core':
				$result = AISS_Remediation::restore_official_core_file( $relative_path );
				break;
			case 'restore_plugin':
				$result = AISS_Remediation::restore_official_plugin_file( $relative_path );
				break;
			case 'restore_baseline':
				$result = AISS_Remediation::restore_from_baseline( $relative_path );
				break;
			case 'quarantine':
				$result = AISS_Remediation::quarantine_file( $relative_path );
				break;
			default:
				wp_send_json_error( array( 'message' => __( 'Unknown fix method.', 'ai-security-scanner' ) ) );
				return;
		}

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( $result );
	}

	public static function fix_undo() {
		self::verify_write_request();

		$backup_id = isset( $_POST['backup_id'] ) ? absint( $_POST['backup_id'] ) : 0;
		if ( ! $backup_id ) {
			wp_send_json_error( array( 'message' => __( 'Missing backup ID.', 'ai-security-scanner' ) ) );
		}

		$result = AISS_Remediation::undo( $backup_id );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success();
	}

	public static function toggle_lock() {
		self::verify_write_request();

		$enable = isset( $_POST['enable'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['enable'] ) );

		$result = $enable ? AISS_Integrity_Lock::enable() : AISS_Integrity_Lock::disable();

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( $result );
	}
}
