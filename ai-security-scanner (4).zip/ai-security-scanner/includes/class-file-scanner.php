<?php
/**
 * Filesystem walker: builds the list of files to scan in resumable batches.
 *
 * Uses a breadth-first directory queue stored in the aiss_scan_queue table so
 * that very large sites never require an unbounded recursive iterator to stay
 * alive across a single PHP request.
 *
 * @package AI_Security_Scanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AISS_File_Scanner {

	/**
	 * Directories (relative to ABSPATH) that are always ignored.
	 */
	public static function get_default_excluded_dirs() {
		return array(
			'.git',
			'.svn',
			'node_modules',
			'vendor/bin',
			'wp-content/cache',
			'wp-content/uploads/cache',
			'wp-content/backup',
			'wp-content/backups',
			'wp-content/upgrade',
			'wp-content/debug.log',
		);
	}

	public static function get_default_allowed_extensions() {
		return array( 'php', 'phtml', 'php5', 'php7', 'inc', 'js', 'html', 'htm', 'css', 'json', 'xml', 'txt', 'htaccess' );
	}

	/**
	 * Resolve the absolute root directory that scans start from.
	 */
	public static function get_root_dir() {
		return wp_normalize_path( untrailingslashit( ABSPATH ) );
	}

	/**
	 * Normalize a path to use forward slashes and no trailing slash.
	 */
	public static function normalize_path( $path ) {
		return untrailingslashit( wp_normalize_path( $path ) );
	}

	/**
	 * Convert an absolute path into a path relative to ABSPATH.
	 * Returns false if the path is not inside ABSPATH (prevents path traversal).
	 */
	public static function to_relative_path( $absolute_path ) {
		$root     = self::get_root_dir();
		$absolute = self::normalize_path( $absolute_path );

		if ( 0 !== strpos( $absolute . '/', $root . '/' ) ) {
			return false;
		}

		$relative = substr( $absolute, strlen( $root ) );
		return ltrim( $relative, '/' );
	}

	/**
	 * Convert a relative path (as stored in the DB) back into a safe absolute
	 * path. Rejects any path that escapes ABSPATH via traversal segments.
	 */
	public static function to_absolute_path( $relative_path ) {
		$relative_path = str_replace( '\\', '/', (string) $relative_path );

		if ( false !== strpos( $relative_path, "\0" ) ) {
			return false;
		}

		$segments = explode( '/', $relative_path );
		foreach ( $segments as $segment ) {
			if ( '..' === $segment ) {
				return false;
			}
		}

		$root     = self::get_root_dir();
		$absolute = self::normalize_path( $root . '/' . ltrim( $relative_path, '/' ) );

		if ( 0 !== strpos( $absolute . '/', $root . '/' ) ) {
			return false;
		}

		return $absolute;
	}

	/**
	 * Is the given relative directory path excluded from scanning?
	 */
	public static function is_excluded_dir( $relative_dir, array $excluded_dirs ) {
		$relative_dir = trim( str_replace( '\\', '/', $relative_dir ), '/' );

		foreach ( $excluded_dirs as $excluded ) {
			$excluded = trim( str_replace( '\\', '/', $excluded ), '/' );
			if ( '' === $excluded ) {
				continue;
			}
			if ( $relative_dir === $excluded || 0 === strpos( $relative_dir . '/', $excluded . '/' ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Should this file (by extension / basename) be inspected?
	 */
	public static function is_scannable_file( $filename, array $allowed_extensions ) {
		$basename = basename( $filename );

		// Special-case files with no standard extension.
		if ( '.htaccess' === $basename || '.user.ini' === $basename ) {
			return true;
		}

		$ext = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
		if ( '' === $ext ) {
			return false;
		}

		return in_array( $ext, $allowed_extensions, true );
	}

	/**
	 * Seed the directory queue for a new scan.
	 */
	public static function seed_queue( $scan_id ) {
		global $wpdb;

		$table = AISS_Database::table_scan_queue();
		$wpdb->insert(
			$table,
			array(
				'scan_id'      => $scan_id,
				'relative_dir' => '',
				'created_at'   => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s' )
		);
	}

	/**
	 * Process one batch of the directory queue: pop up to $max_dirs
	 * directories, list their immediate children, enqueue files found and
	 * push subdirectories back onto the queue.
	 *
	 * Returns array( 'done' => bool, 'files_found' => int, 'dirs_processed' => int ).
	 */
	public static function process_queue_batch( $scan_id, $max_dirs = 25 ) {
		global $wpdb;

		$queue_table = AISS_Database::table_scan_queue();
		$files_table = AISS_Database::table_scan_files();

		$settings          = AISS_Settings::get_settings();
		$excluded_dirs      = $settings['excluded_dirs'];
		$allowed_extensions = $settings['allowed_extensions'];

		// Reclaim any batch that was claimed but never finished (crashed request).
		$stale_before = gmdate( 'Y-m-d H:i:s', time() - AISS_Scanner::STALE_CLAIM_SECONDS );
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$queue_table} SET claim_token = NULL, claimed_at = NULL WHERE scan_id = %d AND claim_token IS NOT NULL AND claimed_at < %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$scan_id,
				$stale_before
			)
		);

		// Claim rows atomically before reading them, so two overlapping requests
		// (e.g. the Full Scan page open in two tabs) can never both list the
		// same directory and double-insert its files.
		$token = wp_generate_password( 32, false, false );

		$claimed = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$queue_table} SET claim_token = %s, claimed_at = %s WHERE scan_id = %d AND claim_token IS NULL ORDER BY id ASC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$token,
				current_time( 'mysql' ),
				$scan_id,
				$max_dirs
			)
		);

		$rows = $claimed
			? $wpdb->get_results(
				$wpdb->prepare(
					"SELECT id, relative_dir FROM {$queue_table} WHERE scan_id = %d AND claim_token = %s ORDER BY id ASC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					$scan_id,
					$token
				)
			)
			: array();

		$files_found    = 0;
		$dirs_processed = 0;

		foreach ( $rows as $row ) {
			$dirs_processed++;

			$relative_dir = $row->relative_dir;
			$absolute_dir = '' === $relative_dir ? self::get_root_dir() : self::to_absolute_path( $relative_dir );

			$wpdb->delete( $queue_table, array( 'id' => $row->id ), array( '%d' ) );

			if ( false === $absolute_dir || ! is_dir( $absolute_dir ) || ! is_readable( $absolute_dir ) ) {
				continue;
			}

			$entries = @scandir( $absolute_dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			if ( false === $entries ) {
				continue;
			}

			$new_dirs  = array();
			$new_files = array();

			foreach ( $entries as $entry ) {
				if ( '.' === $entry || '..' === $entry ) {
					continue;
				}

				$entry_relative = '' === $relative_dir ? $entry : $relative_dir . '/' . $entry;
				$entry_absolute = $absolute_dir . '/' . $entry;

				if ( is_link( $entry_absolute ) ) {
					continue; // Never follow symlinks (avoids escaping the site root).
				}

				if ( is_dir( $entry_absolute ) ) {
					if ( self::is_excluded_dir( $entry_relative, $excluded_dirs ) ) {
						continue;
					}
					$new_dirs[] = $entry_relative;
					continue;
				}

				if ( ! is_file( $entry_absolute ) ) {
					continue;
				}

				if ( ! self::is_scannable_file( $entry, $allowed_extensions ) ) {
					continue;
				}

				$new_files[] = $entry_relative;
			}

			if ( ! empty( $new_dirs ) ) {
				$values       = array();
				$placeholders = array();
				$now          = current_time( 'mysql' );
				foreach ( $new_dirs as $dir ) {
					$placeholders[] = '(%d, %s, %s)';
					$values[]       = $scan_id;
					$values[]       = $dir;
					$values[]       = $now;
				}
				$sql = "INSERT INTO {$queue_table} (scan_id, relative_dir, created_at) VALUES " . implode( ', ', $placeholders ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$wpdb->query( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			}

			if ( ! empty( $new_files ) ) {
				$now = current_time( 'mysql' );
				foreach ( array_chunk( $new_files, 100 ) as $chunk ) {
					$values       = array();
					$placeholders = array();
					foreach ( $chunk as $file_rel ) {
						$placeholders[] = '(%d, %s, %s, %s, %s)';
						$values[]       = $scan_id;
						$values[]       = $file_rel;
						$values[]       = sha1( $file_rel );
						$values[]       = 'pending';
						$values[]       = $now;
					}
					$sql = "INSERT INTO {$files_table} (scan_id, file_path, file_path_hash, status, created_at) VALUES " . implode( ', ', $placeholders ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					$wpdb->query( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
					$files_found += count( $chunk );
				}
			}
		}

		$remaining = (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(*) FROM {$queue_table} WHERE scan_id = %d", $scan_id ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);

		return array(
			'done'           => 0 === $remaining,
			'files_found'    => $files_found,
			'dirs_processed' => $dirs_processed,
		);
	}

	/**
	 * Safely read file contents, capped at a maximum size.
	 * Returns null if the file cannot be read or exceeds the size cap.
	 */
	public static function read_file_capped( $absolute_path, $max_bytes ) {
		if ( ! is_file( $absolute_path ) || ! is_readable( $absolute_path ) ) {
			return null;
		}

		$size = filesize( $absolute_path );
		if ( false === $size || $size > $max_bytes ) {
			return null;
		}

		$contents = @file_get_contents( $absolute_path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		return false === $contents ? null : $contents;
	}

	/**
	 * Compute a SHA-256 hash of a file's contents.
	 */
	public static function hash_file( $absolute_path ) {
		if ( ! is_file( $absolute_path ) || ! is_readable( $absolute_path ) ) {
			return null;
		}
		$hash = @hash_file( 'sha256', $absolute_path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		return false === $hash ? null : $hash;
	}
}
