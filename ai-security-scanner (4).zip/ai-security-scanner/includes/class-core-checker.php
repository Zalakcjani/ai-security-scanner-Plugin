<?php
/**
 * Verifies WordPress core files against the official checksums published by
 * the WordPress.org API. Read-only: never modifies or repairs files.
 *
 * @package AI_Security_Scanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AISS_Core_Checker {

	const TRANSIENT_KEY = 'aiss_core_checksums';

	/**
	 * Fetch official checksums for the running WP version/locale.
	 * Cached for 12 hours to avoid hammering the API.
	 *
	 * @return array|WP_Error Map of relative path => md5 hash, or WP_Error on failure.
	 */
	public static function get_official_checksums() {
		global $wp_version;

		$locale = get_locale();
		$cache_key = self::TRANSIENT_KEY . '_' . $wp_version . '_' . $locale;

		$cached = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}

		$url = add_query_arg(
			array(
				'version' => $wp_version,
				'locale'  => $locale,
			),
			'https://api.wordpress.org/core/checksums/1.0/'
		);

		$response = wp_remote_get( $url, array( 'timeout' => 20 ) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== (int) $code ) {
			return new WP_Error( 'aiss_core_checksum_http_error', sprintf( 'WordPress.org checksum API returned HTTP %d', $code ) );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( empty( $body['checksums'] ) || ! is_array( $body['checksums'] ) ) {
			return new WP_Error( 'aiss_core_checksum_empty', 'No checksums returned for this WordPress version/locale.' );
		}

		set_transient( $cache_key, $body['checksums'], 12 * HOUR_IN_SECONDS );

		return $body['checksums'];
	}

	/**
	 * Compare installed core files against official checksums.
	 *
	 * @return array|WP_Error {
	 *     @type array $modified  Relative paths of files whose hash differs.
	 *     @type array $missing   Relative paths present upstream but absent locally.
	 *     @type array $unexpected Relative core-area paths present locally but not upstream (excludes wp-content).
	 *     @type int   $checked   Number of files compared.
	 * }
	 */
	public static function check_core_integrity() {
		$checksums = self::get_official_checksums();

		if ( is_wp_error( $checksums ) ) {
			return $checksums;
		}

		$root     = AISS_File_Scanner::get_root_dir();
		$modified = array();
		$missing  = array();
		$checked  = 0;

		foreach ( $checksums as $relative_path => $expected_md5 ) {
			// wp-content is user territory (plugins/themes/uploads); core checksums
			// only ship a handful of default theme files there which are noisy and
			// not security-relevant here, so we skip anything under wp-content.
			if ( 0 === strpos( $relative_path, 'wp-content/' ) ) {
				continue;
			}

			$absolute = AISS_File_Scanner::to_absolute_path( $relative_path );
			if ( false === $absolute ) {
				continue;
			}

			$checked++;

			if ( ! is_file( $absolute ) ) {
				$missing[] = $relative_path;
				continue;
			}

			$actual_md5 = @md5_file( $absolute ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

			if ( false === $actual_md5 || ! hash_equals( (string) $expected_md5, (string) $actual_md5 ) ) {
				$modified[] = $relative_path;
			}
		}

		$unexpected = self::find_unexpected_core_files( $checksums );

		return array(
			'modified'   => $modified,
			'missing'    => $missing,
			'unexpected' => $unexpected,
			'checked'    => $checked,
		);
	}

	/**
	 * Look for PHP files inside wp-admin / wp-includes that are not part of
	 * the official checksum manifest — a common place for backdoors to hide
	 * since admins rarely inspect core directories manually.
	 */
	private static function find_unexpected_core_files( array $checksums ) {
		$known = array();
		foreach ( array_keys( $checksums ) as $path ) {
			if ( 0 === strpos( $path, 'wp-admin/' ) || 0 === strpos( $path, 'wp-includes/' ) ) {
				$known[ $path ] = true;
			}
		}

		$root       = AISS_File_Scanner::get_root_dir();
		$unexpected = array();

		foreach ( array( 'wp-admin', 'wp-includes' ) as $core_dir ) {
			$dir = $root . '/' . $core_dir;
			if ( ! is_dir( $dir ) ) {
				continue;
			}

			$iterator = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS )
			);

			foreach ( $iterator as $file_info ) {
				if ( ! $file_info->isFile() ) {
					continue;
				}

				$relative = AISS_File_Scanner::to_relative_path( $file_info->getPathname() );
				if ( false === $relative ) {
					continue;
				}

				if ( ! isset( $known[ $relative ] ) ) {
					$unexpected[] = $relative;
				}

				if ( count( $unexpected ) >= 500 ) {
					break 2; // Safety cap for pathological cases.
				}
			}
		}

		return $unexpected;
	}
}
