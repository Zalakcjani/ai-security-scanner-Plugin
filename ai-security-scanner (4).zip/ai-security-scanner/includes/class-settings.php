<?php
/**
 * Plugin settings: storage, defaults and the Settings API page.
 *
 * @package AI_Security_Scanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AISS_Settings {

	const OPTION_KEY = 'aiss_settings';

	/**
	 * Default settings.
	 */
	public static function get_defaults() {
		return array(
			'batch_size'          => 40,
			'dir_batch_size'      => 40,
			'excluded_dirs'       => AISS_File_Scanner::get_default_excluded_dirs(),
			'allowed_extensions'  => AISS_File_Scanner::get_default_allowed_extensions(),
			'max_file_size'       => 5 * 1024 * 1024, // 5 MB.
			'ai_enabled'          => false,
			'ai_provider'         => 'none',
			'ai_endpoint'         => '',
			'ai_model'            => '',
			'ai_api_key'          => '',
			'fix_actions_enabled' => false,
			'integrity_lock_enabled'   => false,
			'watchdog_interval_minutes' => 5,
		);
	}

	/**
	 * Get merged settings (defaults + stored overrides).
	 */
	public static function get_settings() {
		$stored = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		return wp_parse_args( $stored, self::get_defaults() );
	}

	public static function get( $key, $default = null ) {
		$settings = self::get_settings();
		return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
	}

	/**
	 * Sanitize and persist settings from a submitted form array.
	 */
	public static function save_from_request( array $input ) {
		$defaults = self::get_defaults();
		$current  = self::get_settings();

		$clean = $current;

		$clean['batch_size']     = isset( $input['batch_size'] ) ? max( 1, min( 200, absint( $input['batch_size'] ) ) ) : $defaults['batch_size'];
		$clean['dir_batch_size'] = isset( $input['dir_batch_size'] ) ? max( 1, min( 200, absint( $input['dir_batch_size'] ) ) ) : $defaults['dir_batch_size'];
		$clean['max_file_size']  = isset( $input['max_file_size'] ) ? max( 1024, absint( $input['max_file_size'] ) ) : $defaults['max_file_size'];

		if ( isset( $input['excluded_dirs'] ) ) {
			$lines = preg_split( '/[\r\n]+/', (string) $input['excluded_dirs'] );
			$clean['excluded_dirs'] = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', $lines ) ) ) );
		}

		if ( isset( $input['allowed_extensions'] ) ) {
			$parts = preg_split( '/[\s,]+/', (string) $input['allowed_extensions'] );
			$clean['allowed_extensions'] = array_values( array_filter( array_map( function ( $ext ) {
				return strtolower( preg_replace( '/[^a-zA-Z0-9]/', '', $ext ) );
			}, $parts ) ) );
		}

		$clean['ai_enabled']  = ! empty( $input['ai_enabled'] );
		$clean['ai_provider'] = isset( $input['ai_provider'] ) ? sanitize_key( $input['ai_provider'] ) : $defaults['ai_provider'];
		$clean['ai_endpoint'] = isset( $input['ai_endpoint'] ) ? esc_url_raw( trim( $input['ai_endpoint'] ) ) : $defaults['ai_endpoint'];
		$clean['ai_model']    = isset( $input['ai_model'] ) ? sanitize_text_field( $input['ai_model'] ) : $defaults['ai_model'];

		// Only overwrite the stored API key if a new, non-masked value was submitted.
		if ( isset( $input['ai_api_key'] ) && '' !== trim( $input['ai_api_key'] ) && false === strpos( $input['ai_api_key'], '••••' ) ) {
			$clean['ai_api_key'] = sanitize_text_field( $input['ai_api_key'] );
		}

		$clean['fix_actions_enabled'] = ! empty( $input['fix_actions_enabled'] );

		// integrity_lock_enabled is deliberately NOT settable through this
		// generic form — flipping it has real filesystem side effects
		// (chmod'ing every baseline file) that must go through
		// AISS_Integrity_Lock::enable()/disable(), never a silent save.
		if ( isset( $input['watchdog_interval_minutes'] ) ) {
			$clean['watchdog_interval_minutes'] = max( 1, min( 60, absint( $input['watchdog_interval_minutes'] ) ) );
		}

		update_option( self::OPTION_KEY, $clean, false );

		if ( ! empty( $clean['integrity_lock_enabled'] ) && $clean['watchdog_interval_minutes'] !== $current['watchdog_interval_minutes'] ) {
			AISS_Integrity_Lock::reschedule_cron();
		}

		return $clean;
	}

	/**
	 * Register uninstall-safe defaults on activation.
	 */
	public static function maybe_set_defaults() {
		if ( false === get_option( self::OPTION_KEY, false ) ) {
			update_option( self::OPTION_KEY, self::get_defaults(), false );
		}
	}

	/**
	 * Mask an API key for display in the settings form.
	 */
	public static function mask_key( $key ) {
		if ( '' === $key ) {
			return '';
		}
		$len = strlen( $key );
		if ( $len <= 4 ) {
			return str_repeat( '•', $len );
		}
		return str_repeat( '•', $len - 4 ) . substr( $key, -4 );
	}
}
