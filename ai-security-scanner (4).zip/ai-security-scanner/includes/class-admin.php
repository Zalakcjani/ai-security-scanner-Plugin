<?php
/**
 * Admin menu registration, asset enqueueing and view rendering.
 *
 * @package AI_Security_Scanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AISS_Admin {

	const MENU_SLUG = 'ai-security-scanner';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/**
	 * The capability required to use any part of this plugin.
	 * Filterable so multisite/agency setups can restrict further.
	 */
	public static function capability() {
		return apply_filters( 'aiss_capability', 'manage_options' );
	}

	public static function register_menu() {
		$cap = self::capability();

		add_menu_page(
			__( 'Security Scanner', 'ai-security-scanner' ),
			__( 'Security Scanner', 'ai-security-scanner' ),
			$cap,
			self::MENU_SLUG,
			array( __CLASS__, 'render_dashboard' ),
			'dashicons-shield',
			80
		);

		$pages = array(
			'dashboard'         => __( 'Dashboard', 'ai-security-scanner' ),
			'full-scan'         => __( 'Full Scan', 'ai-security-scanner' ),
			'suspicious-files'  => __( 'Suspicious Files', 'ai-security-scanner' ),
			'modified-files'    => __( 'Modified Files', 'ai-security-scanner' ),
			'new-files'         => __( 'New Files', 'ai-security-scanner' ),
			'core-integrity'    => __( 'Core Integrity', 'ai-security-scanner' ),
			'scan-history'      => __( 'Scan History', 'ai-security-scanner' ),
			'remediation-log'   => __( 'Remediation Log', 'ai-security-scanner' ),
			'settings'          => __( 'Settings', 'ai-security-scanner' ),
		);

		foreach ( $pages as $slug => $label ) {
			$page_hook = 'dashboard' === $slug ? self::MENU_SLUG : self::MENU_SLUG . '-' . $slug;
			add_submenu_page(
				self::MENU_SLUG,
				sprintf( '%s — %s', __( 'Security Scanner', 'ai-security-scanner' ), $label ),
				$label,
				$cap,
				$page_hook,
				array( __CLASS__, 'render_' . str_replace( '-', '_', $slug ) )
			);
		}
	}

	public static function enqueue_assets( $hook ) {
		if ( false === strpos( $hook, self::MENU_SLUG ) ) {
			return;
		}

		wp_enqueue_style( 'aiss-admin', AISS_PLUGIN_URL . 'admin/css/admin.css', array(), AISS_VERSION );
		wp_enqueue_script( 'aiss-admin', AISS_PLUGIN_URL . 'admin/js/admin.js', array( 'jquery' ), AISS_VERSION, true );

		wp_localize_script(
			'aiss-admin',
			'AISS',
			array(
				'ajaxUrl'        => admin_url( 'admin-ajax.php' ),
				'nonce'          => wp_create_nonce( 'aiss_ajax_nonce' ),
				'settingsNonce'  => wp_create_nonce( 'aiss_settings_nonce' ),
				'fixNonce'       => wp_create_nonce( 'aiss_fix_nonce' ),
				'fixActionsEnabled' => AISS_Remediation::is_enabled(),
				'adminUrl'       => admin_url( 'admin.php' ),
				'menuSlug'       => self::MENU_SLUG,
				'activeScanId'   => ( $active = AISS_Scanner::get_active_scan() ) ? (int) $active->id : 0,
				'i18n'           => array(
					'confirmCancel'   => __( 'Cancel the current scan?', 'ai-security-scanner' ),
					'confirmBaseline' => __( 'This will replace the current baseline with the results of the selected scan. Continue?', 'ai-security-scanner' ),
					'scanning'        => __( 'Scanning…', 'ai-security-scanner' ),
					'listing'         => __( 'Building file list…', 'ai-security-scanner' ),
					'finalizing'      => __( 'Finalizing…', 'ai-security-scanner' ),
					'error'           => __( 'An error occurred.', 'ai-security-scanner' ),
					'viewCode'        => __( 'View Code', 'ai-security-scanner' ),
					'fixWorking'      => __( 'Applying fix…', 'ai-security-scanner' ),
					'fixSuccess'      => __( 'Fix applied. A backup of the previous content was saved to the Remediation Log.', 'ai-security-scanner' ),
					'confirmUndo'     => __( 'Undo this fix and restore the file to what it was before?', 'ai-security-scanner' ),
					'fixButton'          => __( 'Fix…', 'ai-security-scanner' ),
					'fixRestoreCore'     => __( 'Restore Official Core File', 'ai-security-scanner' ),
					'fixRestorePlugin'   => __( 'Restore Official Plugin File', 'ai-security-scanner' ),
					'fixRestoreBaseline' => __( 'Restore from Baseline', 'ai-security-scanner' ),
					'fixQuarantine'      => __( 'Quarantine (Delete File)', 'ai-security-scanner' ),
					/* translators: %s: file path */
					'confirmRestore'     => __( 'This will overwrite %s on disk with a trusted copy. The current content will be backed up first and can be undone from the Remediation Log. Continue?', 'ai-security-scanner' ),
					/* translators: %s: file path */
					'confirmQuarantine'  => __( 'This will DELETE %s from disk. A backup will be kept and this can be undone from the Remediation Log. Continue?', 'ai-security-scanner' ),
					'confirmLockEnable'  => __( "This will make every baseline file read-only on disk, and automatically revert any file that's changed anyway. It will also block WordPress core/plugin/theme updates (automatic and manual) until you turn this off again. Continue?", 'ai-security-scanner' ),
					'confirmLockDisable' => __( 'This will restore normal write permissions on all baseline files and stop the watchdog. Continue?', 'ai-security-scanner' ),
					'lockWorking'        => __( 'Working…', 'ai-security-scanner' ),
				),
			)
		);
	}

	private static function render_view( $view, array $data = array() ) {
		if ( ! current_user_can( self::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'ai-security-scanner' ) );
		}

		extract( $data ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract
		include AISS_PLUGIN_DIR . 'admin/views/' . $view . '.php';
	}

	public static function render_dashboard() {
		global $wpdb;

		$latest_scan   = AISS_Scanner::get_latest_completed_scan();
		$active_scan   = AISS_Scanner::get_active_scan();
		$baseline_count = AISS_Baseline::count();
		$baseline_time  = AISS_Baseline::last_updated();

		self::render_view(
			'dashboard',
			array(
				'latest_scan'    => $latest_scan,
				'active_scan'    => $active_scan,
				'baseline_count' => $baseline_count,
				'baseline_time'  => $baseline_time,
			)
		);
	}

	public static function render_full_scan() {
		$active_scan = AISS_Scanner::get_active_scan();
		$latest_scan = AISS_Scanner::get_latest_completed_scan();

		self::render_view(
			'full-scan',
			array(
				'active_scan' => $active_scan,
				'latest_scan' => $latest_scan,
			)
		);
	}

	private static function render_findings_page( $view, $risk_filter = null, $change_filter = null ) {
		global $wpdb;

		$latest_scan = AISS_Scanner::get_latest_completed_scan();
		$findings    = array();
		$scan_files  = array();

		$paged    = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$per_page = 25;
		$total    = 0;

		if ( $latest_scan ) {
			if ( null !== $change_filter ) {
				$files_table = AISS_Database::table_scan_files();
				$total       = (int) $wpdb->get_var(
					$wpdb->prepare( "SELECT COUNT(*) FROM {$files_table} WHERE scan_id = %d AND change_status = %s", $latest_scan->id, $change_filter ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				);
				$scan_files = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT * FROM {$files_table} WHERE scan_id = %d AND change_status = %s ORDER BY risk_score DESC, file_path ASC LIMIT %d OFFSET %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
						$latest_scan->id,
						$change_filter,
						$per_page,
						( $paged - 1 ) * $per_page
					)
				);
			} else {
				$table = AISS_Database::table_findings();
				$where = $wpdb->prepare( 'scan_id = %d', $latest_scan->id );
				if ( null !== $risk_filter ) {
					$where .= $wpdb->prepare( ' AND risk_level = %s', $risk_filter );
				}
				$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE {$where}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$findings = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT * FROM {$table} WHERE {$where} ORDER BY risk_score DESC, file_path ASC LIMIT %d OFFSET %d", // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
						$per_page,
						( $paged - 1 ) * $per_page
					)
				);
			}
		}

		self::render_view(
			$view,
			array(
				'latest_scan' => $latest_scan,
				'findings'    => $findings,
				'scan_files'  => $scan_files,
				'paged'       => $paged,
				'per_page'    => $per_page,
				'total'       => $total,
				'fix_enabled' => AISS_Remediation::is_enabled(),
			)
		);
	}

	public static function render_suspicious_files() {
		self::render_findings_page( 'suspicious-files', null );
	}

	public static function render_modified_files() {
		self::render_findings_page( 'modified-files', null, 'modified' );
	}

	public static function render_new_files() {
		self::render_findings_page( 'new-files', null, 'new' );
	}

	public static function render_core_integrity() {
		self::render_view( 'core-integrity', array( 'fix_enabled' => AISS_Remediation::is_enabled() ) );
	}

	public static function render_scan_history() {
		global $wpdb;

		$table = AISS_Database::table_scan_history();
		$paged    = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$per_page = 20;

		$total  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$scans  = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d OFFSET %d", $per_page, ( $paged - 1 ) * $per_page ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);

		self::render_view(
			'scan-history',
			array(
				'scans'    => $scans,
				'paged'    => $paged,
				'per_page' => $per_page,
				'total'    => $total,
			)
		);
	}

	public static function render_remediation_log() {
		self::render_view(
			'remediation-log',
			array(
				'fix_enabled' => AISS_Remediation::is_enabled(),
				'log'         => AISS_Remediation::get_log( 100 ),
			)
		);
	}

	/**
	 * Shared tab navigation printed at the top of every admin page.
	 */
	public static function print_nav_tabs( $active_slug ) {
		$tabs = array(
			''                 => __( 'Dashboard', 'ai-security-scanner' ),
			'-full-scan'       => __( 'Full Scan', 'ai-security-scanner' ),
			'-suspicious-files' => __( 'Suspicious Files', 'ai-security-scanner' ),
			'-modified-files'  => __( 'Modified Files', 'ai-security-scanner' ),
			'-new-files'       => __( 'New Files', 'ai-security-scanner' ),
			'-core-integrity'  => __( 'Core Integrity', 'ai-security-scanner' ),
			'-scan-history'    => __( 'Scan History', 'ai-security-scanner' ),
			'-remediation-log' => __( 'Remediation Log', 'ai-security-scanner' ),
			'-settings'        => __( 'Settings', 'ai-security-scanner' ),
		);

		echo '<h2 class="nav-tab-wrapper aiss-nav-tabs">';
		foreach ( $tabs as $suffix => $label ) {
			$page  = self::MENU_SLUG . $suffix;
			$class = ( $active_slug === $suffix ) ? 'nav-tab nav-tab-active' : 'nav-tab';
			printf(
				'<a href="%1$s" class="%2$s">%3$s</a>',
				esc_url( admin_url( 'admin.php?page=' . $page ) ),
				esc_attr( $class ),
				esc_html( $label )
			);
		}
		echo '</h2>';
	}

	public static function risk_badge( $level ) {
		$level = $level ? $level : 'informational';
		$labels = array(
			'critical'      => __( 'Critical', 'ai-security-scanner' ),
			'high'          => __( 'High', 'ai-security-scanner' ),
			'medium'        => __( 'Medium', 'ai-security-scanner' ),
			'low'           => __( 'Low', 'ai-security-scanner' ),
			'informational' => __( 'Informational', 'ai-security-scanner' ),
		);
		$label = isset( $labels[ $level ] ) ? $labels[ $level ] : ucfirst( $level );
		return sprintf( '<span class="aiss-badge aiss-badge-%1$s">%2$s</span>', esc_attr( $level ), esc_html( $label ) );
	}

	public static function pagination( $paged, $per_page, $total ) {
		$total_pages = (int) ceil( $total / $per_page );
		if ( $total_pages <= 1 ) {
			return;
		}

		echo '<div class="tablenav"><div class="tablenav-pages">';
		echo paginate_links( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			array(
				'base'      => add_query_arg( 'paged', '%#%' ),
				'format'    => '',
				'prev_text' => __( '&laquo;', 'ai-security-scanner' ),
				'next_text' => __( '&raquo;', 'ai-security-scanner' ),
				'total'     => $total_pages,
				'current'   => $paged,
			)
		);
		echo '</div></div>';
	}

	public static function render_settings() {
		$settings = AISS_Settings::get_settings();

		self::render_view(
			'settings',
			array(
				'settings'    => $settings,
				'lock_status' => AISS_Integrity_Lock::get_status(),
			)
		);
	}
}
