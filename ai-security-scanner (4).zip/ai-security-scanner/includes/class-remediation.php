<?php
/**
 * Manual, confirmation-gated file remediation.
 *
 * Unlike the rest of the plugin, these actions WRITE to the filesystem. They
 * are therefore:
 *  - off by default (Settings → "Enable Fix Actions" must be turned on),
 *  - never triggered automatically by a scan — only by an explicit admin
 *    click plus a confirmation dialog,
 *  - always preceded by a safety backup of whatever was on disk before the
 *    change, recorded in the aiss_backups table with an "Undo" action,
 *  - restricted to a known-good source of truth: the official WordPress.org
 *    core/plugin repository (checksum-verified for core) or the site's own
 *    trusted baseline snapshot — never an AI suggestion, never arbitrary
 *    content supplied by the request.
 *  - never permitted for wp-config.php, and never permitted for a path that
 *    doesn't resolve inside ABSPATH.
 *
 * @package AI_Security_Scanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AISS_Remediation {

	const MAX_BACKUP_BYTES = 20 * 1024 * 1024; // 20 MB safety cap for reading a file to back it up.

	public static function is_enabled() {
		return (bool) AISS_Settings::get( 'fix_actions_enabled', false );
	}

	/**
	 * Common preconditions for every fix action.
	 *
	 * @return string|WP_Error The validated absolute path, or an error.
	 */
	private static function guard( $relative_path ) {
		if ( ! self::is_enabled() ) {
			return new WP_Error( 'aiss_fix_disabled', __( 'Fix actions are disabled. Enable them under Security Scanner → Settings first.', 'ai-security-scanner' ) );
		}

		if ( 'wp-config.php' === basename( $relative_path ) ) {
			return new WP_Error( 'aiss_fix_protected', __( 'wp-config.php contains site-specific configuration (including database credentials) and cannot be auto-restored. Please review and edit it manually.', 'ai-security-scanner' ) );
		}

		$absolute_path = AISS_File_Scanner::to_absolute_path( $relative_path );
		if ( false === $absolute_path ) {
			return new WP_Error( 'aiss_fix_invalid_path', __( 'Invalid file path.', 'ai-security-scanner' ) );
		}

		return $absolute_path;
	}

	/**
	 * Back up whatever is currently on disk (if anything), then write new
	 * content. Returns the new backup row ID, or WP_Error if anything about
	 * the write can't be done safely.
	 */
	private static function backup_and_write( $relative_path, $absolute_path, $new_content, $action, $source ) {
		global $wpdb;

		$existed  = is_file( $absolute_path );
		$original = null;

		if ( $existed ) {
			$original = AISS_File_Scanner::read_file_capped( $absolute_path, self::MAX_BACKUP_BYTES );
			if ( null === $original ) {
				return new WP_Error( 'aiss_fix_read_failed', __( 'Could not read the current file to create a safety backup, so the fix was cancelled to avoid unrecoverable data loss.', 'ai-security-scanner' ) );
			}
		}

		$dir = dirname( $absolute_path );
		if ( ! is_dir( $dir ) || ! wp_is_writable( $dir ) ) {
			return new WP_Error( 'aiss_fix_not_writable', __( 'The containing directory is not writable by PHP on this server.', 'ai-security-scanner' ) );
		}

		// If File Lock Protection made this file read-only, temporarily lift
		// that for the write and re-apply it afterward, rather than failing.
		$written = AISS_Integrity_Lock::with_unlocked(
			$absolute_path,
			function () use ( $absolute_path, $new_content ) {
				return @file_put_contents( $absolute_path, $new_content, LOCK_EX ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_read_file_put_contents
			}
		);

		if ( $existed && false === $written && ! is_writable( $absolute_path ) ) {
			return new WP_Error( 'aiss_fix_not_writable', __( 'This file is not writable by PHP on this server.', 'ai-security-scanner' ) );
		}
		if ( false === $written ) {
			return new WP_Error( 'aiss_fix_write_failed', __( 'Failed to write the file.', 'ai-security-scanner' ) );
		}

		$table = AISS_Database::table_backups();
		$wpdb->insert(
			$table,
			array(
				'file_path'            => $relative_path,
				'action'               => $action,
				'source'               => $source,
				'original_content_gz'  => null !== $original ? gzcompress( $original, 6 ) : null,
				'original_existed'     => $existed ? 1 : 0,
				'new_content_gz'       => gzcompress( $new_content, 6 ),
				'status'               => 'applied',
				'performed_by'         => get_current_user_id(),
				'created_at'           => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%d', '%s' )
		);

		return (int) $wpdb->insert_id;
	}

	/**
	 * Restore a WordPress core file from the official WordPress.org SVN
	 * mirror for the exact running version, checksum-verified before write.
	 */
	public static function restore_official_core_file( $relative_path ) {
		$absolute_path = self::guard( $relative_path );
		if ( is_wp_error( $absolute_path ) ) {
			return $absolute_path;
		}

		if ( 0 === strpos( $relative_path, 'wp-content/' ) ) {
			return new WP_Error( 'aiss_fix_not_core', __( 'This file is inside wp-content, not an official WordPress core file.', 'ai-security-scanner' ) );
		}

		$checksums = AISS_Core_Checker::get_official_checksums();
		if ( is_wp_error( $checksums ) ) {
			return $checksums;
		}
		if ( ! isset( $checksums[ $relative_path ] ) ) {
			return new WP_Error( 'aiss_fix_no_checksum', __( 'No official checksum is published for this file, so it cannot be safely auto-restored.', 'ai-security-scanner' ) );
		}

		global $wp_version;
		$url = self::build_svn_url( 'https://core.svn.wordpress.org/tags/' . rawurlencode( $wp_version ) . '/', $relative_path );

		$response = wp_remote_get( $url, array( 'timeout' => 25 ) );
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			return new WP_Error( 'aiss_fix_fetch_failed', sprintf(
				/* translators: %d: HTTP status code */
				__( 'Could not download the official file from WordPress.org (HTTP %d).', 'ai-security-scanner' ),
				$code
			) );
		}

		$content = wp_remote_retrieve_body( $response );

		if ( ! hash_equals( (string) $checksums[ $relative_path ], md5( $content ) ) ) {
			return new WP_Error( 'aiss_fix_checksum_mismatch', __( 'The file downloaded from WordPress.org did not match the official checksum. Aborted for safety — nothing was changed.', 'ai-security-scanner' ) );
		}

		$backup_id = self::backup_and_write( $relative_path, $absolute_path, $content, 'restore_core', 'wordpress.org core ' . $wp_version );
		if ( is_wp_error( $backup_id ) ) {
			return $backup_id;
		}

		return array( 'backup_id' => $backup_id, 'bytes' => strlen( $content ) );
	}

	/**
	 * Restore a plugin file from the official WordPress.org plugin SVN
	 * repository, matching the plugin's currently-installed version tag.
	 * Only works for plugins actually hosted on wordpress.org.
	 */
	public static function restore_official_plugin_file( $relative_path ) {
		$absolute_path = self::guard( $relative_path );
		if ( is_wp_error( $absolute_path ) ) {
			return $absolute_path;
		}

		if ( ! preg_match( '#^wp-content/plugins/([^/]+)/(.+)$#', $relative_path, $matches ) ) {
			return new WP_Error( 'aiss_fix_not_plugin', __( 'This file is not inside a plugin directory.', 'ai-security-scanner' ) );
		}
		$slug       = $matches[1];
		$inner_path = $matches[2];

		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$version = null;
		foreach ( get_plugins() as $plugin_file => $plugin_data ) {
			if ( 0 === strpos( $plugin_file, $slug . '/' ) || $plugin_file === $slug . '.php' ) {
				$version = $plugin_data['Version'];
				break;
			}
		}

		if ( ! $version ) {
			return new WP_Error( 'aiss_fix_plugin_not_found', __( 'Could not determine the installed version of this plugin.', 'ai-security-scanner' ) );
		}

		$url = self::build_svn_url( 'https://plugins.svn.wordpress.org/' . rawurlencode( $slug ) . '/tags/' . rawurlencode( $version ) . '/', $inner_path );

		$response = wp_remote_get( $url, array( 'timeout' => 25 ) );
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 404 === $code ) {
			return new WP_Error( 'aiss_fix_not_in_repo', __( 'This file was not found in the official WordPress.org repository for this plugin/version — it may be a premium/custom plugin, a build artifact, or this exact version isn\'t published there. Try "Restore from Baseline" instead.', 'ai-security-scanner' ) );
		}
		if ( 200 !== $code ) {
			return new WP_Error( 'aiss_fix_fetch_failed', sprintf(
				/* translators: %d: HTTP status code */
				__( 'Could not download the official file from WordPress.org (HTTP %d).', 'ai-security-scanner' ),
				$code
			) );
		}

		$content = wp_remote_retrieve_body( $response );
		if ( '' === $content ) {
			return new WP_Error( 'aiss_fix_empty_response', __( 'The official repository returned an empty file. Aborted for safety.', 'ai-security-scanner' ) );
		}

		$backup_id = self::backup_and_write( $relative_path, $absolute_path, $content, 'restore_plugin', 'wordpress.org plugin ' . $slug . ' ' . $version );
		if ( is_wp_error( $backup_id ) ) {
			return $backup_id;
		}

		return array( 'backup_id' => $backup_id, 'bytes' => strlen( $content ) );
	}

	/**
	 * Restore a file from the site's own trusted baseline snapshot. Works
	 * for any file type (core, plugin, theme, custom) as long as a baseline
	 * with stored content exists for it.
	 */
	public static function restore_from_baseline( $relative_path ) {
		$absolute_path = self::guard( $relative_path );
		if ( is_wp_error( $absolute_path ) ) {
			return $absolute_path;
		}

		$baseline_row = AISS_Baseline::get_by_path( $relative_path );
		if ( ! $baseline_row ) {
			return new WP_Error( 'aiss_fix_no_baseline', __( 'No baseline snapshot exists for this file.', 'ai-security-scanner' ) );
		}

		$content = AISS_Baseline::get_content( $baseline_row );
		if ( null === $content ) {
			return new WP_Error( 'aiss_fix_no_baseline_content', __( 'The baseline record for this file has no stored content (it may predate this feature, or the file exceeded the size cap when the baseline was created). Re-create the baseline, or use a different restore method.', 'ai-security-scanner' ) );
		}

		$backup_id = self::backup_and_write( $relative_path, $absolute_path, $content, 'restore_baseline', 'baseline' );
		if ( is_wp_error( $backup_id ) ) {
			return $backup_id;
		}

		return array( 'backup_id' => $backup_id, 'bytes' => strlen( $content ) );
	}

	/**
	 * Quarantine a file with no trusted source to restore from (typically a
	 * brand-new file that doesn't exist in the baseline, e.g. a dropped
	 * backdoor): back up its content into the database, then delete it from
	 * disk. Fully reversible via undo().
	 */
	public static function quarantine_file( $relative_path ) {
		$absolute_path = self::guard( $relative_path );
		if ( is_wp_error( $absolute_path ) ) {
			return $absolute_path;
		}

		if ( ! is_file( $absolute_path ) ) {
			return new WP_Error( 'aiss_fix_missing', __( 'File no longer exists on disk.', 'ai-security-scanner' ) );
		}

		$content = AISS_File_Scanner::read_file_capped( $absolute_path, self::MAX_BACKUP_BYTES );
		if ( null === $content ) {
			return new WP_Error( 'aiss_fix_read_failed', __( 'Could not read the file to back it up before removal, so the fix was cancelled.', 'ai-security-scanner' ) );
		}

		if ( ! wp_is_writable( dirname( $absolute_path ) ) ) {
			return new WP_Error( 'aiss_fix_not_writable', __( 'The containing directory is not writable by PHP on this server.', 'ai-security-scanner' ) );
		}

		global $wpdb;
		$table = AISS_Database::table_backups();
		$wpdb->insert(
			$table,
			array(
				'file_path'           => $relative_path,
				'action'              => 'quarantine',
				'source'              => 'manual',
				'original_content_gz' => gzcompress( $content, 6 ),
				'original_existed'    => 1,
				'new_content_gz'      => null,
				'status'              => 'applied',
				'performed_by'        => get_current_user_id(),
				'created_at'          => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%d', '%s' )
		);
		$backup_id = (int) $wpdb->insert_id;

		if ( ! @unlink( $absolute_path ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			$wpdb->update( $table, array( 'status' => 'failed' ), array( 'id' => $backup_id ), array( '%s' ), array( '%d' ) );
			return new WP_Error( 'aiss_fix_delete_failed', __( 'Could not delete the file (check file permissions). A backup was still recorded.', 'ai-security-scanner' ) );
		}

		return array( 'backup_id' => $backup_id );
	}

	/**
	 * Reverse a previously-applied fix action, restoring exactly what was on
	 * disk beforehand (or deleting the file again, if it didn't exist yet).
	 */
	public static function undo( $backup_id ) {
		global $wpdb;

		$table = AISS_Database::table_backups();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $backup_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if ( ! $row ) {
			return new WP_Error( 'aiss_fix_backup_not_found', __( 'Backup record not found.', 'ai-security-scanner' ) );
		}
		if ( 'applied' !== $row->status ) {
			return new WP_Error( 'aiss_fix_already_undone', __( 'This action was already undone (or failed to apply).', 'ai-security-scanner' ) );
		}

		$absolute_path = AISS_File_Scanner::to_absolute_path( $row->file_path );
		if ( false === $absolute_path ) {
			return new WP_Error( 'aiss_fix_invalid_path', __( 'Invalid file path.', 'ai-security-scanner' ) );
		}

		if ( $row->original_existed ) {
			$original = null !== $row->original_content_gz ? @gzuncompress( $row->original_content_gz ) : false; // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			if ( false === $original ) {
				return new WP_Error( 'aiss_fix_backup_corrupt', __( 'The stored backup content could not be read; cannot undo automatically.', 'ai-security-scanner' ) );
			}

			$dir = dirname( $absolute_path );
			if ( ! is_dir( $dir ) ) {
				wp_mkdir_p( $dir );
			}
			if ( ! is_dir( $dir ) || ! wp_is_writable( $dir ) ) {
				return new WP_Error( 'aiss_fix_not_writable', __( 'The containing directory is not writable by PHP on this server.', 'ai-security-scanner' ) );
			}

			if ( false === @file_put_contents( $absolute_path, $original, LOCK_EX ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_read_file_put_contents
				return new WP_Error( 'aiss_fix_write_failed', __( 'Could not write the file back to disk (check permissions).', 'ai-security-scanner' ) );
			}
		} elseif ( is_file( $absolute_path ) ) {
				@unlink( $absolute_path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}

		$wpdb->update( $table, array( 'status' => 'undone', 'undone_at' => current_time( 'mysql' ) ), array( 'id' => $backup_id ), array( '%s', '%s' ), array( '%d' ) );

		return true;
	}

	public static function get_log( $limit = 50 ) {
		global $wpdb;
		$table = AISS_Database::table_backups();
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", $limit ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Build a URL by appending a '/'-separated relative path (each segment
	 * percent-encoded individually so legitimate slashes are preserved).
	 */
	private static function build_svn_url( $base, $relative_path ) {
		$segments = array_map( 'rawurlencode', explode( '/', $relative_path ) );
		return $base . implode( '/', $segments );
	}
}
