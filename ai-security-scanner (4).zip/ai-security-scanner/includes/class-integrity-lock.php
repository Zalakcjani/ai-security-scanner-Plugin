<?php
/**
 * File Lock Protection: an opt-in toggle that, while enabled, tries to make
 * it impossible for any baseline-tracked file to be changed without the
 * plugin catching and reverting it.
 *
 * Two layers, because neither is sufficient alone:
 *
 *  1. OS-level read-only permissions (chmod 0444) on every baseline file.
 *     This blocks the single most common reinfection mechanism seen in real
 *     WordPress malware: a backdoor script calling file_put_contents()/
 *     fwrite() on an EXISTING file to re-inject its payload. A read-only
 *     file simply can't be opened for writing by PHP.
 *
 *     It does NOT stop a file from being deleted and recreated (POSIX
 *     unlink() only checks the *directory's* write permission, not the
 *     file's), and it does NOT stop anything with more privileged access
 *     than the web server user (e.g. a compromised SSH/SFTP/hosting-panel
 *     account) from chmod'ing it back. Layer 2 exists for that gap.
 *
 *  2. A WP-Cron "watchdog" that periodically re-hashes baseline files. Any
 *     mismatch is treated as unauthorized and immediately reverted to the
 *     trusted baseline content, logged, and emailed to the site admin.
 *
 * Unavoidable trade-off: while this is active, WordPress core/plugin/theme
 * updates (automatic AND manual) cannot write to locked files either — this
 * plugin disables WP's own auto-updates while the lock is on so they don't
 * fail half-applied, and the admin must disable the lock before installing
 * updates, then re-run a scan + refresh the baseline + re-enable the lock.
 *
 * @package AI_Security_Scanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AISS_Integrity_Lock {

	const CRON_HOOK      = 'aiss_integrity_watchdog';
	const CRON_SCHEDULE  = 'aiss_watchdog_interval';
	const CURSOR_OPTION  = 'aiss_watchdog_cursor';
	const LAST_RUN_OPTION = 'aiss_watchdog_last_run';
	const WATCHDOG_BATCH_SIZE = 200;
	const MAX_BACKUP_BYTES = 20 * 1024 * 1024;

	public static function is_enabled() {
		return (bool) AISS_Settings::get( 'integrity_lock_enabled', false );
	}

	/**
	 * Registers the custom cron interval used by the watchdog.
	 */
	public static function register_cron_schedule( $schedules ) {
		$minutes = max( 1, min( 60, (int) AISS_Settings::get( 'watchdog_interval_minutes', 5 ) ) );

		$schedules[ self::CRON_SCHEDULE ] = array(
			'interval' => $minutes * MINUTE_IN_SECONDS,
			'display'  => sprintf(
				/* translators: %d: number of minutes */
				__( 'Every %d minutes (AI Security Scanner watchdog)', 'ai-security-scanner' ),
				$minutes
			),
		);

		return $schedules;
	}

	/**
	 * While the lock is enabled, WordPress's own update mechanisms would
	 * just fail against read-only files (or, worse, partially apply). Turn
	 * them off for the duration instead of letting that happen silently.
	 */
	public static function maybe_block_core_updates( $value ) {
		return self::is_enabled() ? false : $value;
	}

	/**
	 * Enable protection: requires an existing baseline (it's the definition
	 * of "trusted"), locks every baseline file, and schedules the watchdog.
	 *
	 * @return array|WP_Error {locked, failed, total} or an error.
	 */
	public static function enable() {
		if ( ! AISS_Baseline::exists() ) {
			return new WP_Error(
				'aiss_lock_no_baseline',
				__( 'Create a baseline first (Full Scan, or Settings → Update Baseline) before enabling File Lock Protection — the baseline is what "trusted" is measured against.', 'ai-security-scanner' )
			);
		}

		$result = self::apply_permission_to_all_baseline_files( 0444 );

		self::set_enabled_flag( true );

		update_option( self::CURSOR_OPTION, 0, false );

		self::reschedule_cron();

		return $result;
	}

	/**
	 * Disable protection: restores normal file permissions and unschedules
	 * the watchdog. Called explicitly by the admin, and automatically on
	 * plugin deactivation/uninstall so a site can never get stuck locked.
	 *
	 * @return array {locked, failed, total} (here "locked" counts files
	 *               successfully returned to a writable permission).
	 */
	public static function disable() {
		$result = self::apply_permission_to_all_baseline_files( 0644 );

		self::set_enabled_flag( false );

		wp_clear_scheduled_hook( self::CRON_HOOK );

		return $result;
	}

	private static function set_enabled_flag( $enabled ) {
		$settings = AISS_Settings::get_settings();
		$settings['integrity_lock_enabled'] = (bool) $enabled;
		update_option( AISS_Settings::OPTION_KEY, $settings, false );
	}

	public static function reschedule_cron() {
		wp_clear_scheduled_hook( self::CRON_HOOK );
		if ( self::is_enabled() ) {
			wp_schedule_event( time() + MINUTE_IN_SECONDS, self::CRON_SCHEDULE, self::CRON_HOOK );
		}
	}

	private static function apply_permission_to_all_baseline_files( $mode ) {
		global $wpdb;

		$table = AISS_Database::table_baseline();
		$paths = $wpdb->get_col( "SELECT file_path FROM {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		$locked = 0;
		$failed = 0;

		foreach ( $paths as $relative_path ) {
			$absolute = AISS_File_Scanner::to_absolute_path( $relative_path );
			if ( false === $absolute || ! is_file( $absolute ) ) {
				continue;
			}

			if ( @chmod( $absolute, $mode ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
				$locked++;
			} else {
				$failed++;
			}
		}

		return array( 'locked' => $locked, 'failed' => $failed, 'total' => count( $paths ) );
	}

	/**
	 * Temporarily restore write permission on a single file for the
	 * duration of $callback, then re-apply the read-only lock afterward
	 * (only if the lock is currently enabled). Used by both the watchdog's
	 * own auto-revert and by Fix Actions, so a manual restore still works
	 * on a locked file instead of failing with "not writable".
	 */
	public static function with_unlocked( $absolute_path, $callback ) {
		$is_locked = self::is_enabled() && is_file( $absolute_path ) && ! is_writable( $absolute_path );

		if ( $is_locked ) {
			@chmod( $absolute_path, 0644 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}

		$result = $callback();

		if ( $is_locked && file_exists( $absolute_path ) ) {
			@chmod( $absolute_path, 0444 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}

		return $result;
	}

	public static function get_status() {
		global $wpdb;
		$table = AISS_Database::table_baseline();

		$locked_count = 0;
		if ( self::is_enabled() ) {
			// Sample a small number of files rather than statting every one on
			// every page load; the watchdog's own log is the source of truth
			// for whether anything has actually slipped through.
			$sample = $wpdb->get_col( "SELECT file_path FROM {$table} ORDER BY id ASC LIMIT 200" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			foreach ( $sample as $relative_path ) {
				$absolute = AISS_File_Scanner::to_absolute_path( $relative_path );
				if ( $absolute && is_file( $absolute ) && ! is_writable( $absolute ) ) {
					$locked_count++;
				}
			}
		}

		return array(
			'enabled'          => self::is_enabled(),
			'baseline_count'   => AISS_Baseline::count(),
			'sample_locked'    => $locked_count,
			'last_run'         => get_option( self::LAST_RUN_OPTION, '' ),
			'next_run'         => wp_next_scheduled( self::CRON_HOOK ),
		);
	}

	/**
	 * Cron callback. Processes one batch of baseline files (cycling through
	 * the whole set over successive runs), and reverts + logs + alerts on
	 * any content that no longer matches the trusted snapshot.
	 */
	public static function run_watchdog() {
		if ( ! self::is_enabled() ) {
			return;
		}

		global $wpdb;
		$table = AISS_Database::table_baseline();

		$cursor = (int) get_option( self::CURSOR_OPTION, 0 );

		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id > %d ORDER BY id ASC LIMIT %d", $cursor, self::WATCHDOG_BATCH_SIZE ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);

		if ( empty( $rows ) ) {
			// Reached the end of the baseline — wrap around for continuous coverage.
			update_option( self::CURSOR_OPTION, 0, false );
			update_option( self::LAST_RUN_OPTION, current_time( 'mysql' ), false );
			return;
		}

		$reverted = array();

		foreach ( $rows as $row ) {
			$cursor = (int) $row->id;

			$absolute = AISS_File_Scanner::to_absolute_path( $row->file_path );
			if ( false === $absolute || ! is_file( $absolute ) ) {
				continue; // Deletions are surfaced by regular scans, not the watchdog.
			}

			$current_hash = AISS_File_Scanner::hash_file( $absolute );
			if ( $current_hash === $row->file_hash ) {
				continue;
			}

			$trusted_content = AISS_Baseline::get_content( $row );
			if ( null === $trusted_content ) {
				continue; // No snapshot to restore from.
			}

			$current_content = AISS_File_Scanner::read_file_capped( $absolute, self::MAX_BACKUP_BYTES );

			$written = self::with_unlocked(
				$absolute,
				function () use ( $absolute, $trusted_content ) {
					return false !== @file_put_contents( $absolute, $trusted_content, LOCK_EX ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_read_file_put_contents
				}
			);

			if ( $written ) {
				self::log_auto_revert( $row->file_path, $current_content, $trusted_content );
				$reverted[] = $row->file_path;
			}
		}

		update_option( self::CURSOR_OPTION, $cursor, false );
		update_option( self::LAST_RUN_OPTION, current_time( 'mysql' ), false );

		if ( ! empty( $reverted ) ) {
			self::notify_admin( $reverted );
		}
	}

	private static function log_auto_revert( $relative_path, $original_content, $new_content ) {
		global $wpdb;

		$table = AISS_Database::table_backups();
		$wpdb->insert(
			$table,
			array(
				'file_path'           => $relative_path,
				'action'              => 'auto_revert',
				'source'              => 'watchdog',
				'original_content_gz' => null !== $original_content ? gzcompress( $original_content, 6 ) : null,
				'original_existed'    => 1,
				'new_content_gz'      => gzcompress( $new_content, 6 ),
				'status'              => 'applied',
				'performed_by'        => 0,
				'created_at'          => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%d', '%s' )
		);
	}

	private static function notify_admin( array $reverted_files ) {
		$to      = get_option( 'admin_email' );
		$subject = sprintf(
			/* translators: 1: site name, 2: number of files */
			__( '[%1$s] AI Security Scanner auto-reverted %2$d file(s)', 'ai-security-scanner' ),
			wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			count( $reverted_files )
		);

		$body = __( "File Lock Protection detected unauthorized changes to the following file(s) and automatically restored them from your trusted baseline:", 'ai-security-scanner' ) . "\n\n"
			. implode( "\n", array_map( function ( $path ) { return ' - ' . $path; }, $reverted_files ) ) . "\n\n"
			. __( 'If you made these changes yourself (e.g. editing a file directly on the server), disable File Lock Protection before editing, then refresh the baseline. Otherwise, treat this as an active intrusion: review the Remediation Log and consider running a full scan.', 'ai-security-scanner' ) . "\n\n"
			. admin_url( 'admin.php?page=ai-security-scanner-remediation-log' );

		wp_mail( $to, $subject, $body );
	}
}
