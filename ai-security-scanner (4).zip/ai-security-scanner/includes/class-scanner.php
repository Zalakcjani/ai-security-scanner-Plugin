<?php
/**
 * Scan orchestrator: coordinates the directory-listing phase and the
 * file-analysis phase across chunked AJAX requests.
 *
 * @package AI_Security_Scanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AISS_Scanner {

	const STATUS_QUEUED   = 'queued';
	const STATUS_LISTING  = 'listing';
	const STATUS_SCANNING = 'scanning';
	const STATUS_FINALIZING = 'finalizing';
	const STATUS_COMPLETED = 'completed';
	const STATUS_CANCELLED = 'cancelled';
	const STATUS_ERROR     = 'error';

	/**
	 * If an "active" scan is older than this, it is treated as abandoned
	 * (browser closed mid-scan, crashed request, etc.) rather than resumed,
	 * so clicking "Start Full Scan" always makes forward progress instead of
	 * silently reattaching to a scan that will never finish.
	 */
	const STALE_SCAN_SECONDS = 3 * HOUR_IN_SECONDS;

	/**
	 * Start a new scan. Returns the new scan_id.
	 */
	public static function start_scan( $create_baseline = false ) {
		global $wpdb;

		// Guard against overlapping scans — but never silently resume one that
		// has been running far longer than any real scan should take; auto-cancel
		// it and start clean instead.
		$active = self::get_active_scan();
		if ( $active ) {
			$age = time() - strtotime( $active->started_at . ' UTC' );
			if ( $age < self::STALE_SCAN_SECONDS ) {
				return $active->id;
			}
			self::cancel_scan( $active->id );
		}

		$table = AISS_Database::table_scan_history();
		$wpdb->insert(
			$table,
			array(
				'status'          => self::STATUS_LISTING,
				'scan_type'       => 'full',
				'started_at'      => current_time( 'mysql' ),
				'initiated_by'    => get_current_user_id(),
				'create_baseline' => $create_baseline ? 1 : 0,
			),
			array( '%s', '%s', '%s', '%d', '%d' )
		);

		$scan_id = (int) $wpdb->insert_id;

		AISS_File_Scanner::seed_queue( $scan_id );

		return $scan_id;
	}

	public static function get_active_scan() {
		global $wpdb;
		$table = AISS_Database::table_scan_history();
		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE status IN (%s, %s, %s) ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				self::STATUS_QUEUED,
				self::STATUS_LISTING,
				self::STATUS_SCANNING
			)
		);
	}

	public static function get_scan( $scan_id ) {
		global $wpdb;
		$table = AISS_Database::table_scan_history();
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $scan_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public static function get_latest_completed_scan() {
		global $wpdb;
		$table = AISS_Database::table_scan_history();
		return $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE status = %s ORDER BY id DESC LIMIT 1", self::STATUS_COMPLETED ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);
	}

	/**
	 * Advance a scan by one unit of work: either a directory-listing batch or
	 * a file-analysis batch, whichever phase the scan is currently in.
	 *
	 * @return array Status payload for the AJAX response.
	 */
	public static function process_next_batch( $scan_id ) {
		$scan = self::get_scan( $scan_id );

		if ( ! $scan ) {
			return array( 'error' => __( 'Scan not found.', 'ai-security-scanner' ) );
		}

		if ( in_array( $scan->status, array( self::STATUS_COMPLETED, self::STATUS_CANCELLED, self::STATUS_ERROR ), true ) ) {
			return self::build_status_payload( $scan );
		}

		$settings     = AISS_Settings::get_settings();
		$new_findings = array();

		try {
			if ( self::STATUS_LISTING === $scan->status ) {
				$result = AISS_File_Scanner::process_queue_batch( $scan_id, $settings['dir_batch_size'] );

				self::increment_counters( $scan_id, array( 'total_files' => $result['files_found'] ) );

				if ( $result['done'] ) {
					self::update_scan( $scan_id, array( 'status' => self::STATUS_SCANNING ) );
				}
			} elseif ( self::STATUS_SCANNING === $scan->status ) {
				$batch_result = self::process_analysis_batch( $scan_id, $settings );
				$new_findings = $batch_result['new_findings'];

				if ( $batch_result['done'] ) {
					self::finalize_scan( $scan_id );
				}
			}
		} catch ( Exception $e ) {
			self::update_scan(
				$scan_id,
				array(
					'status'        => self::STATUS_ERROR,
					'error_message' => $e->getMessage(),
					'finished_at'   => current_time( 'mysql' ),
				)
			);
		}

		$payload                 = self::build_status_payload( self::get_scan( $scan_id ) );
		$payload['new_findings'] = $new_findings;

		return $payload;
	}

	/**
	 * A 'processing' row whose claim is older than this is assumed to belong
	 * to a request that died mid-batch (PHP fatal error, host timeout, etc.)
	 * and is safe to reclaim.
	 */
	const STALE_CLAIM_SECONDS = 120;

	/**
	 * Analyze up to $settings['batch_size'] pending files.
	 *
	 * Rows are claimed atomically (UPDATE ... LIMIT, scoped to a per-request
	 * token) before being read and processed. This prevents two overlapping
	 * requests — e.g. the Full Scan page open in two browser tabs, or a
	 * retried AJAX call — from selecting and double-counting the same
	 * "pending" rows, which previously caused files_scanned to run past
	 * total_files and the scan to appear stuck.
	 *
	 * @return array{done: bool, new_findings: array} done=true once no pending/claimed files remain.
	 */
	private static function process_analysis_batch( $scan_id, array $settings ) {
		global $wpdb;

		$files_table = AISS_Database::table_scan_files();

		// Reclaim any batch that was claimed but never finished (crashed request).
		$stale_before = gmdate( 'Y-m-d H:i:s', time() - self::STALE_CLAIM_SECONDS );
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$files_table} SET status = 'pending', claim_token = NULL, claimed_at = NULL WHERE scan_id = %d AND status = 'processing' AND claimed_at < %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$scan_id,
				$stale_before
			)
		);

		$token = wp_generate_password( 32, false, false );

		$claimed = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$files_table} SET status = 'processing', claim_token = %s, claimed_at = %s WHERE scan_id = %d AND status = 'pending' ORDER BY id ASC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$token,
				current_time( 'mysql' ),
				$scan_id,
				$settings['batch_size']
			)
		);

		if ( ! $claimed ) {
			$remaining = (int) $wpdb->get_var(
				$wpdb->prepare( "SELECT COUNT(*) FROM {$files_table} WHERE scan_id = %d AND status IN ('pending', 'processing')", $scan_id ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			);
			return array(
				'done'         => 0 === $remaining,
				'new_findings' => array(),
			);
		}

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$files_table} WHERE scan_id = %d AND claim_token = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$scan_id,
				$token
			)
		);

		$counters = array(
			'files_scanned'    => 0,
			'modified_files'   => 0,
			'new_files'        => 0,
			'suspicious_files' => 0,
			'critical_count'   => 0,
			'high_count'       => 0,
			'medium_count'     => 0,
			'low_count'        => 0,
			'info_count'       => 0,
		);

		$has_baseline = AISS_Baseline::exists();
		$new_findings = array();

		foreach ( $rows as $row ) {
			$counters['files_scanned']++;

			self::analyze_single_file( $scan_id, $row, $settings, $has_baseline, $counters, $new_findings );
		}

		self::increment_counters( $scan_id, $counters );

		$remaining = (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(*) FROM {$files_table} WHERE scan_id = %d AND status IN ('pending', 'processing')", $scan_id ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);

		return array(
			'done'         => 0 === $remaining,
			'new_findings' => $new_findings,
		);
	}

	/**
	 * @param array &$new_findings Suspicious-file summaries discovered in this
	 *                              batch are appended here so the Full Scan
	 *                              page can show them live, without waiting
	 *                              for the scan to finish.
	 */
	private static function analyze_single_file( $scan_id, $file_row, array $settings, $has_baseline, array &$counters, array &$new_findings ) {
		global $wpdb;

		$files_table    = AISS_Database::table_scan_files();
		$relative_path  = $file_row->file_path;
		$absolute_path  = AISS_File_Scanner::to_absolute_path( $relative_path );

		$update = array(
			'status' => 'scanned',
		);

		if ( false === $absolute_path || ! is_file( $absolute_path ) ) {
			$update['status']        = 'error';
			$update['error_message'] = 'File no longer exists or is outside the allowed root.';
			$wpdb->update( $files_table, $update, array( 'id' => $file_row->id ) );
			return;
		}

		$size  = @filesize( $absolute_path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		$mtime = @filemtime( $absolute_path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		$hash  = AISS_File_Scanner::hash_file( $absolute_path );

		$update['file_size']  = false !== $size ? $size : null;
		$update['file_mtime'] = $mtime ? gmdate( 'Y-m-d H:i:s', $mtime ) : null;
		$update['file_hash']  = $hash;

		// Change detection against baseline.
		$change_status = 'unchanged';
		if ( $has_baseline ) {
			$baseline_entry = AISS_Baseline::get_by_path( $relative_path );
			if ( ! $baseline_entry ) {
				$change_status = 'new';
				$counters['new_files']++;
			} elseif ( $baseline_entry->file_hash !== $hash ) {
				$change_status = 'modified';
				$counters['modified_files']++;
			}
		} else {
			$change_status = 'new';
			$counters['new_files']++;
		}
		$update['change_status'] = $change_status;

		// Content-based detection.
		$findings   = array();
		$extension  = self::get_extension_for_rules( $relative_path );
		$readable   = $size !== false && $size <= $settings['max_file_size'];

		if ( $readable ) {
			$content = AISS_File_Scanner::read_file_capped( $absolute_path, $settings['max_file_size'] );

			if ( null !== $content ) {
				$findings = array_merge( $findings, AISS_Malware_Detector::scan_content( $content, $extension ) );

				$basename = basename( $relative_path );
				if ( '.htaccess' === $basename ) {
					$findings = array_merge( $findings, AISS_Malware_Detector::check_htaccess( $content ) );
				}
				if ( 'wp-config.php' === $basename ) {
					$findings = array_merge( $findings, AISS_Malware_Detector::check_wpconfig( $content ) );
				}

				// Store a compressed snapshot so the "Compare" view has something
				// to diff against later (bounded to scannable code files under the
				// configured size cap, never the whole site).
				$update['content_gz'] = gzcompress( $content, 6 );
			}
		}

		$findings = array_merge( $findings, AISS_Malware_Detector::check_file_context( $relative_path, $extension ) );

		$risk_score = 0;
		foreach ( $findings as $finding ) {
			$risk_score += $finding['score'];
		}
		$risk_level = AISS_Malware_Detector::score_to_level( $risk_score );

		$update['risk_score'] = $risk_score;
		$update['risk_level'] = $risk_level;

		$wpdb->update( $files_table, $update, array( 'id' => $file_row->id ) );

		if ( ! empty( $findings ) ) {
			$finding_ids = self::insert_findings( $scan_id, $file_row->id, $relative_path, $findings );
			$counters['suspicious_files']++;

			// Surface the single highest-scoring finding for this file as a live
			// "just found" entry; the Suspicious Files tab has the full list.
			$top_index = 0;
			$top_score = -1;
			foreach ( $findings as $index => $finding ) {
				if ( $finding['score'] > $top_score ) {
					$top_score = $finding['score'];
					$top_index = $index;
				}
			}

			$top = $findings[ $top_index ];

			$new_findings[] = array(
				'finding_id' => isset( $finding_ids[ $top_index ] ) ? $finding_ids[ $top_index ] : 0,
				'file_path'  => $relative_path,
				'risk_level' => $risk_level,
				'risk_score' => $risk_score,
				'category'   => $top['category'],
				'reason'     => $top['description'],
			);
		}

		if ( isset( $counters[ $risk_level . '_count' ] ) ) {
			$counters[ $risk_level . '_count' ]++;
		}
	}

	private static function get_extension_for_rules( $relative_path ) {
		$basename = basename( $relative_path );
		if ( '.htaccess' === $basename ) {
			return 'htaccess';
		}
		return strtolower( pathinfo( $relative_path, PATHINFO_EXTENSION ) );
	}

	/**
	 * @return array List of inserted finding IDs, in the same order as $findings.
	 */
	private static function insert_findings( $scan_id, $scan_file_id, $relative_path, array $findings ) {
		global $wpdb;

		$table = AISS_Database::table_findings();
		$now   = current_time( 'mysql' );
		$ids   = array();

		foreach ( $findings as $finding ) {
			$wpdb->insert(
				$table,
				array(
					'scan_id'         => $scan_id,
					'scan_file_id'    => $scan_file_id,
					'file_path'       => $relative_path,
					'line_number'     => $finding['line'],
					'risk_level'      => AISS_Malware_Detector::score_to_level( $finding['score'] ),
					'risk_score'      => $finding['score'],
					'rule_id'         => $finding['rule_id'],
					'category'        => $finding['category'],
					'reason'          => $finding['description'],
					'matched_pattern' => $finding['matched'],
					'code_snippet'    => $finding['snippet'],
					'recommendation'  => $finding['recommendation'],
					'status'          => 'open',
					'created_at'      => $now,
				),
				array( '%d', '%d', '%s', '%d', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
			);

			$ids[] = (int) $wpdb->insert_id;
		}

		return $ids;
	}

	private static function finalize_scan( $scan_id ) {
		self::update_scan( $scan_id, array( 'status' => self::STATUS_FINALIZING ) );

		$deleted = AISS_Baseline::exists() ? AISS_Baseline::find_deleted_files( $scan_id ) : array();

		$scan = self::get_scan( $scan_id );

		if ( $scan && $scan->create_baseline ) {
			AISS_Baseline::rebuild_from_scan( $scan_id );
		}

		self::update_scan(
			$scan_id,
			array(
				'status'        => self::STATUS_COMPLETED,
				'finished_at'   => current_time( 'mysql' ),
				'deleted_files' => count( $deleted ),
			)
		);
	}

	public static function cancel_scan( $scan_id ) {
		self::update_scan(
			$scan_id,
			array(
				'status'      => self::STATUS_CANCELLED,
				'finished_at' => current_time( 'mysql' ),
			)
		);

		global $wpdb;
		$queue_table = AISS_Database::table_scan_queue();
		$wpdb->delete( $queue_table, array( 'scan_id' => $scan_id ), array( '%d' ) );
	}

	private static function update_scan( $scan_id, array $fields ) {
		global $wpdb;
		$table   = AISS_Database::table_scan_history();
		$formats = array();
		foreach ( $fields as $key => $value ) {
			$formats[] = is_int( $value ) ? '%d' : '%s';
		}
		$wpdb->update( $table, $fields, array( 'id' => $scan_id ), $formats, array( '%d' ) );
	}

	private static function increment_counters( $scan_id, array $counters ) {
		global $wpdb;
		$table = AISS_Database::table_scan_history();

		$sets = array();
		$args = array();
		foreach ( $counters as $key => $value ) {
			if ( ! $value ) {
				continue;
			}
			$sets[] = "{$key} = {$key} + %d";
			$args[] = $value;
		}

		if ( empty( $sets ) ) {
			return;
		}

		$args[] = $scan_id;

		$sql = "UPDATE {$table} SET " . implode( ', ', $sets ) . ' WHERE id = %d'; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( $sql, $args ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}

	private static function build_status_payload( $scan ) {
		if ( ! $scan ) {
			return array( 'error' => __( 'Scan not found.', 'ai-security-scanner' ) );
		}

		global $wpdb;
		$files_table = AISS_Database::table_scan_files();

		$current_file   = '';
		$files_remaining = 0;

		if ( in_array( $scan->status, array( self::STATUS_SCANNING, self::STATUS_FINALIZING ), true ) ) {
			$current_file = (string) $wpdb->get_var(
				$wpdb->prepare( "SELECT file_path FROM {$files_table} WHERE scan_id = %d AND status = 'scanned' ORDER BY id DESC LIMIT 1", $scan->id ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			);
			$files_remaining = (int) $wpdb->get_var(
				$wpdb->prepare( "SELECT COUNT(*) FROM {$files_table} WHERE scan_id = %d AND status IN ('pending', 'processing')", $scan->id ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			);
		}

		// Percent (and the "files processed" figure shown alongside it) is derived
		// from a live COUNT of remaining work, never from the cumulative
		// files_scanned counter. That counter is kept for historical reporting,
		// but deriving progress from it made the bar look permanently "stuck" if
		// it was ever inflated (e.g. by two overlapping requests scanning the
		// same batch) — a live remaining-count is self-correcting instead.
		$percent         = 0;
		$files_processed = 0;

		if ( self::STATUS_LISTING === $scan->status ) {
			$percent = 5; // Listing phase shown as a small fixed slice; exact totals unknown until done.
		} elseif ( in_array( $scan->status, array( self::STATUS_SCANNING, self::STATUS_FINALIZING ), true ) && $scan->total_files > 0 ) {
			$files_processed = max( 0, (int) $scan->total_files - $files_remaining );
			$percent         = min( 99, 5 + (int) round( ( $files_processed / $scan->total_files ) * 94 ) );
		} elseif ( self::STATUS_COMPLETED === $scan->status ) {
			$percent         = 100;
			$files_processed = (int) $scan->total_files;
		}

		return array(
			'scan_id'          => (int) $scan->id,
			'status'           => $scan->status,
			'percent'          => $percent,
			'total_files'      => (int) $scan->total_files,
			'files_scanned'    => $files_processed,
			'modified_files'   => (int) $scan->modified_files,
			'new_files'        => (int) $scan->new_files,
			'deleted_files'    => (int) $scan->deleted_files,
			'suspicious_files' => (int) $scan->suspicious_files,
			'critical_count'   => (int) $scan->critical_count,
			'high_count'       => (int) $scan->high_count,
			'medium_count'     => (int) $scan->medium_count,
			'low_count'        => (int) $scan->low_count,
			'info_count'       => (int) $scan->info_count,
			'current_file'     => $current_file,
			'error_message'    => $scan->error_message,
		);
	}
}
