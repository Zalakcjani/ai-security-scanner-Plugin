<?php
/**
 * Export scan reports as CSV or JSON.
 *
 * @package AI_Security_Scanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AISS_Report_Exporter {

	/**
	 * Fetch findings + summary for a scan.
	 */
	public static function get_report_data( $scan_id ) {
		global $wpdb;

		$scan = AISS_Scanner::get_scan( $scan_id );
		if ( ! $scan ) {
			return null;
		}

		$table    = AISS_Database::table_findings();
		$findings = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE scan_id = %d ORDER BY risk_score DESC, file_path ASC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$scan_id
			),
			ARRAY_A
		);

		return array(
			'summary'  => array(
				'scan_id'          => (int) $scan->id,
				'started_at'       => $scan->started_at,
				'finished_at'      => $scan->finished_at,
				'total_files'      => (int) $scan->total_files,
				'files_scanned'    => (int) $scan->files_scanned,
				'modified_files'   => (int) $scan->modified_files,
				'new_files'        => (int) $scan->new_files,
				'deleted_files'    => (int) $scan->deleted_files,
				'suspicious_files' => (int) $scan->suspicious_files,
				'critical_count'   => (int) $scan->critical_count,
				'high_count'       => (int) $scan->high_count,
				'medium_count'     => (int) $scan->medium_count,
				'low_count'        => (int) $scan->low_count,
				'info_count'       => (int) $scan->info_count,
			),
			'findings' => $findings,
		);
	}

	public static function to_json( $scan_id ) {
		$data = self::get_report_data( $scan_id );
		if ( null === $data ) {
			return null;
		}
		return wp_json_encode( $data, JSON_PRETTY_PRINT );
	}

	public static function to_csv( $scan_id ) {
		$data = self::get_report_data( $scan_id );
		if ( null === $data ) {
			return null;
		}

		$handle = fopen( 'php://temp', 'w+' );

		$columns = array( 'file_path', 'line_number', 'risk_level', 'risk_score', 'category', 'rule_id', 'reason', 'matched_pattern', 'recommendation', 'status' );
		fputcsv( $handle, $columns );

		foreach ( $data['findings'] as $row ) {
			$line = array();
			foreach ( $columns as $col ) {
				$line[] = isset( $row[ $col ] ) ? $row[ $col ] : '';
			}
			fputcsv( $handle, $line );
		}

		rewind( $handle );
		$csv = stream_get_contents( $handle );
		fclose( $handle );

		return $csv;
	}
}
