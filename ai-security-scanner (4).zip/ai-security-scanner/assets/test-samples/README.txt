TEST FIXTURES — NOT EXECUTABLE, NOT LOADED BY THE PLUGIN
==========================================================

The files in this folder are synthetic test data used only to manually verify
that the AI Security Scanner detection engine (includes/class-malware-detector.php)
correctly flags suspicious patterns.

They are NOT part of the plugin's runtime. They are:

  - saved with a ".txt" suffix so PHP/WordPress will never execute them
    (e.g. "sample-eval-base64.php.txt", not "sample-eval-base64.php")
  - not referenced by any include/require anywhere in the plugin
  - not placed inside wp-content/uploads or any web-accessible scan target
    by default — they only exist here, inside the plugin's own folder, as
    reference fixtures for manual testing

To test detection manually:

  1. Copy the contents of one of these files into a real, appropriately-named
     file (e.g. test.php) inside a disposable test WordPress installation
     that you control — never a production site.
  2. Run a Security Scanner full scan against that test installation.
  3. Confirm the expected finding(s) appear under Suspicious Files.
  4. Delete the test file afterwards.

Do not copy these into a live/production site.

Contents:
  sample-eval-base64.php.txt          -> expects: Dynamic Execution + Obfuscation findings (eval + base64_decode)
  sample-backdoor-request-exec.php.txt -> expects: CRITICAL "Remote Code Execution" finding (function called directly on $_POST/$_REQUEST)
  sample-obfuscated-js.js.txt          -> expects: JS obfuscation / iframe-injection findings
  sample-suspicious-htaccess.txt       -> expects: suspicious .htaccess rule finding (PHP handler on image extension)
  sample-clean-code.php.txt            -> expects: NO findings (uses base64_decode() legitimately on a static, non-executed value — verifies the engine does not flag a single low-weight indicator on its own)
