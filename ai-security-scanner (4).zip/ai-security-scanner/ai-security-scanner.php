<?php
/**
 * Plugin Name:       AI Security Scanner
 * Plugin URI:        https://example.com/ai-security-scanner
 * Description:       Read-only malware and suspicious-code scanner for WordPress. Scans core, plugins, themes and uploads for injected/modified code, compares against a trusted baseline, verifies core file integrity, and optionally explains findings with an AI provider you configure. Scanning and detection never modify or delete files automatically; optional, off-by-default Fix Actions and File Lock Protection features can, but only with explicit admin confirmation/opt-in.
 * Version:           1.1.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            AI Security Scanner
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ai-security-scanner
 *
 * @package AI_Security_Scanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Disallow direct access.
}

define( 'AISS_VERSION', '1.1.0' );
define( 'AISS_PLUGIN_FILE', __FILE__ );
define( 'AISS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'AISS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'AISS_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Load all plugin classes.
 */
function aiss_load_includes() {
	$includes = array(
		'includes/class-database.php',
		'includes/class-settings.php',
		'includes/class-file-scanner.php',
		'includes/class-malware-detector.php',
		'includes/class-baseline.php',
		'includes/class-diff-analyzer.php',
		'includes/class-core-checker.php',
		'includes/class-ai-analyzer.php',
		'includes/class-scanner.php',
		'includes/class-remediation.php',
		'includes/class-integrity-lock.php',
		'includes/class-report-exporter.php',
		'includes/class-admin.php',
		'includes/class-ajax.php',
	);

	foreach ( $includes as $file ) {
		require_once AISS_PLUGIN_DIR . $file;
	}
}
aiss_load_includes();

/**
 * Activation: create database tables and default settings.
 * Deliberately does not scan anything on activation — scanning is always an
 * explicit administrator action.
 */
function aiss_activate_plugin() {
	AISS_Database::install();
	AISS_Settings::maybe_set_defaults();
}
register_activation_hook( __FILE__, 'aiss_activate_plugin' );

/**
 * Deactivation: data (scan history, findings, baseline) is preserved so
 * re-activating does not lose scan history — tables are only removed via
 * uninstall.php when the plugin is deleted. File Lock Protection, however,
 * is always turned off here: a site must never be left with files stuck
 * read-only because this plugin got deactivated.
 */
function aiss_deactivate_plugin() {
	$active = AISS_Scanner::get_active_scan();
	if ( $active ) {
		AISS_Scanner::cancel_scan( $active->id );
	}

	if ( AISS_Integrity_Lock::is_enabled() ) {
		AISS_Integrity_Lock::disable();
	}
	wp_clear_scheduled_hook( AISS_Integrity_Lock::CRON_HOOK );
}
register_deactivation_hook( __FILE__, 'aiss_deactivate_plugin' );

/**
 * Bootstrap admin + AJAX + the integrity watchdog on every request.
 */
function aiss_init_plugin() {
	load_plugin_textdomain( 'ai-security-scanner', false, dirname( AISS_PLUGIN_BASENAME ) . '/languages' );

	AISS_Database::maybe_upgrade();

	add_filter( 'cron_schedules', array( 'AISS_Integrity_Lock', 'register_cron_schedule' ) ); // phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval
	add_action( AISS_Integrity_Lock::CRON_HOOK, array( 'AISS_Integrity_Lock', 'run_watchdog' ) );

	// While File Lock Protection is on, locked files can't be written to
	// anyway — stop WordPress from attempting updates against them instead
	// of letting an update fail half-applied.
	add_filter( 'auto_update_core', array( 'AISS_Integrity_Lock', 'maybe_block_core_updates' ) );
	add_filter( 'auto_update_plugin', array( 'AISS_Integrity_Lock', 'maybe_block_core_updates' ) );
	add_filter( 'auto_update_theme', array( 'AISS_Integrity_Lock', 'maybe_block_core_updates' ) );

	if ( is_admin() ) {
		AISS_Admin::init();
		AISS_Ajax::init();
	}
}
add_action( 'plugins_loaded', 'aiss_init_plugin' );
