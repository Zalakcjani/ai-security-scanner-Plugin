=== AI Security Scanner ===
Contributors: aisecurityscanner
Tags: security, malware scanner, integrity check, backdoor detection
Requires at least: 5.8
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Read-only-by-default malware and suspicious-code scanner for WordPress, with optional confirmation-gated repair and reinfection protection.

== Description ==

AI Security Scanner scans your entire WordPress installation (core, plugins, themes, uploads, and configuration files) for code patterns commonly associated with malware, backdoors, and unauthorized modifications.

**Scanning and detection are read-only.** They never delete, modify, quarantine, or "auto-fix" anything on their own. Two additional features are available, but both are off by default and require explicit opt-in plus per-action confirmation before touching any file — see below.

= Key features =

* Full-site scan with resumable, AJAX-driven chunked scanning (safe on large sites, no PHP timeouts)
* Live findings feed on the Full Scan screen — see suspicious files as they're found, no need to wait for the scan to finish
* Rule-based detection engine covering PHP and JavaScript obfuscation, dynamic code execution, remote code execution patterns, suspicious file writes, redirect injection, and known web-shell signatures
* Multi-indicator risk scoring (Critical / High / Medium / Low / Informational) — a single common function call is never treated as proof of infection
* File baseline system with SHA-256 hashing to detect new, modified, and deleted files
* WordPress core file integrity verification against official WordPress.org checksums
* Side-by-side baseline vs. current code comparison for modified files
* CSV and JSON scan report export
* Optional AI-assisted explanation of individual findings (disabled by default; you choose and configure the provider; only the specific flagged snippet is sent, never your whole site)
* **Fix Actions (off by default):** per-file, confirmation-gated restore from the official WordPress.org core/plugin repository (checksum-verified) or from your own baseline, or quarantine a file with no trusted source — every action is backed up first and reversible from the Remediation Log
* **File Lock Protection (off by default):** for active reinfection — locks baseline files read-only and runs a background watchdog that automatically reverts and alerts on any unauthorized change; disables WordPress auto-updates while active so they don't fail half-applied
* Configurable excluded directories, file extensions, batch sizes, and maximum inspected file size
* Full WordPress security best practices: capability checks, nonces, prepared statements, output escaping, and strict path validation that prevents access to anything outside the WordPress root

= What this plugin does NOT do =

* Scanning never deletes, modifies, or quarantines any file automatically
* Fix Actions and File Lock Protection never act without you first turning them on in Settings, and Fix Actions always requires an explicit per-file confirmation click
* It does not guarantee a "clean" or "infected" verdict — findings are indicators for a human to review
* It does not send your source code anywhere unless you explicitly enable and configure the optional AI analysis feature

== Installation ==

1. Upload the `ai-security-scanner` folder to `/wp-content/plugins/`.
2. Activate the plugin through the "Plugins" screen in WordPress.
3. Go to **Security Scanner → Full Scan** and click **Start Full Scan**.
4. After the first scan, consider creating a baseline (checkbox on the Full Scan screen, or the button under **Settings → Baseline**) so future scans can detect new and modified files.

== Frequently Asked Questions ==

= Will this plugin fix problems it finds? =

No. It is intentionally read-only. Every finding includes a recommended action for you (or your developer/host) to review and apply manually.

= Does this scanner require an AI API key? =

No. All detection is done by the built-in rule engine. AI analysis is an optional, additional explanation layer you can enable in Settings.

= Will scanning slow down or time out my site? =

Scanning runs in small AJAX batches (configurable in Settings), so it is safe for large sites and does not hold a single long-running PHP process.

== Changelog ==

= 1.1.0 =
* Add Fix Actions: off-by-default, confirmation-gated per-file restore (official core/plugin repository or baseline) and quarantine, each backed up and undoable from a new Remediation Log.
* Add File Lock Protection: off-by-default read-only file lock plus a background watchdog that auto-reverts unauthorized changes, for sites experiencing active reinfection.
* Add a live findings feed to the Full Scan screen.
* Fix a race condition where overlapping scan requests (e.g. the Full Scan page open in two tabs) could double-count files and make progress appear stuck.
* Make scan progress immune to counter drift by deriving it from a live count of remaining work instead of a cumulative counter.
* Raise default batch sizes for faster scans.

= 1.0.0 =
* Initial release.
