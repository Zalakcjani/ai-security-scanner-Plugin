<?php
/**
 * Full Scan view: start a scan and watch chunked AJAX progress.
 *
 * @package AI_Security_Scanner
 * @var object|null $active_scan
 * @var object|null $latest_scan
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap aiss-wrap">
	<h1><?php esc_html_e( 'Security Scanner', 'ai-security-scanner' ); ?></h1>
	<?php AISS_Admin::print_nav_tabs( '-full-scan' ); ?>

	<div id="aiss-scan-panel" data-scan-id="<?php echo esc_attr( $active_scan ? $active_scan->id : 0 ); ?>" data-status="<?php echo esc_attr( $active_scan ? $active_scan->status : '' ); ?>">

		<div id="aiss-scan-idle" class="aiss-box" <?php echo $active_scan ? 'style="display:none;"' : ''; ?>>
			<p><?php esc_html_e( 'This will scan every PHP, JavaScript, HTML, CSS, and configuration file in this WordPress installation for suspicious or modified code. Scanning is entirely read-only — no files will be changed, moved, or deleted.', 'ai-security-scanner' ); ?></p>

			<label class="aiss-checkbox-row">
				<input type="checkbox" id="aiss-create-baseline" value="1" />
				<?php esc_html_e( 'Set the results of this scan as the new trusted baseline when it completes', 'ai-security-scanner' ); ?>
			</label>

			<p>
				<button type="button" id="aiss-start-scan" class="button button-primary button-hero">
					<?php esc_html_e( 'Start Full Scan', 'ai-security-scanner' ); ?>
				</button>
			</p>
		</div>

		<div id="aiss-scan-running" class="aiss-box" <?php echo $active_scan ? '' : 'style="display:none;"'; ?>>
			<p id="aiss-scan-phase-label"><?php esc_html_e( 'Scanning…', 'ai-security-scanner' ); ?></p>

			<div class="aiss-progress-bar-outer">
				<div id="aiss-progress-bar" class="aiss-progress-bar-inner" style="width:0%;"></div>
			</div>
			<p class="aiss-progress-text">
				<span id="aiss-progress-percent">0%</span> —
				<?php esc_html_e( 'Files scanned:', 'ai-security-scanner' ); ?>
				<span id="aiss-files-scanned">0</span> / <span id="aiss-files-total">0</span>
			</p>
			<p class="aiss-current-file">
				<?php esc_html_e( 'Current file:', 'ai-security-scanner' ); ?>
				<code id="aiss-current-file-name"></code>
			</p>

			<div class="aiss-live-counters">
				<span><?php esc_html_e( 'Modified', 'ai-security-scanner' ); ?>: <strong id="aiss-live-modified">0</strong></span>
				<span><?php esc_html_e( 'New', 'ai-security-scanner' ); ?>: <strong id="aiss-live-new">0</strong></span>
				<span><?php esc_html_e( 'Suspicious', 'ai-security-scanner' ); ?>: <strong id="aiss-live-suspicious">0</strong></span>
				<span class="aiss-risk-critical"><?php esc_html_e( 'Critical', 'ai-security-scanner' ); ?>: <strong id="aiss-live-critical">0</strong></span>
				<span class="aiss-risk-high"><?php esc_html_e( 'High', 'ai-security-scanner' ); ?>: <strong id="aiss-live-high">0</strong></span>
			</div>

			<p>
				<button type="button" id="aiss-cancel-scan" class="button"><?php esc_html_e( 'Cancel Scan', 'ai-security-scanner' ); ?></button>
			</p>
		</div>

		<div id="aiss-live-findings-box" class="aiss-box" style="display:none;">
			<h2><?php esc_html_e( 'Suspicious Files Found So Far', 'ai-security-scanner' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Updated live as the scan runs — you do not need to wait for it to finish to start reviewing findings. Each entry is a file\'s highest-risk finding; the Suspicious Files tab has the complete list.', 'ai-security-scanner' ); ?></p>
			<table class="widefat striped aiss-findings-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Risk', 'ai-security-scanner' ); ?></th>
						<th><?php esc_html_e( 'File', 'ai-security-scanner' ); ?></th>
						<th><?php esc_html_e( 'Category', 'ai-security-scanner' ); ?></th>
						<th><?php esc_html_e( 'Reason', 'ai-security-scanner' ); ?></th>
						<th><?php esc_html_e( 'Actions', 'ai-security-scanner' ); ?></th>
					</tr>
				</thead>
				<tbody id="aiss-live-findings-list"></tbody>
			</table>
		</div>

		<div id="aiss-scan-complete" class="aiss-box" style="display:none;">
			<p class="aiss-scan-complete-message">
				<span class="dashicons dashicons-yes-alt"></span>
				<?php esc_html_e( 'Scan complete.', 'ai-security-scanner' ); ?>
			</p>
			<p>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=ai-security-scanner-suspicious-files' ) ); ?>" class="button button-primary"><?php esc_html_e( 'View Suspicious Files', 'ai-security-scanner' ); ?></a>
				<button type="button" id="aiss-scan-again" class="button"><?php esc_html_e( 'Run Another Scan', 'ai-security-scanner' ); ?></button>
			</p>
		</div>

		<div id="aiss-scan-error" class="aiss-box notice notice-error" style="display:none;">
			<p id="aiss-scan-error-message"></p>
		</div>
	</div>

	<?php if ( $latest_scan ) : ?>
		<h2><?php esc_html_e( 'Last Completed Scan', 'ai-security-scanner' ); ?></h2>
		<table class="widefat striped aiss-summary-table">
			<tbody>
				<tr><th><?php esc_html_e( 'Finished', 'ai-security-scanner' ); ?></th><td><?php echo esc_html( get_date_from_gmt( $latest_scan->finished_at, 'Y-m-d H:i:s' ) ); ?></td></tr>
				<tr><th><?php esc_html_e( 'Files Scanned', 'ai-security-scanner' ); ?></th><td><?php echo esc_html( number_format_i18n( $latest_scan->files_scanned ) ); ?></td></tr>
				<tr><th><?php esc_html_e( 'Suspicious Files', 'ai-security-scanner' ); ?></th><td><?php echo esc_html( number_format_i18n( $latest_scan->suspicious_files ) ); ?></td></tr>
			</tbody>
		</table>
		<p>
			<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-ajax.php?action=aiss_export_report&format=csv&scan_id=' . $latest_scan->id ), 'aiss_export_report' ) ); ?>"><?php esc_html_e( 'Export CSV', 'ai-security-scanner' ); ?></a>
			<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-ajax.php?action=aiss_export_report&format=json&scan_id=' . $latest_scan->id ), 'aiss_export_report' ) ); ?>"><?php esc_html_e( 'Export JSON', 'ai-security-scanner' ); ?></a>
		</p>
	<?php endif; ?>
</div>

<?php require AISS_PLUGIN_DIR . 'admin/views/partial-modals.php'; ?>
