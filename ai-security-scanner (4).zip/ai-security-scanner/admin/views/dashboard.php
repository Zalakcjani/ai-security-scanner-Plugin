<?php
/**
 * Dashboard view.
 *
 * @package AI_Security_Scanner
 * @var object|null $latest_scan
 * @var object|null $active_scan
 * @var int         $baseline_count
 * @var string|null $baseline_time
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap aiss-wrap">
	<h1><?php esc_html_e( 'Security Scanner', 'ai-security-scanner' ); ?></h1>
	<?php AISS_Admin::print_nav_tabs( '' ); ?>

	<?php if ( $active_scan ) : ?>
		<div class="notice notice-info">
			<p>
				<?php esc_html_e( 'A scan is currently in progress.', 'ai-security-scanner' ); ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=ai-security-scanner-full-scan' ) ); ?>"><?php esc_html_e( 'View progress', 'ai-security-scanner' ); ?></a>
			</p>
		</div>
	<?php endif; ?>

	<div class="aiss-cards">
		<div class="aiss-card">
			<span class="aiss-card-label"><?php esc_html_e( 'Last Scan', 'ai-security-scanner' ); ?></span>
			<span class="aiss-card-value aiss-card-value-small">
				<?php echo $latest_scan ? esc_html( get_date_from_gmt( $latest_scan->finished_at, 'Y-m-d H:i' ) ) : esc_html__( 'Never', 'ai-security-scanner' ); ?>
			</span>
		</div>
		<div class="aiss-card">
			<span class="aiss-card-label"><?php esc_html_e( 'Files Scanned', 'ai-security-scanner' ); ?></span>
			<span class="aiss-card-value"><?php echo esc_html( $latest_scan ? number_format_i18n( $latest_scan->files_scanned ) : '0' ); ?></span>
		</div>
		<div class="aiss-card">
			<span class="aiss-card-label"><?php esc_html_e( 'Modified', 'ai-security-scanner' ); ?></span>
			<span class="aiss-card-value"><?php echo esc_html( $latest_scan ? number_format_i18n( $latest_scan->modified_files ) : '0' ); ?></span>
		</div>
		<div class="aiss-card">
			<span class="aiss-card-label"><?php esc_html_e( 'New', 'ai-security-scanner' ); ?></span>
			<span class="aiss-card-value"><?php echo esc_html( $latest_scan ? number_format_i18n( $latest_scan->new_files ) : '0' ); ?></span>
		</div>
		<div class="aiss-card">
			<span class="aiss-card-label"><?php esc_html_e( 'Suspicious', 'ai-security-scanner' ); ?></span>
			<span class="aiss-card-value"><?php echo esc_html( $latest_scan ? number_format_i18n( $latest_scan->suspicious_files ) : '0' ); ?></span>
		</div>
	</div>

	<div class="aiss-cards aiss-cards-risk">
		<div class="aiss-card aiss-risk-critical">
			<span class="aiss-card-label"><?php esc_html_e( 'Critical', 'ai-security-scanner' ); ?></span>
			<span class="aiss-card-value"><?php echo esc_html( $latest_scan ? number_format_i18n( $latest_scan->critical_count ) : '0' ); ?></span>
		</div>
		<div class="aiss-card aiss-risk-high">
			<span class="aiss-card-label"><?php esc_html_e( 'High', 'ai-security-scanner' ); ?></span>
			<span class="aiss-card-value"><?php echo esc_html( $latest_scan ? number_format_i18n( $latest_scan->high_count ) : '0' ); ?></span>
		</div>
		<div class="aiss-card aiss-risk-medium">
			<span class="aiss-card-label"><?php esc_html_e( 'Medium', 'ai-security-scanner' ); ?></span>
			<span class="aiss-card-value"><?php echo esc_html( $latest_scan ? number_format_i18n( $latest_scan->medium_count ) : '0' ); ?></span>
		</div>
		<div class="aiss-card aiss-risk-low">
			<span class="aiss-card-label"><?php esc_html_e( 'Low', 'ai-security-scanner' ); ?></span>
			<span class="aiss-card-value"><?php echo esc_html( $latest_scan ? number_format_i18n( $latest_scan->low_count ) : '0' ); ?></span>
		</div>
	</div>

	<p class="aiss-baseline-status">
		<?php if ( $baseline_count > 0 ) : ?>
			<?php
			printf(
				/* translators: 1: number of files in baseline, 2: date */
				esc_html__( 'Baseline: %1$s files, last updated %2$s.', 'ai-security-scanner' ),
				esc_html( number_format_i18n( $baseline_count ) ),
				esc_html( $baseline_time ? get_date_from_gmt( $baseline_time, 'Y-m-d H:i' ) : '—' )
			);
			?>
		<?php else : ?>
			<?php esc_html_e( 'No baseline has been created yet. Run a full scan and create a baseline to enable change detection.', 'ai-security-scanner' ); ?>
		<?php endif; ?>
	</p>

	<p>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=ai-security-scanner-full-scan' ) ); ?>" class="button button-primary button-hero">
			<?php esc_html_e( 'Start Full Scan', 'ai-security-scanner' ); ?>
		</a>
	</p>
</div>
