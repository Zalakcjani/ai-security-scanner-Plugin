<?php
/**
 * Remediation Log view: history of confirmation-gated fix actions, each
 * reversible via Undo.
 *
 * @package AI_Security_Scanner
 * @var bool  $fix_enabled
 * @var array $log
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$action_labels = array(
	'restore_core'     => __( 'Restore official core file', 'ai-security-scanner' ),
	'restore_plugin'   => __( 'Restore official plugin file', 'ai-security-scanner' ),
	'restore_baseline' => __( 'Restore from baseline', 'ai-security-scanner' ),
	'quarantine'       => __( 'Quarantine (removed)', 'ai-security-scanner' ),
	'auto_revert'      => __( 'Auto-reverted by File Lock watchdog', 'ai-security-scanner' ),
);
?>
<div class="wrap aiss-wrap">
	<h1><?php esc_html_e( 'Security Scanner', 'ai-security-scanner' ); ?></h1>
	<?php AISS_Admin::print_nav_tabs( '-remediation-log' ); ?>

	<p><?php esc_html_e( 'Every fix action taken from this plugin is recorded here with a full backup of what was on disk beforehand. Any entry can be undone.', 'ai-security-scanner' ); ?></p>

	<?php if ( ! $fix_enabled ) : ?>
		<div class="notice notice-info"><p>
			<?php
			printf(
				/* translators: %s: link to Settings page */
				wp_kses( __( 'Fix actions are currently disabled. Enable them under <a href="%s">Settings</a> to use the "Restore" and "Quarantine" buttons on the Suspicious/Modified/Core Integrity pages.', 'ai-security-scanner' ), array( 'a' => array( 'href' => array() ) ) ),
				esc_url( admin_url( 'admin.php?page=ai-security-scanner-settings' ) )
			);
			?>
		</p></div>
	<?php endif; ?>

	<table class="widefat striped">
		<thead>
			<tr>
				<th><?php esc_html_e( 'When', 'ai-security-scanner' ); ?></th>
				<th><?php esc_html_e( 'File', 'ai-security-scanner' ); ?></th>
				<th><?php esc_html_e( 'Action', 'ai-security-scanner' ); ?></th>
				<th><?php esc_html_e( 'Source', 'ai-security-scanner' ); ?></th>
				<th><?php esc_html_e( 'By', 'ai-security-scanner' ); ?></th>
				<th><?php esc_html_e( 'Status', 'ai-security-scanner' ); ?></th>
				<th><?php esc_html_e( 'Actions', 'ai-security-scanner' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php if ( empty( $log ) ) : ?>
				<tr><td colspan="7"><?php esc_html_e( 'No fix actions have been taken yet.', 'ai-security-scanner' ); ?></td></tr>
			<?php else : ?>
				<?php foreach ( $log as $entry ) : ?>
					<?php $user = $entry->performed_by ? get_userdata( $entry->performed_by ) : false; ?>
					<tr>
						<td><?php echo esc_html( $entry->created_at ); ?></td>
						<td><code><?php echo esc_html( $entry->file_path ); ?></code></td>
						<td><?php echo esc_html( isset( $action_labels[ $entry->action ] ) ? $action_labels[ $entry->action ] : $entry->action ); ?></td>
						<td><?php echo esc_html( $entry->source ); ?></td>
						<td>
							<?php if ( $user ) : ?>
								<?php echo esc_html( $user->user_login ); ?>
							<?php elseif ( 'watchdog' === $entry->source ) : ?>
								<?php esc_html_e( 'Watchdog (automatic)', 'ai-security-scanner' ); ?>
							<?php else : ?>
								&mdash;
							<?php endif; ?>
						</td>
						<td>
							<?php if ( 'applied' === $entry->status ) : ?>
								<?php esc_html_e( 'Applied', 'ai-security-scanner' ); ?>
							<?php elseif ( 'undone' === $entry->status ) : ?>
								<?php esc_html_e( 'Undone', 'ai-security-scanner' ); ?> (<?php echo esc_html( $entry->undone_at ); ?>)
							<?php else : ?>
								<?php esc_html_e( 'Failed', 'ai-security-scanner' ); ?>
							<?php endif; ?>
						</td>
						<td>
							<?php if ( 'applied' === $entry->status ) : ?>
								<button type="button" class="button button-small aiss-undo-fix" data-backup-id="<?php echo esc_attr( $entry->id ); ?>"><?php esc_html_e( 'Undo', 'ai-security-scanner' ); ?></button>
							<?php else : ?>
								&mdash;
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
		</tbody>
	</table>
</div>
