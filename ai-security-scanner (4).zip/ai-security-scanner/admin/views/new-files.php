<?php
/**
 * New Files view: files present now but absent from the baseline.
 *
 * @package AI_Security_Scanner
 * @var object|null $latest_scan
 * @var array       $scan_files
 * @var int         $paged
 * @var int         $per_page
 * @var int         $total
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap aiss-wrap">
	<h1><?php esc_html_e( 'Security Scanner', 'ai-security-scanner' ); ?></h1>
	<?php AISS_Admin::print_nav_tabs( '-new-files' ); ?>

	<?php if ( ! $latest_scan ) : ?>
		<div class="notice notice-warning"><p><?php esc_html_e( 'No completed scan yet. Run a full scan first.', 'ai-security-scanner' ); ?></p></div>
	<?php else : ?>

		<p><?php esc_html_e( 'Files found on disk that are not present in the baseline. If no baseline exists, every scanned file is listed here.', 'ai-security-scanner' ); ?></p>

		<table class="widefat striped aiss-findings-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Risk', 'ai-security-scanner' ); ?></th>
					<th><?php esc_html_e( 'File', 'ai-security-scanner' ); ?></th>
					<th><?php esc_html_e( 'Size', 'ai-security-scanner' ); ?></th>
					<th><?php esc_html_e( 'Added / Modified', 'ai-security-scanner' ); ?></th>
					<?php if ( ! empty( $fix_enabled ) ) : ?><th><?php esc_html_e( 'Actions', 'ai-security-scanner' ); ?></th><?php endif; ?>
				</tr>
			</thead>
			<tbody>
				<?php if ( empty( $scan_files ) ) : ?>
					<tr><td colspan="5"><?php esc_html_e( 'No new files in the latest scan.', 'ai-security-scanner' ); ?></td></tr>
				<?php else : ?>
					<?php foreach ( $scan_files as $file ) : ?>
						<tr>
							<td><?php echo AISS_Admin::risk_badge( $file->risk_level ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
							<td><code><?php echo esc_html( $file->file_path ); ?></code></td>
							<td><?php echo esc_html( size_format( (int) $file->file_size ) ); ?></td>
							<td><?php echo esc_html( $file->file_mtime ); ?></td>
							<?php if ( ! empty( $fix_enabled ) ) : ?>
								<td class="aiss-actions">
									<button type="button" class="button button-small aiss-open-fix" data-file-path="<?php echo esc_attr( $file->file_path ); ?>"><?php esc_html_e( 'Fix…', 'ai-security-scanner' ); ?></button>
								</td>
							<?php endif; ?>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>
		<p class="description"><?php esc_html_e( 'Any detected suspicious code in these files also appears on the Suspicious Files tab with full details.', 'ai-security-scanner' ); ?></p>

		<?php AISS_Admin::pagination( $paged, $per_page, $total ); ?>

	<?php endif; ?>
</div>

<?php require AISS_PLUGIN_DIR . 'admin/views/partial-modals.php'; ?>
