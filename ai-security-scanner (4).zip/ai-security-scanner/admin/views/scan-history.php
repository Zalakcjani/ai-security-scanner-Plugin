<?php
/**
 * Scan History view.
 *
 * @package AI_Security_Scanner
 * @var array $scans
 * @var int   $paged
 * @var int   $per_page
 * @var int   $total
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap aiss-wrap">
	<h1><?php esc_html_e( 'Security Scanner', 'ai-security-scanner' ); ?></h1>
	<?php AISS_Admin::print_nav_tabs( '-scan-history' ); ?>

	<table class="widefat striped">
		<thead>
			<tr>
				<th><?php esc_html_e( 'ID', 'ai-security-scanner' ); ?></th>
				<th><?php esc_html_e( 'Status', 'ai-security-scanner' ); ?></th>
				<th><?php esc_html_e( 'Started', 'ai-security-scanner' ); ?></th>
				<th><?php esc_html_e( 'Finished', 'ai-security-scanner' ); ?></th>
				<th><?php esc_html_e( 'Files Scanned', 'ai-security-scanner' ); ?></th>
				<th><?php esc_html_e( 'Suspicious', 'ai-security-scanner' ); ?></th>
				<th><?php esc_html_e( 'Critical', 'ai-security-scanner' ); ?></th>
				<th><?php esc_html_e( 'High', 'ai-security-scanner' ); ?></th>
				<th><?php esc_html_e( 'Baseline Set', 'ai-security-scanner' ); ?></th>
				<th><?php esc_html_e( 'Report', 'ai-security-scanner' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php if ( empty( $scans ) ) : ?>
				<tr><td colspan="10"><?php esc_html_e( 'No scans have been run yet.', 'ai-security-scanner' ); ?></td></tr>
			<?php else : ?>
				<?php foreach ( $scans as $scan ) : ?>
					<tr>
						<td>#<?php echo esc_html( $scan->id ); ?></td>
						<td><?php echo esc_html( ucfirst( $scan->status ) ); ?></td>
						<td><?php echo esc_html( $scan->started_at ); ?></td>
						<td><?php echo esc_html( $scan->finished_at ? $scan->finished_at : '—' ); ?></td>
						<td><?php echo esc_html( number_format_i18n( $scan->files_scanned ) ); ?></td>
						<td><?php echo esc_html( number_format_i18n( $scan->suspicious_files ) ); ?></td>
						<td><?php echo esc_html( number_format_i18n( $scan->critical_count ) ); ?></td>
						<td><?php echo esc_html( number_format_i18n( $scan->high_count ) ); ?></td>
						<td><?php echo $scan->create_baseline ? esc_html__( 'Yes', 'ai-security-scanner' ) : '—'; ?></td>
						<td>
							<?php if ( 'completed' === $scan->status ) : ?>
								<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-ajax.php?action=aiss_export_report&format=csv&scan_id=' . $scan->id ), 'aiss_export_report' ) ); ?>"><?php esc_html_e( 'CSV', 'ai-security-scanner' ); ?></a>
								|
								<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-ajax.php?action=aiss_export_report&format=json&scan_id=' . $scan->id ), 'aiss_export_report' ) ); ?>"><?php esc_html_e( 'JSON', 'ai-security-scanner' ); ?></a>
							<?php else : ?>
								—
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
		</tbody>
	</table>

	<?php AISS_Admin::pagination( $paged, $per_page, $total ); ?>
</div>
