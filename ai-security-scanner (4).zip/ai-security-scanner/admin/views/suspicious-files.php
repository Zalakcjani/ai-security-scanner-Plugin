<?php
/**
 * Suspicious Files view: findings from the latest completed scan.
 *
 * @package AI_Security_Scanner
 * @var object|null $latest_scan
 * @var array       $findings
 * @var int         $paged
 * @var int         $per_page
 * @var int         $total
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap aiss-wrap">
	<h1><?php esc_html_e( 'Security Scanner', 'ai-security-scanner' ); ?></h1>
	<?php AISS_Admin::print_nav_tabs( '-suspicious-files' ); ?>

	<?php if ( ! $latest_scan ) : ?>
		<div class="notice notice-warning"><p><?php esc_html_e( 'No completed scan yet. Run a full scan first.', 'ai-security-scanner' ); ?></p></div>
	<?php else : ?>

		<p><?php esc_html_e( 'Findings are ranked by risk score. A finding is a possible indicator, not a confirmed infection — review the code before taking action.', 'ai-security-scanner' ); ?></p>

		<table class="widefat striped aiss-findings-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Risk', 'ai-security-scanner' ); ?></th>
					<th><?php esc_html_e( 'File', 'ai-security-scanner' ); ?></th>
					<th><?php esc_html_e( 'Line', 'ai-security-scanner' ); ?></th>
					<th><?php esc_html_e( 'Category', 'ai-security-scanner' ); ?></th>
					<th><?php esc_html_e( 'Reason', 'ai-security-scanner' ); ?></th>
					<th><?php esc_html_e( 'Status', 'ai-security-scanner' ); ?></th>
					<th><?php esc_html_e( 'Actions', 'ai-security-scanner' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( empty( $findings ) ) : ?>
					<tr><td colspan="7"><?php esc_html_e( 'No suspicious findings in the latest scan.', 'ai-security-scanner' ); ?></td></tr>
				<?php else : ?>
					<?php foreach ( $findings as $finding ) : ?>
						<tr class="<?php echo 'ignored' === $finding->status ? 'aiss-row-ignored' : ''; ?>">
							<td><?php echo AISS_Admin::risk_badge( $finding->risk_level ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
							<td><code><?php echo esc_html( $finding->file_path ); ?></code></td>
							<td><?php echo $finding->line_number ? esc_html( $finding->line_number ) : '&mdash;'; ?></td>
							<td><?php echo esc_html( $finding->category ); ?></td>
							<td><?php echo esc_html( wp_trim_words( $finding->reason, 14 ) ); ?></td>
							<td><?php echo esc_html( 'ignored' === $finding->status ? __( 'Ignored', 'ai-security-scanner' ) : __( 'Open', 'ai-security-scanner' ) ); ?></td>
							<td class="aiss-actions">
								<button type="button" class="button button-small aiss-view-finding" data-finding-id="<?php echo esc_attr( $finding->id ); ?>"><?php esc_html_e( 'View Code', 'ai-security-scanner' ); ?></button>
								<button type="button" class="button button-small aiss-compare-finding" data-scan-file-id="<?php echo esc_attr( $finding->scan_file_id ); ?>"><?php esc_html_e( 'Compare', 'ai-security-scanner' ); ?></button>
								<button type="button" class="button button-small aiss-ignore-finding" data-finding-id="<?php echo esc_attr( $finding->id ); ?>" data-ignored="<?php echo esc_attr( 'ignored' === $finding->status ? '0' : '1' ); ?>">
									<?php echo esc_html( 'ignored' === $finding->status ? __( 'Unignore', 'ai-security-scanner' ) : __( 'Ignore Finding', 'ai-security-scanner' ) ); ?>
								</button>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>

		<?php AISS_Admin::pagination( $paged, $per_page, $total ); ?>

	<?php endif; ?>
</div>

<?php require AISS_PLUGIN_DIR . 'admin/views/partial-modals.php'; ?>
