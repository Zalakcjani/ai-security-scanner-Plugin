<?php
/**
 * Shared modal markup for "View Code" and "Compare" actions, included by
 * the findings-related admin views. Populated client-side via AJAX.
 *
 * @package AI_Security_Scanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div id="aiss-modal-overlay" class="aiss-modal-overlay" style="display:none;">

	<div id="aiss-modal-view" class="aiss-modal" style="display:none;">
		<div class="aiss-modal-header">
			<h2><?php esc_html_e( 'Finding Detail', 'ai-security-scanner' ); ?></h2>
			<button type="button" class="aiss-modal-close">&times;</button>
		</div>
		<div class="aiss-modal-body">
			<table class="aiss-finding-meta">
				<tr><th><?php esc_html_e( 'File', 'ai-security-scanner' ); ?></th><td id="aiss-fv-file"></td></tr>
				<tr><th><?php esc_html_e( 'Risk', 'ai-security-scanner' ); ?></th><td id="aiss-fv-risk"></td></tr>
				<tr><th><?php esc_html_e( 'Line', 'ai-security-scanner' ); ?></th><td id="aiss-fv-line"></td></tr>
				<tr><th><?php esc_html_e( 'Category', 'ai-security-scanner' ); ?></th><td id="aiss-fv-category"></td></tr>
				<tr><th><?php esc_html_e( 'Detected Pattern', 'ai-security-scanner' ); ?></th><td><code id="aiss-fv-pattern"></code></td></tr>
				<tr><th><?php esc_html_e( 'Reason', 'ai-security-scanner' ); ?></th><td id="aiss-fv-reason"></td></tr>
			</table>
			<h3><?php esc_html_e( 'Code Snippet', 'ai-security-scanner' ); ?></h3>
			<pre id="aiss-fv-snippet" class="aiss-code-block"></pre>
			<h3><?php esc_html_e( 'Recommended Action', 'ai-security-scanner' ); ?></h3>
			<p id="aiss-fv-recommendation" class="aiss-recommendation"></p>

			<div id="aiss-fv-fix-section" class="aiss-fix-section" style="display:none;">
				<h3><?php esc_html_e( 'Fix This File', 'ai-security-scanner' ); ?></h3>
				<p class="description"><?php esc_html_e( 'Each action backs up the current file content first and can be undone from the Remediation Log.', 'ai-security-scanner' ); ?></p>
				<div class="aiss-fix-buttons"></div>
				<div class="aiss-fix-result" style="display:none;"></div>
			</div>

			<div id="aiss-ai-section">
				<button type="button" id="aiss-ai-analyze-btn" class="button"><?php esc_html_e( 'Ask AI to Explain', 'ai-security-scanner' ); ?></button>
				<div id="aiss-ai-result" style="display:none;">
					<h3><?php esc_html_e( 'AI Explanation', 'ai-security-scanner' ); ?></h3>
					<p><strong><?php esc_html_e( 'Confidence:', 'ai-security-scanner' ); ?></strong> <span id="aiss-ai-confidence"></span></p>
					<p id="aiss-ai-explanation"></p>
					<p><strong><?php esc_html_e( 'Suggested remediation:', 'ai-security-scanner' ); ?></strong></p>
					<p id="aiss-ai-recommendation"></p>
				</div>
				<div id="aiss-ai-error" class="notice notice-error" style="display:none;"><p></p></div>
			</div>
		</div>
	</div>

	<div id="aiss-modal-compare" class="aiss-modal aiss-modal-wide" style="display:none;">
		<div class="aiss-modal-header">
			<h2><?php esc_html_e( 'Compare: Baseline vs Current', 'ai-security-scanner' ); ?></h2>
			<button type="button" class="aiss-modal-close">&times;</button>
		</div>
		<div class="aiss-modal-body">
			<p><code id="aiss-cmp-file"></code></p>
			<div id="aiss-cmp-no-baseline" class="notice notice-warning" style="display:none;"><p><?php esc_html_e( 'No baseline snapshot is available for this file, so only the current content can be shown.', 'ai-security-scanner' ); ?></p></div>
			<pre id="aiss-cmp-diff" class="aiss-diff-block"></pre>
		</div>
	</div>

	<div id="aiss-modal-fix" class="aiss-modal" style="display:none;">
		<div class="aiss-modal-header">
			<h2><?php esc_html_e( 'Fix This File', 'ai-security-scanner' ); ?></h2>
			<button type="button" class="aiss-modal-close">&times;</button>
		</div>
		<div class="aiss-modal-body">
			<p><code id="aiss-fix-file"></code></p>
			<p class="description"><?php esc_html_e( 'Each action backs up the current file content first and can be undone from the Remediation Log.', 'ai-security-scanner' ); ?></p>
			<div class="aiss-fix-buttons"></div>
			<div class="aiss-fix-result" style="display:none;"></div>
		</div>
	</div>

</div>
