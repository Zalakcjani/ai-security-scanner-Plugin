<?php
/**
 * Modified Files view: files whose hash differs from the baseline.
 *
 * @package AI_Security_Scanner
 * @var object|null $latest_scan
 * @var array       $scan_files
 * @var int         $paged
 * @var int         $per_page
 * @var int         $total
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap aiss-wrap">
	<h1><?php esc_html_e( 'Security Scanner', 'ai-security-scanner' ); ?></h1>
	<?php AISS_Admin::print_nav_tabs( '-modified-files' ); ?>

	<?php if ( ! $latest_scan ) : ?>
		<div class="notice notice-warning"><p><?php esc_html_e( 'No completed scan yet. Run a full scan first.', 'ai-security-scanner' ); ?></p></div>
	<?php elseif ( 0 === AISS_Baseline::count() ) : ?>
		<div class="notice notice-warning"><p><?php esc_html_e( 'No baseline exists yet, so "modified" cannot be determined. Every scanned file is currently treated as new. Create a baseline from Full Scan or Settings.', 'ai-security-scanner' ); ?></p></div>
	<?php else : ?>

		<p><?php esc_html_e( 'These files exist in the baseline but their content hash has changed since it was recorded. A modification is not necessarily malicious — it may be a legitimate update. It is shown separately from "suspicious code" findings below.', 'ai-security-scanner' ); ?></p>

		<table class="widefat striped aiss-findings-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Risk', 'ai-security-scanner' ); ?></th>
					<th><?php esc_html_e( 'File', 'ai-security-scanner' ); ?></th>
					<th><?php esc_html_e( 'Size', 'ai-security-scanner' ); ?></th>
					<th><?php esc_html_e( 'Modified', 'ai-security-scanner' ); ?></th>
					<th><?php esc_html_e( 'Actions', 'ai-security-scanner' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( empty( $scan_files ) ) : ?>
					<tr><td colspan="5"><?php esc_html_e( 'No modified files in the latest scan.', 'ai-security-scanner' ); ?></td></tr>
				<?php else : ?>
					<?php foreach ( $scan_files as $file ) : ?>
						<tr>
							<td><?php echo AISS_Admin::risk_badge( $file->risk_level ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
							<td><code><?php echo esc_html( $file->file_path ); ?></code></td>
							<td><?php echo esc_html( size_format( (int) $file->file_size ) ); ?></td>
							<td><?php echo esc_html( $file->file_mtime ); ?></td>
							<td class="aiss-actions">
								<button type="button" class="button button-small aiss-compare-finding" data-scan-file-id="<?php echo esc_attr( $file->id ); ?>"><?php esc_html_e( 'Compare', 'ai-security-scanner' ); ?></button>
								<?php if ( ! empty( $fix_enabled ) ) : ?>
									<button type="button" class="button button-small aiss-open-fix" data-file-path="<?php echo esc_attr( $file->file_path ); ?>"><?php esc_html_e( 'Fix…', 'ai-security-scanner' ); ?></button>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>

		<?php AISS_Admin::pagination( $paged, $per_page, $total ); ?>

	<?php endif; ?>
</div>

<?php require AISS_PLUGIN_DIR . 'admin/views/partial-modals.php'; ?>
