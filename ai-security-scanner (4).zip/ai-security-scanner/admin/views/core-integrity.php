<?php
/**
 * Core Integrity view: compares installed core files against the official
 * WordPress.org checksums. Read-only — never repairs files automatically.
 *
 * @package AI_Security_Scanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap aiss-wrap">
	<h1><?php esc_html_e( 'Security Scanner', 'ai-security-scanner' ); ?></h1>
	<?php AISS_Admin::print_nav_tabs( '-core-integrity' ); ?>

	<p><?php esc_html_e( 'Compares your WordPress core files (wp-admin and wp-includes) against the official checksums published by WordPress.org for your exact version and language.', 'ai-security-scanner' ); ?></p>

	<p>
		<button type="button" id="aiss-check-core-btn" class="button button-primary"><?php esc_html_e( 'Check Core Integrity', 'ai-security-scanner' ); ?></button>
	</p>

	<div id="aiss-core-results" style="display:none;">
		<div id="aiss-core-summary" class="aiss-cards"></div>

		<h2><?php esc_html_e( 'Modified Core Files', 'ai-security-scanner' ); ?></h2>
		<ul id="aiss-core-modified" class="aiss-file-list"></ul>

		<h2><?php esc_html_e( 'Missing Core Files', 'ai-security-scanner' ); ?></h2>
		<ul id="aiss-core-missing" class="aiss-file-list"></ul>

		<h2><?php esc_html_e( 'Unexpected Files in Core Directories', 'ai-security-scanner' ); ?></h2>
		<ul id="aiss-core-unexpected" class="aiss-file-list"></ul>
	</div>

	<div id="aiss-core-error" class="notice notice-error" style="display:none;"><p></p></div>
</div>

<?php require AISS_PLUGIN_DIR . 'admin/views/partial-modals.php'; ?>
