<?php
/**
 * Settings view.
 *
 * @package AI_Security_Scanner
 * @var array $settings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap aiss-wrap">
	<h1><?php esc_html_e( 'Security Scanner', 'ai-security-scanner' ); ?></h1>
	<?php AISS_Admin::print_nav_tabs( '-settings' ); ?>

	<div id="aiss-settings-saved" class="notice notice-success" style="display:none;"><p><?php esc_html_e( 'Settings saved.', 'ai-security-scanner' ); ?></p></div>

	<form id="aiss-settings-form" onsubmit="return false;">

		<h2><?php esc_html_e( 'Scan Performance', 'ai-security-scanner' ); ?></h2>
		<table class="form-table">
			<tr>
				<th><label for="aiss-batch-size"><?php esc_html_e( 'File batch size', 'ai-security-scanner' ); ?></label></th>
				<td>
					<input type="number" id="aiss-batch-size" name="batch_size" min="1" max="200" value="<?php echo esc_attr( $settings['batch_size'] ); ?>" class="small-text" />
					<p class="description"><?php esc_html_e( 'Number of files analyzed per AJAX request. Lower this on slow hosting to avoid timeouts.', 'ai-security-scanner' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><label for="aiss-dir-batch-size"><?php esc_html_e( 'Directory batch size', 'ai-security-scanner' ); ?></label></th>
				<td>
					<input type="number" id="aiss-dir-batch-size" name="dir_batch_size" min="1" max="200" value="<?php echo esc_attr( $settings['dir_batch_size'] ); ?>" class="small-text" />
					<p class="description"><?php esc_html_e( 'Number of directories listed per AJAX request while building the file list.', 'ai-security-scanner' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><label for="aiss-max-file-size"><?php esc_html_e( 'Maximum file size to inspect (bytes)', 'ai-security-scanner' ); ?></label></th>
				<td>
					<input type="number" id="aiss-max-file-size" name="max_file_size" min="1024" value="<?php echo esc_attr( $settings['max_file_size'] ); ?>" class="regular-text" />
					<p class="description"><?php esc_html_e( 'Files larger than this are recorded but not opened/content-scanned.', 'ai-security-scanner' ); ?></p>
				</td>
			</tr>
		</table>

		<h2><?php esc_html_e( 'Scan Scope', 'ai-security-scanner' ); ?></h2>
		<table class="form-table">
			<tr>
				<th><label for="aiss-excluded-dirs"><?php esc_html_e( 'Excluded directories', 'ai-security-scanner' ); ?></label></th>
				<td>
					<textarea id="aiss-excluded-dirs" name="excluded_dirs" rows="6" class="large-text code"><?php echo esc_textarea( implode( "\n", $settings['excluded_dirs'] ) ); ?></textarea>
					<p class="description"><?php esc_html_e( 'One path per line, relative to the WordPress root (e.g. wp-content/cache).', 'ai-security-scanner' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><label for="aiss-allowed-extensions"><?php esc_html_e( 'File extensions to scan', 'ai-security-scanner' ); ?></label></th>
				<td>
					<input type="text" id="aiss-allowed-extensions" name="allowed_extensions" value="<?php echo esc_attr( implode( ', ', $settings['allowed_extensions'] ) ); ?>" class="large-text" />
					<p class="description"><?php esc_html_e( 'Comma-separated list, without dots.', 'ai-security-scanner' ); ?></p>
				</td>
			</tr>
		</table>

		<h2><?php esc_html_e( 'Baseline', 'ai-security-scanner' ); ?></h2>
		<table class="form-table">
			<tr>
				<th><?php esc_html_e( 'Current baseline', 'ai-security-scanner' ); ?></th>
				<td>
					<p>
						<?php
						$count = AISS_Baseline::count();
						$updated = AISS_Baseline::last_updated();
						if ( $count > 0 ) {
							printf(
								/* translators: 1: file count, 2: date */
								esc_html__( '%1$s files, last updated %2$s.', 'ai-security-scanner' ),
								esc_html( number_format_i18n( $count ) ),
								esc_html( $updated ? get_date_from_gmt( $updated, 'Y-m-d H:i' ) : '—' )
							);
						} else {
							esc_html_e( 'No baseline has been created yet.', 'ai-security-scanner' );
						}
						?>
					</p>
					<button type="button" id="aiss-update-baseline-btn" class="button"><?php esc_html_e( 'Update Baseline from Latest Scan', 'ai-security-scanner' ); ?></button>
					<span id="aiss-baseline-msg"></span>
				</td>
			</tr>
		</table>

		<h2><?php esc_html_e( 'File Lock Protection', 'ai-security-scanner' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'For when suspicious code keeps reappearing after you remove it — a sign something is actively re-injecting it. When enabled, every baseline file is made read-only on disk (blocking the most common reinfection method: a script overwriting an existing file), and a background watchdog checks every few minutes for any file that no longer matches the baseline and automatically restores it, logging the event and emailing you.', 'ai-security-scanner' ); ?>
		</p>
		<div class="notice notice-warning inline" style="margin: 0 0 12px;">
			<p>
				<?php esc_html_e( 'Trade-off: while this is on, WordPress core/plugin/theme updates (automatic and manual) cannot write to locked files either, and this plugin disables WP\'s auto-updates for the duration so they don\'t fail half-applied. To install an update: turn this off, update, run a full scan and refresh the baseline, then turn it back on. wp-config.php and files outside your baseline are not affected.', 'ai-security-scanner' ); ?>
			</p>
		</div>
		<table class="form-table">
			<tr>
				<th><?php esc_html_e( 'Status', 'ai-security-scanner' ); ?></th>
				<td>
					<p id="aiss-lock-status">
						<?php if ( $lock_status['enabled'] ) : ?>
							<strong style="color:#00a32a;"><?php esc_html_e( 'Enabled', 'ai-security-scanner' ); ?></strong>
							&mdash;
							<?php
							printf(
								/* translators: %d: number of files */
								esc_html__( '%d baseline files protected.', 'ai-security-scanner' ),
								(int) $lock_status['baseline_count']
							);
							?>
							<?php if ( $lock_status['last_run'] ) : ?>
								<?php
								printf(
									/* translators: %s: date/time */
									esc_html__( ' Watchdog last ran %s.', 'ai-security-scanner' ),
									esc_html( get_date_from_gmt( $lock_status['last_run'], 'Y-m-d H:i' ) )
								);
								?>
							<?php else : ?>
								<?php esc_html_e( ' Watchdog has not run yet — it fires on the next site visit after the schedule interval.', 'ai-security-scanner' ); ?>
							<?php endif; ?>
						<?php else : ?>
							<strong><?php esc_html_e( 'Disabled', 'ai-security-scanner' ); ?></strong>
						<?php endif; ?>
					</p>

					<?php if ( 0 === (int) $lock_status['baseline_count'] ) : ?>
						<p class="description"><?php esc_html_e( 'Create a baseline first — this feature protects exactly what the baseline contains.', 'ai-security-scanner' ); ?></p>
					<?php else : ?>
						<button type="button" id="aiss-toggle-lock-btn" class="button <?php echo $lock_status['enabled'] ? '' : 'button-primary'; ?>" data-enabled="<?php echo $lock_status['enabled'] ? '1' : '0'; ?>">
							<?php echo $lock_status['enabled'] ? esc_html__( 'Disable File Lock Protection', 'ai-security-scanner' ) : esc_html__( 'Enable File Lock Protection', 'ai-security-scanner' ); ?>
						</button>
					<?php endif; ?>
					<span id="aiss-lock-msg"></span>
				</td>
			</tr>
			<tr>
				<th><label for="aiss-watchdog-interval"><?php esc_html_e( 'Watchdog check interval (minutes)', 'ai-security-scanner' ); ?></label></th>
				<td>
					<input type="number" id="aiss-watchdog-interval" name="watchdog_interval_minutes" min="1" max="60" value="<?php echo esc_attr( $settings['watchdog_interval_minutes'] ); ?>" class="small-text" />
					<p class="description"><?php esc_html_e( 'Relies on WP-Cron, which only fires on site visits — very low-traffic sites may check less often than this. Saved with the other settings below.', 'ai-security-scanner' ); ?></p>
				</td>
			</tr>
		</table>

		<h2><?php esc_html_e( 'Fix Actions (advanced)', 'ai-security-scanner' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'Off by default. When enabled, "Restore" / "Quarantine" buttons appear next to findings on the Suspicious Files, Modified Files and Core Integrity pages. Every fix requires an explicit confirmation click and automatically backs up whatever was on disk first, so it can always be undone from the Remediation Log.', 'ai-security-scanner' ); ?>
		</p>
		<table class="form-table">
			<tr>
				<th><label for="aiss-fix-actions-enabled"><?php esc_html_e( 'Enable Fix Actions', 'ai-security-scanner' ); ?></label></th>
				<td>
					<input type="checkbox" id="aiss-fix-actions-enabled" name="fix_actions_enabled" value="1" <?php checked( ! empty( $settings['fix_actions_enabled'] ) ); ?> />
					<p class="description">
						<?php esc_html_e( 'WordPress core files are restored from the official WordPress.org source for your exact installed version, checksum-verified before writing. Plugin files are restored the same way from the WordPress.org plugin repository, when that exact plugin/version is published there. Any file can also be restored from your own baseline snapshot. Files with no trusted source to restore from (e.g. a newly dropped file with no baseline) can be quarantined: backed up to the database, then deleted from disk. wp-config.php is never touched by this feature.', 'ai-security-scanner' ); ?>
					</p>
				</td>
			</tr>
		</table>

		<h2><?php esc_html_e( 'AI Analysis (optional)', 'ai-security-scanner' ); ?></h2>
		<p class="description"><?php esc_html_e( 'The scanner works fully without this. When enabled, only the specific flagged code snippet is sent to the configured provider — never the whole site.', 'ai-security-scanner' ); ?></p>
		<table class="form-table">
			<tr>
				<th><label for="aiss-ai-enabled"><?php esc_html_e( 'Enable AI analysis', 'ai-security-scanner' ); ?></label></th>
				<td><input type="checkbox" id="aiss-ai-enabled" name="ai_enabled" value="1" <?php checked( ! empty( $settings['ai_enabled'] ) ); ?> /></td>
			</tr>
			<tr>
				<th><label for="aiss-ai-provider"><?php esc_html_e( 'Provider', 'ai-security-scanner' ); ?></label></th>
				<td>
					<select id="aiss-ai-provider" name="ai_provider">
						<option value="none" <?php selected( $settings['ai_provider'], 'none' ); ?>><?php esc_html_e( 'None', 'ai-security-scanner' ); ?></option>
						<option value="generic" <?php selected( $settings['ai_provider'], 'generic' ); ?>><?php esc_html_e( 'OpenAI-compatible endpoint', 'ai-security-scanner' ); ?></option>
					</select>
				</td>
			</tr>
			<tr>
				<th><label for="aiss-ai-endpoint"><?php esc_html_e( 'API endpoint URL', 'ai-security-scanner' ); ?></label></th>
				<td><input type="url" id="aiss-ai-endpoint" name="ai_endpoint" value="<?php echo esc_attr( $settings['ai_endpoint'] ); ?>" class="large-text" placeholder="https://api.openai.com/v1/chat/completions" /></td>
			</tr>
			<tr>
				<th><label for="aiss-ai-model"><?php esc_html_e( 'Model', 'ai-security-scanner' ); ?></label></th>
				<td><input type="text" id="aiss-ai-model" name="ai_model" value="<?php echo esc_attr( $settings['ai_model'] ); ?>" class="regular-text" placeholder="gpt-4o-mini" /></td>
			</tr>
			<tr>
				<th><label for="aiss-ai-api-key"><?php esc_html_e( 'API key', 'ai-security-scanner' ); ?></label></th>
				<td>
					<input type="password" id="aiss-ai-api-key" name="ai_api_key" value="<?php echo esc_attr( AISS_Settings::mask_key( $settings['ai_api_key'] ) ); ?>" class="regular-text" autocomplete="off" />
					<p class="description"><?php esc_html_e( 'Stored server-side only and never sent to the browser in plain text. Leave unchanged to keep the current key.', 'ai-security-scanner' ); ?></p>
				</td>
			</tr>
		</table>

		<p>
			<button type="button" id="aiss-save-settings-btn" class="button button-primary"><?php esc_html_e( 'Save Settings', 'ai-security-scanner' ); ?></button>
		</p>
	</form>
</div>
