/* global jQuery, AISS */
( function ( $ ) {
	'use strict';

	var pollTimer = null;

	function ajax( action, data ) {
		data = data || {};
		data.action = action;
		data.nonce = AISS.nonce;
		return $.post( AISS.ajaxUrl, data );
	}

	function showBox( id ) {
		[ 'aiss-scan-idle', 'aiss-scan-running', 'aiss-scan-complete', 'aiss-scan-error' ].forEach( function ( box ) {
			$( '#' + box ).toggle( box === id );
		} );

		// The live findings feed stays visible through running + complete so
		// findings already surfaced don't disappear once the scan finishes;
		// it resets only when a fresh scan is started from idle.
		if ( 'aiss-scan-idle' === id ) {
			$( '#aiss-live-findings-box' ).hide();
			$( '#aiss-live-findings-list' ).empty();
		} else if ( 'aiss-scan-running' === id || 'aiss-scan-complete' === id ) {
			$( '#aiss-live-findings-box' ).show();
		}
	}

	function escapeHtml( str ) {
		return $( '<div>' ).text( str == null ? '' : str ).html();
	}

	function riskBadge( level ) {
		level = level || 'informational';
		return '<span class="aiss-badge aiss-badge-' + escapeHtml( level ) + '">' + escapeHtml( level ) + '</span>';
	}

	function addLiveFindings( findings ) {
		if ( ! findings || ! findings.length ) {
			return;
		}

		var $list = $( '#aiss-live-findings-list' );

		findings.forEach( function ( f ) {
			var $row = $(
				'<tr class="aiss-live-finding-row">' +
					'<td>' + riskBadge( f.risk_level ) + '</td>' +
					'<td><code>' + escapeHtml( f.file_path ) + '</code></td>' +
					'<td>' + escapeHtml( f.category ) + '</td>' +
					'<td>' + escapeHtml( f.reason ) + '</td>' +
					'<td class="aiss-actions"></td>' +
				'</tr>'
			);

			if ( f.finding_id ) {
				$( '<button type="button" class="button button-small aiss-view-finding"></button>' )
					.attr( 'data-finding-id', f.finding_id )
					.text( AISS.i18n.viewCode )
					.appendTo( $row.find( '.aiss-actions' ) );
			}

			$list.prepend( $row );
		} );
	}

	function phaseLabel( status ) {
		if ( 'listing' === status ) {
			return AISS.i18n.listing;
		}
		if ( 'finalizing' === status ) {
			return AISS.i18n.finalizing;
		}
		return AISS.i18n.scanning;
	}

	function renderProgress( data ) {
		$( '#aiss-scan-phase-label' ).text( phaseLabel( data.status ) );
		$( '#aiss-progress-bar' ).css( 'width', data.percent + '%' );
		$( '#aiss-progress-percent' ).text( data.percent + '%' );
		$( '#aiss-files-scanned' ).text( data.files_scanned );
		$( '#aiss-files-total' ).text( data.total_files );
		$( '#aiss-current-file-name' ).text( data.current_file || '' );
		$( '#aiss-live-modified' ).text( data.modified_files );
		$( '#aiss-live-new' ).text( data.new_files );
		$( '#aiss-live-suspicious' ).text( data.suspicious_files );
		$( '#aiss-live-critical' ).text( data.critical_count );
		$( '#aiss-live-high' ).text( data.high_count );
	}

	function poll( scanId ) {
		ajax( 'aiss_scan_progress', { scan_id: scanId } ).done( function ( resp ) {
			if ( ! resp.success ) {
				stopWithError( ( resp.data && resp.data.message ) || AISS.i18n.error );
				return;
			}

			var data = resp.data;

			if ( data.error ) {
				stopWithError( data.error );
				return;
			}

			renderProgress( data );
			addLiveFindings( data.new_findings );

			if ( 'completed' === data.status ) {
				showBox( 'aiss-scan-complete' );
				return;
			}

			if ( 'cancelled' === data.status ) {
				showBox( 'aiss-scan-idle' );
				return;
			}

			if ( 'error' === data.status ) {
				stopWithError( data.error_message || AISS.i18n.error );
				return;
			}

			pollTimer = setTimeout( function () {
				poll( scanId );
			}, 400 );
		} ).fail( function () {
			pollTimer = setTimeout( function () {
				poll( scanId );
			}, 2000 );
		} );
	}

	function stopWithError( message ) {
		$( '#aiss-scan-error-message' ).text( message );
		showBox( 'aiss-scan-error' );
	}

	function startScan() {
		var createBaseline = $( '#aiss-create-baseline' ).is( ':checked' ) ? '1' : '0';

		ajax( 'aiss_start_scan', { create_baseline: createBaseline } ).done( function ( resp ) {
			if ( ! resp.success ) {
				stopWithError( ( resp.data && resp.data.message ) || AISS.i18n.error );
				return;
			}
			showBox( 'aiss-scan-running' );
			renderProgress( { status: 'listing', percent: 0, files_scanned: 0, total_files: 0, modified_files: 0, new_files: 0, suspicious_files: 0, critical_count: 0, high_count: 0 } );
			poll( resp.data.scan_id );
		} );
	}

	function cancelScan() {
		var scanId = $( '#aiss-scan-panel' ).data( 'scan-id' );
		if ( ! window.confirm( AISS.i18n.confirmCancel ) ) {
			return;
		}
		clearTimeout( pollTimer );
		ajax( 'aiss_cancel_scan', { scan_id: scanId } ).always( function () {
			showBox( 'aiss-scan-idle' );
		} );
	}

	/* ---- Modals ---- */

	function openModal( id ) {
		$( '#aiss-modal-overlay' ).show();
		$( '.aiss-modal' ).hide();
		$( '#' + id ).show();
	}

	function closeModal() {
		$( '#aiss-modal-overlay' ).hide();
	}

	function viewFinding( findingId ) {
		ajax( 'aiss_get_finding', { finding_id: findingId } ).done( function ( resp ) {
			if ( ! resp.success ) {
				return;
			}
			var f = resp.data;
			$( '#aiss-fv-file' ).text( f.file_path );
			$( '#aiss-fv-risk' ).text( f.risk_level );
			$( '#aiss-fv-line' ).text( f.line_number || '—' );
			$( '#aiss-fv-category' ).text( f.category );
			$( '#aiss-fv-pattern' ).text( f.matched_pattern );
			$( '#aiss-fv-reason' ).text( f.reason );
			$( '#aiss-fv-snippet' ).text( f.code_snippet );
			$( '#aiss-fv-recommendation' ).text( f.recommendation );
			$( '#aiss-ai-analyze-btn' ).data( 'finding-id', f.id ).show();
			$( '#aiss-ai-result' ).hide();
			$( '#aiss-ai-error' ).hide();

			if ( AISS.fixActionsEnabled ) {
				var $fixSection = $( '#aiss-fv-fix-section' );
				$fixSection.find( '.aiss-fix-buttons' ).html( renderFixButtons( f.file_path ) );
				$fixSection.find( '.aiss-fix-result' ).hide().removeClass( 'aiss-fix-success aiss-fix-error' );
				$fixSection.show();
			} else {
				$( '#aiss-fv-fix-section' ).hide();
			}

			openModal( 'aiss-modal-view' );
		} );
	}

	function renderDiff( diffOps ) {
		var html = '';
		diffOps.forEach( function ( op ) {
			if ( 'add' === op.type ) {
				html += '<span class="aiss-diff-add">+ ' + escapeHtml( op.text ) + '</span>\n';
			} else if ( 'remove' === op.type ) {
				html += '<span class="aiss-diff-remove">- ' + escapeHtml( op.text ) + '</span>\n';
			} else if ( 'skip' === op.type || 'truncated' === op.type ) {
				html += '<span class="aiss-diff-skip">… ' + escapeHtml( op.text ) + '</span>\n';
			} else {
				html += '  ' + escapeHtml( op.text ) + '\n';
			}
		} );
		return html;
	}

	function compareFinding( scanFileId ) {
		ajax( 'aiss_get_diff', { scan_file_id: scanFileId } ).done( function ( resp ) {
			if ( ! resp.success ) {
				$( '#aiss-cmp-diff' ).text( ( resp.data && resp.data.message ) || AISS.i18n.error );
				openModal( 'aiss-modal-compare' );
				return;
			}
			var d = resp.data;
			$( '#aiss-cmp-file' ).text( d.file_path );
			$( '#aiss-cmp-no-baseline' ).toggle( ! d.has_baseline );
			$( '#aiss-cmp-diff' ).html( renderDiff( d.diff ) );
			openModal( 'aiss-modal-compare' );
		} );
	}

	function ignoreFinding( $btn ) {
		var findingId = $btn.data( 'finding-id' );
		var ignored = $btn.data( 'ignored' );

		ajax( 'aiss_ignore_finding', { finding_id: findingId, ignored: ignored } ).done( function ( resp ) {
			if ( resp.success ) {
				window.location.reload();
			}
		} );
	}

	function aiAnalyze() {
		var findingId = $( '#aiss-ai-analyze-btn' ).data( 'finding-id' );
		$( '#aiss-ai-error' ).hide();
		$( '#aiss-ai-analyze-btn' ).prop( 'disabled', true );

		ajax( 'aiss_ai_analyze', { finding_id: findingId } ).done( function ( resp ) {
			$( '#aiss-ai-analyze-btn' ).prop( 'disabled', false );
			if ( ! resp.success ) {
				$( '#aiss-ai-error p' ).text( ( resp.data && resp.data.message ) || AISS.i18n.error );
				$( '#aiss-ai-error' ).show();
				return;
			}
			$( '#aiss-ai-confidence' ).text( resp.data.confidence );
			$( '#aiss-ai-explanation' ).text( resp.data.explanation );
			$( '#aiss-ai-recommendation' ).text( resp.data.recommendation );
			$( '#aiss-ai-result' ).show();
		} );
	}

	/* ---- Core integrity ---- */

	function checkCore() {
		$( '#aiss-core-error' ).hide();
		$( '#aiss-check-core-btn' ).prop( 'disabled', true ).text( '…' );

		ajax( 'aiss_check_core', {} ).done( function ( resp ) {
			$( '#aiss-check-core-btn' ).prop( 'disabled', false ).text( $( '#aiss-check-core-btn' ).data( 'label' ) );

			if ( ! resp.success ) {
				$( '#aiss-core-error p' ).text( ( resp.data && resp.data.message ) || AISS.i18n.error );
				$( '#aiss-core-error' ).show();
				return;
			}

			var d = resp.data;
			$( '#aiss-core-summary' ).html(
				'<div class="aiss-card"><span class="aiss-card-label">Checked</span><span class="aiss-card-value">' + d.checked + '</span></div>' +
				'<div class="aiss-card aiss-risk-high"><span class="aiss-card-label">Modified</span><span class="aiss-card-value">' + d.modified.length + '</span></div>' +
				'<div class="aiss-card aiss-risk-medium"><span class="aiss-card-label">Missing</span><span class="aiss-card-value">' + d.missing.length + '</span></div>' +
				'<div class="aiss-card aiss-risk-low"><span class="aiss-card-label">Unexpected</span><span class="aiss-card-value">' + d.unexpected.length + '</span></div>'
			);

			function fillList( id, list ) {
				var $ul = $( id ).empty();
				list.forEach( function ( path ) {
					var $li = $( '<li>' ).text( path );
					if ( AISS.fixActionsEnabled ) {
						$( '<button type="button" class="button button-small aiss-open-fix"></button>' )
							.attr( 'data-file-path', path )
							.css( 'marginLeft', '10px' )
							.text( AISS.i18n.fixButton )
							.appendTo( $li );
					}
					$ul.append( $li );
				} );
			}

			fillList( '#aiss-core-modified', d.modified );
			fillList( '#aiss-core-missing', d.missing );
			fillList( '#aiss-core-unexpected', d.unexpected );

			$( '#aiss-core-results' ).show();
		} );
	}

	/* ---- Fix actions ---- */

	function fixButtonHtml( method, label, filePath, extraClass ) {
		return '<button type="button" class="button ' + ( extraClass || '' ) + ' aiss-do-fix" data-method="' + method + '" data-file-path="' + escapeHtml( filePath ) + '">' +
			escapeHtml( label ) + '</button> ';
	}

	function renderFixButtons( filePath ) {
		var isWpContent = 0 === filePath.indexOf( 'wp-content/' );
		var isPlugin = 0 === filePath.indexOf( 'wp-content/plugins/' );
		var html = '';

		if ( ! isWpContent ) {
			html += fixButtonHtml( 'restore_core', AISS.i18n.fixRestoreCore, filePath, 'button-primary' );
		}
		if ( isPlugin ) {
			html += fixButtonHtml( 'restore_plugin', AISS.i18n.fixRestorePlugin, filePath, 'button-primary' );
		}
		html += fixButtonHtml( 'restore_baseline', AISS.i18n.fixRestoreBaseline, filePath, '' );
		html += fixButtonHtml( 'quarantine', AISS.i18n.fixQuarantine, filePath, 'aiss-btn-danger' );

		return html;
	}

	function openFixModal( filePath ) {
		$( '#aiss-fix-file' ).text( filePath );
		var $box = $( '#aiss-modal-fix' );
		$box.find( '.aiss-fix-buttons' ).html( renderFixButtons( filePath ) );
		$box.find( '.aiss-fix-result' ).hide().removeClass( 'aiss-fix-success aiss-fix-error' );
		openModal( 'aiss-modal-fix' );
	}

	function runFixAction( $btn ) {
		var method = $btn.data( 'method' );
		var filePath = $btn.data( 'file-path' );
		var confirmMsg = ( 'quarantine' === method ? AISS.i18n.confirmQuarantine : AISS.i18n.confirmRestore ).replace( '%s', filePath );

		if ( ! window.confirm( confirmMsg ) ) {
			return;
		}

		var $buttons = $btn.closest( '.aiss-fix-buttons' );
		var $result = $buttons.siblings( '.aiss-fix-result' );

		$buttons.find( 'button' ).prop( 'disabled', true );
		$result.removeClass( 'aiss-fix-success aiss-fix-error' ).text( AISS.i18n.fixWorking ).show();

		$.post( AISS.ajaxUrl, {
			action: 'aiss_fix_action',
			nonce: AISS.fixNonce,
			file_path: filePath,
			method: method
		} ).done( function ( resp ) {
			$buttons.find( 'button' ).prop( 'disabled', false );
			if ( resp.success ) {
				$result.removeClass( 'aiss-fix-error' ).addClass( 'aiss-fix-success' ).text( AISS.i18n.fixSuccess );
			} else {
				$result.removeClass( 'aiss-fix-success' ).addClass( 'aiss-fix-error' ).text( ( resp.data && resp.data.message ) || AISS.i18n.error );
			}
		} ).fail( function () {
			$buttons.find( 'button' ).prop( 'disabled', false );
			$result.removeClass( 'aiss-fix-success' ).addClass( 'aiss-fix-error' ).text( AISS.i18n.error );
		} );
	}

	function undoFix( $btn ) {
		if ( ! window.confirm( AISS.i18n.confirmUndo ) ) {
			return;
		}
		var backupId = $btn.data( 'backup-id' );
		$btn.prop( 'disabled', true );

		$.post( AISS.ajaxUrl, {
			action: 'aiss_fix_undo',
			nonce: AISS.fixNonce,
			backup_id: backupId
		} ).done( function ( resp ) {
			if ( resp.success ) {
				window.location.reload();
			} else {
				$btn.prop( 'disabled', false );
				window.alert( ( resp.data && resp.data.message ) || AISS.i18n.error );
			}
		} ).fail( function () {
			$btn.prop( 'disabled', false );
			window.alert( AISS.i18n.error );
		} );
	}

	/* ---- Settings ---- */

	function saveSettings() {
		var settings = {
			batch_size: $( '#aiss-batch-size' ).val(),
			dir_batch_size: $( '#aiss-dir-batch-size' ).val(),
			max_file_size: $( '#aiss-max-file-size' ).val(),
			excluded_dirs: $( '#aiss-excluded-dirs' ).val(),
			allowed_extensions: $( '#aiss-allowed-extensions' ).val(),
			watchdog_interval_minutes: $( '#aiss-watchdog-interval' ).val(),
			fix_actions_enabled: $( '#aiss-fix-actions-enabled' ).is( ':checked' ) ? '1' : '',
			ai_enabled: $( '#aiss-ai-enabled' ).is( ':checked' ) ? '1' : '',
			ai_provider: $( '#aiss-ai-provider' ).val(),
			ai_endpoint: $( '#aiss-ai-endpoint' ).val(),
			ai_model: $( '#aiss-ai-model' ).val(),
			ai_api_key: $( '#aiss-ai-api-key' ).val()
		};

		$.post( AISS.ajaxUrl, {
			action: 'aiss_save_settings',
			nonce: AISS.settingsNonce,
			settings: settings
		} ).done( function ( resp ) {
			if ( resp.success ) {
				$( '#aiss-settings-saved' ).show();
				window.scrollTo( 0, 0 );
			}
		} );
	}

	function updateBaseline() {
		if ( ! window.confirm( AISS.i18n.confirmBaseline ) ) {
			return;
		}
		ajax( 'aiss_create_baseline', {} ).done( function ( resp ) {
			if ( resp.success ) {
				window.location.reload();
			} else {
				$( '#aiss-baseline-msg' ).text( ( resp.data && resp.data.message ) || AISS.i18n.error );
			}
		} );
	}

	function toggleLock( $btn ) {
		var currentlyEnabled = '1' === String( $btn.data( 'enabled' ) );
		var confirmMsg = currentlyEnabled ? AISS.i18n.confirmLockDisable : AISS.i18n.confirmLockEnable;

		if ( ! window.confirm( confirmMsg ) ) {
			return;
		}

		var originalText = $btn.text();
		$btn.prop( 'disabled', true ).text( AISS.i18n.lockWorking );
		$( '#aiss-lock-msg' ).text( '' );

		$.post( AISS.ajaxUrl, {
			action: 'aiss_toggle_lock',
			nonce: AISS.fixNonce,
			enable: currentlyEnabled ? '0' : '1'
		} ).done( function ( resp ) {
			if ( resp.success ) {
				window.location.reload();
			} else {
				$btn.prop( 'disabled', false ).text( originalText );
				$( '#aiss-lock-msg' ).text( ( resp.data && resp.data.message ) || AISS.i18n.error );
			}
		} ).fail( function () {
			$btn.prop( 'disabled', false ).text( originalText );
			$( '#aiss-lock-msg' ).text( AISS.i18n.error );
		} );
	}

	$( function () {
		$( '#aiss-start-scan' ).on( 'click', startScan );
		$( '#aiss-scan-again' ).on( 'click', function () {
			showBox( 'aiss-scan-idle' );
		} );
		$( '#aiss-cancel-scan' ).on( 'click', cancelScan );

		$( document ).on( 'click', '.aiss-view-finding', function () {
			viewFinding( $( this ).data( 'finding-id' ) );
		} );

		$( document ).on( 'click', '.aiss-compare-finding', function () {
			compareFinding( $( this ).data( 'scan-file-id' ) );
		} );

		$( document ).on( 'click', '.aiss-ignore-finding', function () {
			ignoreFinding( $( this ) );
		} );

		$( document ).on( 'click', '.aiss-modal-close, .aiss-modal-overlay', function ( e ) {
			if ( e.target === this ) {
				closeModal();
			}
		} );

		$( document ).on( 'click', '#aiss-ai-analyze-btn', aiAnalyze );
		$( document ).on( 'click', '#aiss-check-core-btn', checkCore );
		$( document ).on( 'click', '#aiss-save-settings-btn', saveSettings );
		$( document ).on( 'click', '#aiss-update-baseline-btn', updateBaseline );

		$( document ).on( 'click', '.aiss-open-fix', function () {
			openFixModal( $( this ).data( 'file-path' ) );
		} );
		$( document ).on( 'click', '.aiss-do-fix', function () {
			runFixAction( $( this ) );
		} );
		$( document ).on( 'click', '.aiss-undo-fix', function () {
			undoFix( $( this ) );
		} );
		$( document ).on( 'click', '#aiss-toggle-lock-btn', function () {
			toggleLock( $( this ) );
		} );

		var $panel = $( '#aiss-scan-panel' );
		if ( $panel.length && parseInt( $panel.data( 'scan-id' ), 10 ) > 0 ) {
			var status = $panel.data( 'status' );
			if ( 'completed' !== status && 'cancelled' !== status && 'error' !== status ) {
				showBox( 'aiss-scan-running' );
				poll( $panel.data( 'scan-id' ) );
			}
		}
	} );
} )( jQuery );
